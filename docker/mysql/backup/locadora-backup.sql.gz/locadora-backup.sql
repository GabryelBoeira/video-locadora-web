-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: videolocadora
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `videolocadora`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `videolocadora` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `videolocadora`;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Rua',
  `number` int DEFAULT NULL COMMENT 'Número',
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Cidade',
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Estado',
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'País',
  `complement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Complemento',
  `neighborhood` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Bairro',
  `active` bit(1) NOT NULL COMMENT 'Endereço ativo',
  `zip_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'CEP',
  `primary_address` bit(1) NOT NULL COMMENT 'Endereço principal',
  `customer_id` bigint NOT NULL COMMENT 'Id do cliente',
  PRIMARY KEY (`id`),
  KEY `FK_ADDRESS_ON_CUSTOMER` (`customer_id`),
  CONSTRAINT `FK_ADDRESS_ON_CUSTOMER` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'Rua A',123,'São Paulo','SP','Brasil',NULL,'teste 1',_binary '','01000000',_binary '',1),(2,'Avenida B',456,'Rio de Janeiro','RJ','Brasil',NULL,'Teste 2',_binary '','20000000',_binary '',2),(3,'Rua C',789,'Belo Horizonte','MG','Brasil',NULL,'teste 3',_binary '','30000000',_binary '',3),(4,'Avenida D',101,'Porto Alegre','RS','Brasil',NULL,'teste 4',_binary '','90000000',_binary '',4),(5,'Rua E',202,'Salvador','BA','Brasil',NULL,'teste 5',_binary '','40000000',_binary '',5),(6,'Avenida F',303,'Recife','PE','Brasil',NULL,'teste 6',_binary '','50000000',_binary '',6),(7,'Rua G',404,'Curitiba','PR','Brasil',NULL,'teste 7',_binary '','80000000',_binary '',7),(8,'Avenida H',505,'Brasília','DF','Brasil',NULL,'teste 8',_binary '','70000000',_binary '',8),(9,'Rua I',606,'Fortaleza','CE','Brasil',NULL,'teste 9',_binary '','60000000',_binary '',9),(10,'Avenida J',707,'Manaus','AM','Brasil',NULL,'teste 10',_binary '','69000000',_binary '',10);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(36) NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL,
  `total_price` double NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_cart_customer` (`customer_id`),
  KEY `idx_cart_session` (`session_id`),
  KEY `idx_cart_expires` (`expires_at`),
  CONSTRAINT `fk_cart_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,'4a995e4a-6064-40a2-b1af-62cf55cf5ef2',1,'2026-10-19 01:02:41','2026-10-19 01:32:41',0,'EXPIRED');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_item`
--

DROP TABLE IF EXISTS `cart_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cart_id` bigint NOT NULL,
  `movie_id` bigint NOT NULL,
  `rental_days` int NOT NULL,
  `unit_price` double NOT NULL,
  `subtotal` double NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reservation_expires_at` timestamp NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_cart_item_cart` (`cart_id`),
  KEY `idx_cart_item_movie` (`movie_id`),
  KEY `idx_cart_item_reservation` (`reservation_expires_at`),
  CONSTRAINT `fk_cart_item_cart` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cart_item_movie` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_item`
--

LOCK TABLES `cart_item` WRITE;
/*!40000 ALTER TABLE `cart_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nome',
  `cpf` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'CPF',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Email',
  `delay_devolution` bit(1) DEFAULT NULL COMMENT 'Tem atraso em alguma devolução',
  `enable` tinyint(1) DEFAULT NULL COMMENT 'usuario ativo',
  `birth_date` date DEFAULT NULL,
  `cell_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'numeoro celular',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Ana Silva','12345678901','ana.silva@email.com',_binary '\0',1,'1990-01-01',NULL),(2,'Bruno Oliveira','98765432109','bruno.oliveira@email.com',_binary '',1,'1990-01-01',NULL),(3,'Carla Souza','45678901234','carla.souza@email.com',_binary '\0',1,'1990-01-01',NULL),(4,'Daniel Pereira','65432109876','daniel.pereira@email.com',_binary '',1,'1990-01-01',NULL),(5,'Elisa Santos','78901234567','elisa.santos@email.com',_binary '\0',1,'1990-01-01',NULL),(6,'Fernando Lima','01234567890','fernando.lima@email.com',_binary '',1,'1990-01-01',NULL),(7,'Gabriela Rocha','34567890123','gabriela.rocha@email.com',_binary '\0',1,'1990-01-01',NULL),(8,'Henrique Costa','21098765432','henrique.costa@email.com',_binary '',1,'1990-01-01',NULL),(9,'Isabela Gomes','56789012345','isabela.gomes@email.com',_binary '\0',1,'1990-01-01',NULL),(10,'João Rodrigues','89012345678','joao.rodrigues@email.com',_binary '',1,'1990-01-01',NULL);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','customer information','SQL','V1__customer_information.sql',-103541430,'root','2026-09-21 01:28:03',12,1),(2,'2','address information','SQL','V2__address_information.sql',407302086,'root','2026-09-21 01:28:03',29,1),(3,'3','movie information','SQL','V3__movie_information.sql',-712756413,'root','2026-09-21 01:28:03',9,1),(4,'4','rental information','SQL','V4__rental_information.sql',-1478567931,'root','2026-09-21 01:28:03',38,1),(5,'5','birth-date information','SQL','V5__birth-date_information.sql',928759833,'root','2026-09-21 01:28:03',7,1),(6,'6','cart information','SQL','V6__cart_information.sql',-2118432194,'root','2026-09-21 01:28:03',23,1),(7,'7','add colunms customer','SQL','V7__add_colunms_customer.sql',-2130597667,'root','2026-09-21 01:28:03',8,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Título',
  `content_rating` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Classificação indicativa',
  `internal_code` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Código interno',
  `price` double NOT NULL COMMENT 'Preço',
  `available` bit(1) NOT NULL COMMENT 'Disponibilidade no estoque',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Tipo',
  `genre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Gênero',
  PRIMARY KEY (`id`),
  UNIQUE KEY `internal_code` (`internal_code`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (1,'Aventura nas Estrelas','PG_13','b0ae2ae9-b55b-11f1-aaf9-125fe7388284',19.99,_binary '','BLU_RAY','SCIENCE_FICTION'),(2,'Comédia Selvagem','AGE_18','b0ae2c4d-b55b-11f1-aaf9-125fe7388284',14.99,_binary '','DVD','COMEDY'),(3,'Lágrimas na Chuva','PG_10','b0ae2ca3-b55b-11f1-aaf9-125fe7388284',12.99,_binary '','DVD','DRAMA'),(4,'Dragões e Magia','PG_13','b0ae2cd2-b55b-11f1-aaf9-125fe7388284',24.99,_binary '','BLU_RAY','FANTASY'),(5,'Noite dos Mortos Vivos 2','AGE_18','b0ae2cfd-b55b-11f1-aaf9-125fe7388284',17.99,_binary '\0','DVD','HORROR'),(6,'Um Amor para Recordar','PG_10','b0ae2d27-b55b-11f1-aaf9-125fe7388284',10.99,_binary '','DVD','ROMANCE'),(7,'O Suspeito','AGE_18','b0ae2d51-b55b-11f1-aaf9-125fe7388284',16.99,_binary '','DVD','THRILLER'),(8,'Guerra no Espaço','PG_13','b0ae2d78-b55b-11f1-aaf9-125fe7388284',22.99,_binary '','BLU_RAY','SCIENCE_FICTION'),(9,'Risadas Soltas','PG_10','b0ae2da0-b55b-11f1-aaf9-125fe7388284',13.99,_binary '','DVD','COMEDY'),(10,'Coração Partido','PG_10','b0ae2dc7-b55b-11f1-aaf9-125fe7388284',11.99,_binary '','DVD','DRAMA'),(11,'A Princesa Guerreira','PG_13','b0ae2deb-b55b-11f1-aaf9-125fe7388284',27.99,_binary '','BLU_RAY','FANTASY'),(12,'A Maldição da Mansão','AGE_18','b0ae2e2f-b55b-11f1-aaf9-125fe7388284',19.99,_binary '\0','DVD','HORROR'),(13,'Enquanto Você Dormia','PG_10','b0ae2e55-b55b-11f1-aaf9-125fe7388284',9.99,_binary '','DVD','ROMANCE'),(14,'Perseguição Implacável','AGE_18','b0ae2e79-b55b-11f1-aaf9-125fe7388284',18.99,_binary '','DVD','THRILLER'),(15,'Planeta Proibido','PG_13','b0ae2e9f-b55b-11f1-aaf9-125fe7388284',21.99,_binary '','DVD','SCIENCE_FICTION'),(16,'Férias Frustradas','PG_13','b0ae2ec3-b55b-11f1-aaf9-125fe7388284',15.99,_binary '','DVD','COMEDY'),(17,'Segredos do Passado','PG_10','b0ae2ee7-b55b-11f1-aaf9-125fe7388284',14.99,_binary '','DVD','DRAMA'),(18,'A Lenda do Cavaleiro Verde','PG_13','b0ae2f0e-b55b-11f1-aaf9-125fe7388284',26.99,_binary '','BLU_RAY','FANTASY'),(19,'O Exorcista Retorna','AGE_18','b0ae2f32-b55b-11f1-aaf9-125fe7388284',20.99,_binary '\0','DVD','HORROR'),(20,'Amor Além do Tempo','PG_10','b0ae2f58-b55b-11f1-aaf9-125fe7388284',10.99,_binary '','DVD','ROMANCE'),(21,'O Silêncio dos Inocentes','AGE_18','b0ae2f7e-b55b-11f1-aaf9-125fe7388284',17.99,_binary '','DVD','THRILLER'),(22,'Invasores de Corpos','PG_13','b0ae2fa3-b55b-11f1-aaf9-125fe7388284',23.99,_binary '','DVD','SCIENCE_FICTION'),(23,'Um Tira Muito Louco','AGE_18','b0ae2fcf-b55b-11f1-aaf9-125fe7388284',16.99,_binary '','DVD','ACTION_COMEDY'),(24,'O Resgate do Soldado Ryan','AGE_18','b0ae2ff3-b55b-11f1-aaf9-125fe7388284',19.99,_binary '','DVD','ACTION_DRAMA'),(25,'Missão Impossível','PG_13','b0ae3018-b55b-11f1-aaf9-125fe7388284',20.99,_binary '','DVD','ACTION_THRILLER'),(26,'Apertem os Cintos... o Piloto Sumiu!','PG_13','b0ae3042-b55b-11f1-aaf9-125fe7388284',12.99,_binary '','DVD','COMEDY_DRAMA'),(27,'Corra que a Polícia Vem Aí','PG_13','b0ae3067-b55b-11f1-aaf9-125fe7388284',14.99,_binary '','DVD','COMEDY_THRILLER'),(28,'Seven - Os Sete Crimes Capitais','AGE_18','b0ae308c-b55b-11f1-aaf9-125fe7388284',18.99,_binary '','DVD','DRAMA_THRILLER'),(29,'Bad Boys','AGE_18','b0ae30b1-b55b-11f1-aaf9-125fe7388284',17.99,_binary '','DVD','ACTION_COMEDY_DRAMA'),(30,'Máquina Mortífera','AGE_18','b0ae30d6-b55b-11f1-aaf9-125fe7388284',18.99,_binary '','DVD','ACTION_COMEDY_THRILLER'),(31,'A Viagem do Balão Vermelho','FREE','b0ae30fb-b55b-11f1-aaf9-125fe7388284',8.99,_binary '','DVD','DRAMA'),(32,'Planeta Jardim','FREE','b0ae3121-b55b-11f1-aaf9-125fe7388284',9.49,_binary '','VHS','DOCUMENTARY'),(33,'Os Pequenos Heróis','PG_10','b0ae3147-b55b-11f1-aaf9-125fe7388284',11.99,_binary '','DVD','ANIMATION'),(34,'Risos em Família','PG_10','b0ae316d-b55b-11f1-aaf9-125fe7388284',12.49,_binary '','DVD','COMEDY'),(35,'O Mistério do Museu','PG_13','b0ae3191-b55b-11f1-aaf9-125fe7388284',16.99,_binary '','BLU_RAY','THRILLER'),(36,'A Floresta Sombria','AGE_16','b0ae31b9-b55b-11f1-aaf9-125fe7388284',17.49,_binary '','DVD','HORROR'),(37,'Códigos e Segredos','AGE_16','b0ae31df-b55b-11f1-aaf9-125fe7388284',18.99,_binary '\0','DVD','THRILLER'),(38,'Operação Relâmpago','PG_13','b0ae3204-b55b-11f1-aaf9-125fe7388284',19.99,_binary '','BLU_RAY','ACTION'),(39,'Cidade das Sombras','AGE_18','b0ae3228-b55b-11f1-aaf9-125fe7388284',21.49,_binary '','BLU_RAY','DRAMA_THRILLER'),(40,'Amor em Paris','PG_10','b0ae324c-b55b-11f1-aaf9-125fe7388284',10.49,_binary '','DVD','ROMANCE'),(41,'Nebulosa X','PG_13','b0ae3272-b55b-11f1-aaf9-125fe7388284',22.99,_binary '','BLU_RAY','SCIENCE_FICTION'),(42,'Batalha Final','AGE_18','b0ae3299-b55b-11f1-aaf9-125fe7388284',24.99,_binary '\0','BLU_RAY','ACTION_THRILLER'),(43,'Magia do Norte','PG_10','b0ae32c2-b55b-11f1-aaf9-125fe7388284',13.99,_binary '','DVD','FANTASY'),(44,'Caçadores do Tesouro','PG_13','b0ae32e7-b55b-11f1-aaf9-125fe7388284',18.49,_binary '','DVD','ACTION_COMEDY'),(45,'Diário do Medo','AGE_16','b0ae330d-b55b-11f1-aaf9-125fe7388284',15.99,_binary '','DVD','HORROR'),(46,'No Limite','AGE_18','b0ae3331-b55b-11f1-aaf9-125fe7388284',19.49,_binary '','DVD','ACTION_DRAMA'),(47,'Som e Silêncio','PG_10','b0ae3355-b55b-11f1-aaf9-125fe7388284',12.99,_binary '','VHS','DRAMA'),(48,'A Última Gargalhada','AGE_18','b0ae337b-b55b-11f1-aaf9-125fe7388284',16.49,_binary '','DVD','COMEDY_THRILLER'),(49,'Universo Paralelo','PG_13','b0ae339f-b55b-11f1-aaf9-125fe7388284',20.49,_binary '','BLU_RAY','SCIENCE_FICTION'),(50,'Contos Animados','FREE','b0ae33c4-b55b-11f1-aaf9-125fe7388284',9.99,_binary '','DVD','ANIMATION');
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental`
--

DROP TABLE IF EXISTS `rental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customer_id` bigint NOT NULL,
  `rented_at` timestamp NOT NULL,
  `due_at` timestamp NOT NULL,
  `returned_at` timestamp NULL DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rental_customer_id` (`customer_id`),
  CONSTRAINT `fk_rental_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental`
--

LOCK TABLES `rental` WRITE;
/*!40000 ALTER TABLE `rental` DISABLE KEYS */;
/*!40000 ALTER TABLE `rental` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental_item`
--

DROP TABLE IF EXISTS `rental_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rental_id` bigint NOT NULL,
  `movie_id` bigint NOT NULL,
  `item_price` double NOT NULL,
  `returned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rental_item_rental_id` (`rental_id`),
  KEY `idx_rental_item_movie_id` (`movie_id`),
  CONSTRAINT `fk_rental_item_movie` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`),
  CONSTRAINT `fk_rental_item_rental` FOREIGN KEY (`rental_id`) REFERENCES `rental` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental_item`
--

LOCK TABLES `rental_item` WRITE;
/*!40000 ALTER TABLE `rental_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `rental_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'videolocadora'
--

--
-- Dumping routines for database 'videolocadora'
--

--
-- Current Database: `keycloak`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `keycloak` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `keycloak`;

--
-- Table structure for table `ADMIN_EVENT_ENTITY`
--

DROP TABLE IF EXISTS `ADMIN_EVENT_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ADMIN_EVENT_ENTITY` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ADMIN_EVENT_TIME` bigint DEFAULT NULL,
  `REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OPERATION_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_PATH` text COLLATE utf8mb4_unicode_ci,
  `REPRESENTATION` text COLLATE utf8mb4_unicode_ci,
  `ERROR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_TYPE` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DETAILS_JSON` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_ADMIN_EVENT_TIME` (`REALM_ID`,`ADMIN_EVENT_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ADMIN_EVENT_ENTITY`
--

LOCK TABLES `ADMIN_EVENT_ENTITY` WRITE;
/*!40000 ALTER TABLE `ADMIN_EVENT_ENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `ADMIN_EVENT_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ASSOCIATED_POLICY`
--

DROP TABLE IF EXISTS `ASSOCIATED_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ASSOCIATED_POLICY` (
  `POLICY_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ASSOCIATED_POLICY_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`POLICY_ID`,`ASSOCIATED_POLICY_ID`),
  KEY `IDX_ASSOC_POL_ASSOC_POL_ID` (`ASSOCIATED_POLICY_ID`),
  CONSTRAINT `FK_FRSR5S213XCX4WNKOG82SSRFY` FOREIGN KEY (`ASSOCIATED_POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`),
  CONSTRAINT `FK_FRSRPAS14XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ASSOCIATED_POLICY`
--

LOCK TABLES `ASSOCIATED_POLICY` WRITE;
/*!40000 ALTER TABLE `ASSOCIATED_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `ASSOCIATED_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATION_EXECUTION`
--

DROP TABLE IF EXISTS `AUTHENTICATION_EXECUTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATION_EXECUTION` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTHENTICATOR` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FLOW_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REQUIREMENT` int DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  `AUTHENTICATOR_FLOW` tinyint NOT NULL DEFAULT '0',
  `AUTH_FLOW_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_CONFIG` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_AUTH_EXEC_REALM_FLOW` (`REALM_ID`,`FLOW_ID`),
  KEY `IDX_AUTH_EXEC_FLOW` (`FLOW_ID`),
  CONSTRAINT `FK_AUTH_EXEC_FLOW` FOREIGN KEY (`FLOW_ID`) REFERENCES `AUTHENTICATION_FLOW` (`ID`),
  CONSTRAINT `FK_AUTH_EXEC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATION_EXECUTION`
--

LOCK TABLES `AUTHENTICATION_EXECUTION` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATION_EXECUTION` DISABLE KEYS */;
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('08cea2da-ff80-4a69-8d97-42e546a0daab',NULL,'webauthn-authenticator','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','13bb4c05-3d45-4338-8c56-f861e6559b4f',3,40,0,NULL,NULL),('09333baf-4398-40f1-b869-16cc830d2f2f',NULL,'conditional-user-configured','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','13bb4c05-3d45-4338-8c56-f861e6559b4f',0,10,0,NULL,NULL),('0ed63535-dd74-439d-b754-da07d319ec48',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','fe9a8920-3135-4faf-bf53-430f105ca09b',0,20,1,'2be9e75e-2e8b-4d7b-baa4-a89f17b9fc0a',NULL),('0fa6571b-09df-48a4-9ed8-e795ace8e18e',NULL,'auth-spnego','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','18f7dbe3-b9e1-4bfe-b6e4-e0633333649b',3,20,0,NULL,NULL),('1914607b-fc3e-4ccd-b4e3-8efd3a6f65bd',NULL,'client-jwt','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','b329b136-1daa-4f76-97a6-9979c730a9ff',2,20,0,NULL,NULL),('191b94a5-d1a7-437f-b8b1-caf6410f3210',NULL,'identity-provider-redirector','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','18f7dbe3-b9e1-4bfe-b6e4-e0633333649b',2,25,0,NULL,NULL),('1dad1e4d-e584-4176-ac53-62d9957673b9',NULL,'reset-credentials-choose-user','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','a4acbcfb-294f-462e-a9af-7066e899f78f',0,10,0,NULL,NULL),('1f3d6fbe-9749-44d2-84e0-4c078e032f0f',NULL,'identity-provider-redirector','84ab64b6-3491-4ad3-8d0b-34567e32e313','2171dcb5-2f36-468d-9620-002ac6875e4a',2,25,0,NULL,NULL),('20a150ba-7ca9-42a6-a613-dd0a0475338c',NULL,'registration-recaptcha-action','84ab64b6-3491-4ad3-8d0b-34567e32e313','e574065d-6406-45cd-8a66-ea5a8d017cc2',3,60,0,NULL,NULL),('27fecc54-c0ec-4770-8972-7de59a8742e7',NULL,'reset-otp','84ab64b6-3491-4ad3-8d0b-34567e32e313','ca91350d-eaa1-4faf-8549-6b5ceb0191a1',0,20,0,NULL,NULL),('2956c733-6e1e-4955-b143-7bed09c06d23',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ace3e7b2-4f53-411f-8937-15206446ee27',1,30,1,'570e8e7e-f9cb-43f7-ba0b-4ead40a9a874',NULL),('2d51448e-a7b3-47f3-860f-acf8cb3b8fe1',NULL,'auth-recovery-authn-code-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','70f5a9a3-23e9-48ac-979d-a6a1f2b2321d',3,50,0,NULL,NULL),('2ef3bf3d-c67c-436e-b504-f0ab65ed5523',NULL,'conditional-user-configured','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','70f5a9a3-23e9-48ac-979d-a6a1f2b2321d',0,10,0,NULL,NULL),('2f75d1c6-ce16-4d60-9893-4a7e435c2699',NULL,'conditional-credential','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','70f5a9a3-23e9-48ac-979d-a6a1f2b2321d',0,20,0,NULL,'a2a3f6e3-2a54-45d3-896c-7778b5244d20'),('30dd25b8-cf46-4f0a-b054-4f30a39cf918',NULL,'registration-password-action','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5fe1bd83-3d24-4e10-9738-df170015c921',0,50,0,NULL,NULL),('31086df2-9051-4c74-872a-e2fb452851c5',NULL,'http-basic-authenticator','84ab64b6-3491-4ad3-8d0b-34567e32e313','42f88d19-f437-4c87-9852-b0d804c0237a',0,10,0,NULL,NULL),('3141349d-0316-45fe-93cc-af3cd4f85381',NULL,'auth-recovery-authn-code-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','13bb4c05-3d45-4338-8c56-f861e6559b4f',3,50,0,NULL,NULL),('319d73d8-99b5-4ea4-aa80-1af5925d948b',NULL,'auth-otp-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','70f5a9a3-23e9-48ac-979d-a6a1f2b2321d',2,30,0,NULL,NULL),('35ce8d5c-d48b-4f42-8d7a-9987b9c5fc11',NULL,'registration-page-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','9277b8f3-ac0c-44fc-883d-ae764c53ca3e',0,10,1,'5fe1bd83-3d24-4e10-9738-df170015c921',NULL),('3637add2-6b15-4763-af91-5ff6c3619c5e',NULL,'registration-page-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','30023d6e-1e73-472d-a64f-ebac7b7225d4',0,10,1,'e574065d-6406-45cd-8a66-ea5a8d017cc2',NULL),('380c406a-9fed-4e8d-aef7-4f4dfbf38f14',NULL,'webauthn-authenticator','84ab64b6-3491-4ad3-8d0b-34567e32e313','7dd4bd33-42b5-435c-8646-ea53a60c154c',3,40,0,NULL,NULL),('3941d66f-cd2d-4d05-8704-49ba63b2e54d',NULL,'conditional-user-configured','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','e305e857-a64c-47f6-a8c8-fd5fc3fd1b51',0,10,0,NULL,NULL),('39aad1ee-df35-49c6-90ce-3bfdff025454',NULL,'registration-recaptcha-action','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5fe1bd83-3d24-4e10-9738-df170015c921',3,60,0,NULL,NULL),('39f453c3-1cae-47c5-8fc6-231cd84f9178',NULL,'reset-password','84ab64b6-3491-4ad3-8d0b-34567e32e313','ad814251-0805-46fa-a0b9-4b0f36475fc7',0,30,0,NULL,NULL),('3e5efbd6-99e6-47b9-9a3c-abd94871b02e',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','bd6b69af-3043-4a92-bfc4-d88e6d4ce742',2,20,1,'c57bfc0d-426a-4394-952d-a97f085c5918',NULL),('3f26f0ea-9e28-4cfe-95a1-fc7dbcb60b06',NULL,'auth-otp-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','13bb4c05-3d45-4338-8c56-f861e6559b4f',2,30,0,NULL,NULL),('4509f94b-f11e-46fe-a582-4727135b6a0e',NULL,'auth-recovery-authn-code-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','c1ccae56-2953-4330-8b76-7a7c5c06b1e9',3,50,0,NULL,NULL),('46513734-e9b5-4923-ac16-7370cdc6513d',NULL,'auth-username-password-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','547594ad-3454-40a5-8f68-6b2b5bda7c85',0,10,0,NULL,NULL),('4ab15b74-49ed-4953-8cb2-a6c51e2ac616',NULL,'conditional-user-configured','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ef397a66-487e-4562-9e8d-713ef672e13c',0,10,0,NULL,NULL),('4b1b3d7e-7c04-4a35-95e5-3a0da4a99f9b',NULL,'idp-review-profile','84ab64b6-3491-4ad3-8d0b-34567e32e313','b4d48dee-1ddd-40bd-8c23-ee5a21e0d768',0,10,0,NULL,'05e9eb7e-9c64-4dc5-ac16-20693c64d671'),('4b357218-dbcd-4084-9858-184046d162aa',NULL,'conditional-user-configured','84ab64b6-3491-4ad3-8d0b-34567e32e313','ca91350d-eaa1-4faf-8549-6b5ceb0191a1',0,10,0,NULL,NULL),('520fc57c-a1d6-4766-8cb2-3d1f28e19fcf',NULL,'direct-grant-validate-password','84ab64b6-3491-4ad3-8d0b-34567e32e313','6a37e0ec-0488-4e26-93eb-d404bc21b066',0,20,0,NULL,NULL),('52249e0b-7410-4f22-a694-b54fc96b7206',NULL,'idp-username-password-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','c57bfc0d-426a-4394-952d-a97f085c5918',0,10,0,NULL,NULL),('530d0338-368d-4088-996f-64fa7b6428fd',NULL,'auth-recovery-authn-code-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','7dd4bd33-42b5-435c-8646-ea53a60c154c',3,50,0,NULL,NULL),('5764aae9-8e27-427a-ad55-379d025b8fa5',NULL,'idp-review-profile','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','fe9a8920-3135-4faf-bf53-430f105ca09b',0,10,0,NULL,'614f5476-7533-4a48-9901-b7b191800459'),('586a3dc2-bfaf-414d-a0bb-b7a01fd9ecc3',NULL,'client-secret-jwt','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','b329b136-1daa-4f76-97a6-9979c730a9ff',2,30,0,NULL,NULL),('5b39580b-7194-4986-b0ac-c98f770af189',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','1f1049c5-502a-4d3c-9b73-c6ededd07b1c',1,20,1,'13bb4c05-3d45-4338-8c56-f861e6559b4f',NULL),('648a8c54-640e-4f2e-a4de-a3ab73d07bd3',NULL,'direct-grant-validate-password','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ace3e7b2-4f53-411f-8937-15206446ee27',0,20,0,NULL,NULL),('6779f0c6-1d93-49b3-acb4-79cfa01a39af',NULL,'auth-cookie','84ab64b6-3491-4ad3-8d0b-34567e32e313','2171dcb5-2f36-468d-9620-002ac6875e4a',2,10,0,NULL,NULL),('6bfded38-1918-44b7-8d72-d5fc2a57f246',NULL,'conditional-user-configured','84ab64b6-3491-4ad3-8d0b-34567e32e313','c1ccae56-2953-4330-8b76-7a7c5c06b1e9',0,10,0,NULL,NULL),('7290d399-a3e7-4dd5-99d7-13912d8f2fa8',NULL,'idp-add-organization-member','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ef397a66-487e-4562-9e8d-713ef672e13c',0,20,0,NULL,NULL),('762f4a05-9d53-471f-a726-cc49e7ece8f0',NULL,'direct-grant-validate-username','84ab64b6-3491-4ad3-8d0b-34567e32e313','6a37e0ec-0488-4e26-93eb-d404bc21b066',0,10,0,NULL,NULL),('763eadb9-415b-407b-877e-b18ccf799daa',NULL,'auth-spnego','84ab64b6-3491-4ad3-8d0b-34567e32e313','2171dcb5-2f36-468d-9620-002ac6875e4a',3,20,0,NULL,NULL),('78ee30a4-aa5b-4690-8c72-c48e77c280c0',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','05a83ce7-f691-44a6-b20c-2617220ef72c',0,20,1,'f3325618-1492-489a-9b7c-7ebe0dd6f317',NULL),('7d27f8aa-e066-41d5-a0a3-c5451f18232d',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','fe9a8920-3135-4faf-bf53-430f105ca09b',1,60,1,'ef397a66-487e-4562-9e8d-713ef672e13c',NULL),('7dac3e9a-e98f-49e3-b702-7a6ce08bb165',NULL,'registration-terms-and-conditions','84ab64b6-3491-4ad3-8d0b-34567e32e313','e574065d-6406-45cd-8a66-ea5a8d017cc2',3,70,0,NULL,NULL),('7e9d8954-fa6a-4fb9-a40b-7313a16e6b25',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','1db10166-eef0-4dd0-80db-539916cd9bb5',1,10,1,'305caaa6-cd23-4801-8a44-340bee3de1f6',NULL),('8097c7c7-a509-4cb2-ad2e-f91e900e6428',NULL,'conditional-user-configured','84ab64b6-3491-4ad3-8d0b-34567e32e313','7dd4bd33-42b5-435c-8646-ea53a60c154c',0,10,0,NULL,NULL),('84196827-187a-485a-aa4e-c6f2016bfe1a',NULL,'idp-username-password-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','36c56211-874f-41f2-91ba-b007c19d2386',0,10,0,NULL,NULL),('84382041-f2bb-48e7-b6aa-83185d5f8026',NULL,'registration-password-action','84ab64b6-3491-4ad3-8d0b-34567e32e313','e574065d-6406-45cd-8a66-ea5a8d017cc2',0,50,0,NULL,NULL),('848792c4-a8d5-4637-96d6-72bb5d7f9e77',NULL,'reset-credentials-choose-user','84ab64b6-3491-4ad3-8d0b-34567e32e313','ad814251-0805-46fa-a0b9-4b0f36475fc7',0,10,0,NULL,NULL),('886d30b8-55db-4bc5-81cc-79ae70e1e83b',NULL,'reset-otp','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','e305e857-a64c-47f6-a8c8-fd5fc3fd1b51',0,20,0,NULL,NULL),('8b44d8ed-2869-4b17-a8ec-8ba45981f5c5',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','18f7dbe3-b9e1-4bfe-b6e4-e0633333649b',2,26,1,'1db10166-eef0-4dd0-80db-539916cd9bb5',NULL),('8cb4d615-e03b-4d5f-8c1f-d8f1a4bb8262',NULL,'conditional-credential','84ab64b6-3491-4ad3-8d0b-34567e32e313','7dd4bd33-42b5-435c-8646-ea53a60c154c',0,20,0,NULL,'72b12f01-3dfd-44cf-bfe1-0cbd888d3d4d'),('8d77f910-5a1d-43ed-b5e9-b56721c29105',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','c57bfc0d-426a-4394-952d-a97f085c5918',1,20,1,'70f5a9a3-23e9-48ac-979d-a6a1f2b2321d',NULL),('8d982b55-1d4f-41de-a2f5-296d612ea78e',NULL,'client-jwt','84ab64b6-3491-4ad3-8d0b-34567e32e313','f84dfc68-fb64-42d2-b465-813fb35926e5',2,20,0,NULL,NULL),('8fd0a924-7bda-4670-9771-298977b1970f',NULL,'auth-otp-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','7dd4bd33-42b5-435c-8646-ea53a60c154c',2,30,0,NULL,NULL),('92733421-fbb5-45b2-9a3a-5a73f7854d2d',NULL,'idp-email-verification','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','bd6b69af-3043-4a92-bfc4-d88e6d4ce742',2,10,0,NULL,NULL),('93fe1f38-639c-4014-91da-ab63799ff222',NULL,'conditional-user-configured','84ab64b6-3491-4ad3-8d0b-34567e32e313','9290daee-5dd3-4f6b-abdb-7b7f90fc9f8d',0,10,0,NULL,NULL),('968de5b3-cf04-4682-8fc9-b28bfe3ea0b3',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','2171dcb5-2f36-468d-9620-002ac6875e4a',2,30,1,'547594ad-3454-40a5-8f68-6b2b5bda7c85',NULL),('96c89ef4-7364-4f01-83c6-80149ba9512d',NULL,'idp-create-user-if-unique','84ab64b6-3491-4ad3-8d0b-34567e32e313','8f97c36b-7ae0-4da3-b602-f5aea0af980a',2,10,0,NULL,'a5b1cb98-796e-4a1d-b90d-20d2374f600c'),('98123ce3-37bf-4342-978a-2fc19e03fed2',NULL,'docker-http-basic-authenticator','84ab64b6-3491-4ad3-8d0b-34567e32e313','37f96afe-b813-492c-85f9-6ac327b3cc7d',0,10,0,NULL,NULL),('9c359ee0-eaf3-4249-b9be-6a87996a3796',NULL,'webauthn-authenticator','84ab64b6-3491-4ad3-8d0b-34567e32e313','c1ccae56-2953-4330-8b76-7a7c5c06b1e9',3,40,0,NULL,NULL),('9d60ccea-41d1-4ec3-9a5f-382ace02191b',NULL,'idp-confirm-link','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','94370c21-ce38-4c21-92ac-dec729416493',0,10,0,NULL,NULL),('9ffa3c68-eb9a-4449-b46b-af1d77a2a6e8',NULL,'reset-credential-email','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','a4acbcfb-294f-462e-a9af-7066e899f78f',0,20,0,NULL,NULL),('a053a994-fe07-4f03-be62-0b0b2d8ea940',NULL,'direct-grant-validate-otp','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','570e8e7e-f9cb-43f7-ba0b-4ead40a9a874',0,20,0,NULL,NULL),('a1e42116-03d5-41d5-a275-13fdf35ced96',NULL,'client-secret-jwt','84ab64b6-3491-4ad3-8d0b-34567e32e313','f84dfc68-fb64-42d2-b465-813fb35926e5',2,30,0,NULL,NULL),('a6cfb3be-0bff-48a8-b2b3-befd16de77ed',NULL,'conditional-credential','84ab64b6-3491-4ad3-8d0b-34567e32e313','c1ccae56-2953-4330-8b76-7a7c5c06b1e9',0,20,0,NULL,'8efd7b38-2e9c-4dcf-8f72-1f1345af5677'),('a8b4af73-16f6-4bab-9b2d-17a815a1f457',NULL,'registration-user-creation','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5fe1bd83-3d24-4e10-9738-df170015c921',0,20,0,NULL,NULL),('a8e7b0cc-385d-4cde-97f7-0d37482db2e4',NULL,'reset-credential-email','84ab64b6-3491-4ad3-8d0b-34567e32e313','ad814251-0805-46fa-a0b9-4b0f36475fc7',0,20,0,NULL,NULL),('aa1a96bf-f242-41e7-898d-913bb8648e94',NULL,'conditional-user-configured','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','570e8e7e-f9cb-43f7-ba0b-4ead40a9a874',0,10,0,NULL,NULL),('ac18ed5e-8d76-4f5e-b8ae-cded66a2f77d',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','18f7dbe3-b9e1-4bfe-b6e4-e0633333649b',2,30,1,'1f1049c5-502a-4d3c-9b73-c6ededd07b1c',NULL),('ac7d7ec1-2d0d-4285-872c-3d1edd9299a9',NULL,'federated-jwt','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','b329b136-1daa-4f76-97a6-9979c730a9ff',2,50,0,NULL,NULL),('af5c27a4-b614-45d9-8298-e735b1bde5da',NULL,'http-basic-authenticator','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','3a9f8f3f-3df2-4a0d-9cd0-9e55891d34ce',0,10,0,NULL,NULL),('b1c42f05-2a02-42a8-b4b7-af61d28e1c54',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','ad814251-0805-46fa-a0b9-4b0f36475fc7',1,40,1,'ca91350d-eaa1-4faf-8549-6b5ceb0191a1',NULL),('b5c12e5e-c4b6-4209-8d12-5322cab1d199',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','8f97c36b-7ae0-4da3-b602-f5aea0af980a',2,20,1,'05a83ce7-f691-44a6-b20c-2617220ef72c',NULL),('b710b3a7-5411-4dcb-b9f8-5f7ebabcb5c2',NULL,'auth-otp-form','84ab64b6-3491-4ad3-8d0b-34567e32e313','c1ccae56-2953-4330-8b76-7a7c5c06b1e9',2,30,0,NULL,NULL),('b828e96b-cdf0-4655-a0b2-ebcd89bf77dd',NULL,'client-x509','84ab64b6-3491-4ad3-8d0b-34567e32e313','f84dfc68-fb64-42d2-b465-813fb35926e5',2,40,0,NULL,NULL),('b8f2d7b7-73b6-49e9-84d0-4981dfa984e1',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','547594ad-3454-40a5-8f68-6b2b5bda7c85',1,20,1,'7dd4bd33-42b5-435c-8646-ea53a60c154c',NULL),('b91fa0a8-1163-44e7-86f8-1361dba32304',NULL,'docker-http-basic-authenticator','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','c27ea42c-a5ae-4cc9-a80b-130c19243ed0',0,10,0,NULL,NULL),('bd2dd6f0-142f-4b32-8771-030f47ac2fbe',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','94370c21-ce38-4c21-92ac-dec729416493',0,20,1,'bd6b69af-3043-4a92-bfc4-d88e6d4ce742',NULL),('c481c94e-9dc2-4755-8e3c-61d8bef59097',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','2be9e75e-2e8b-4d7b-baa4-a89f17b9fc0a',2,20,1,'94370c21-ce38-4c21-92ac-dec729416493',NULL),('c64f72a4-d668-4c24-b401-19096baa667a',NULL,'client-secret','84ab64b6-3491-4ad3-8d0b-34567e32e313','f84dfc68-fb64-42d2-b465-813fb35926e5',2,10,0,NULL,NULL),('d0fa46a9-970a-4981-addf-64a403baebff',NULL,'registration-user-creation','84ab64b6-3491-4ad3-8d0b-34567e32e313','e574065d-6406-45cd-8a66-ea5a8d017cc2',0,20,0,NULL,NULL),('d3d06a5b-8804-4b27-8db7-d25b5f5c387f',NULL,'conditional-credential','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','13bb4c05-3d45-4338-8c56-f861e6559b4f',0,20,0,NULL,'ff65052a-5720-49c7-b830-6be3b0bb7cae'),('d76c7bb9-b4ab-48ad-8239-494e3b3d9220',NULL,'client-x509','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','b329b136-1daa-4f76-97a6-9979c730a9ff',2,40,0,NULL,NULL),('d7f5645d-300a-47a4-badf-d778d6941f35',NULL,'idp-create-user-if-unique','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','2be9e75e-2e8b-4d7b-baa4-a89f17b9fc0a',2,10,0,NULL,'76c9e684-b500-4e7c-bbb7-f35b4dc527c6'),('d8871e91-7af0-40c2-bb38-32528d2a9230',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','36c56211-874f-41f2-91ba-b007c19d2386',1,20,1,'c1ccae56-2953-4330-8b76-7a7c5c06b1e9',NULL),('de7eb80d-8275-4042-8ee6-41ee296cda7b',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','6a37e0ec-0488-4e26-93eb-d404bc21b066',1,30,1,'9290daee-5dd3-4f6b-abdb-7b7f90fc9f8d',NULL),('e08337c4-c650-415b-aaa7-09835d17efee',NULL,'auth-cookie','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','18f7dbe3-b9e1-4bfe-b6e4-e0633333649b',2,10,0,NULL,NULL),('e216bad8-4e63-475d-94bb-ad7b7cea808b',NULL,'auth-username-password-form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','1f1049c5-502a-4d3c-9b73-c6ededd07b1c',0,10,0,NULL,NULL),('e35fe126-6996-4b21-bed4-5bcc1633b18b',NULL,'federated-jwt','84ab64b6-3491-4ad3-8d0b-34567e32e313','f84dfc68-fb64-42d2-b465-813fb35926e5',2,50,0,NULL,NULL),('e44a4de9-c222-43b1-b419-b74e0e574bac',NULL,'registration-terms-and-conditions','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5fe1bd83-3d24-4e10-9738-df170015c921',3,70,0,NULL,NULL),('eb8164cc-b452-496e-bf40-7a262d62460a',NULL,'organization','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','305caaa6-cd23-4801-8a44-340bee3de1f6',2,20,0,NULL,NULL),('eb930749-21fb-415c-821f-52a63065ff73',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','b4d48dee-1ddd-40bd-8c23-ee5a21e0d768',0,20,1,'8f97c36b-7ae0-4da3-b602-f5aea0af980a',NULL),('ed02e3c3-b418-4702-9cf3-d4b3f24bb270',NULL,'idp-confirm-link','84ab64b6-3491-4ad3-8d0b-34567e32e313','05a83ce7-f691-44a6-b20c-2617220ef72c',0,10,0,NULL,NULL),('edb5eebe-4b3f-4fea-930d-d7551b05a065',NULL,'webauthn-authenticator','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','70f5a9a3-23e9-48ac-979d-a6a1f2b2321d',3,40,0,NULL,NULL),('edd65df4-360c-4a60-a311-ce6b144802a4',NULL,'idp-email-verification','84ab64b6-3491-4ad3-8d0b-34567e32e313','f3325618-1492-489a-9b7c-7ebe0dd6f317',2,10,0,NULL,NULL),('f0ca1826-7329-41a8-9f17-605bbf734087',NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','f3325618-1492-489a-9b7c-7ebe0dd6f317',2,20,1,'36c56211-874f-41f2-91ba-b007c19d2386',NULL),('f557a47f-086e-4474-9ed8-7af806451120',NULL,'direct-grant-validate-otp','84ab64b6-3491-4ad3-8d0b-34567e32e313','9290daee-5dd3-4f6b-abdb-7b7f90fc9f8d',0,20,0,NULL,NULL),('f5f95f36-5e71-4704-ab66-3816ec5e8b1f',NULL,'reset-password','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','a4acbcfb-294f-462e-a9af-7066e899f78f',0,30,0,NULL,NULL),('f7426455-7104-4011-972c-5fbd609778e5',NULL,'conditional-user-configured','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','305caaa6-cd23-4801-8a44-340bee3de1f6',0,10,0,NULL,NULL),('f80d5db9-0567-4739-9d13-13ff59e9a615',NULL,'direct-grant-validate-username','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ace3e7b2-4f53-411f-8937-15206446ee27',0,10,0,NULL,NULL),('f9e231d6-fd12-4922-b212-683f6a68ba17',NULL,'client-secret','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','b329b136-1daa-4f76-97a6-9979c730a9ff',2,10,0,NULL,NULL),('fd20880d-0ec1-4515-ad77-32b6450ade5a',NULL,NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','a4acbcfb-294f-462e-a9af-7066e899f78f',1,40,1,'e305e857-a64c-47f6-a8c8-fd5fc3fd1b51',NULL);
/*!40000 ALTER TABLE `AUTHENTICATION_EXECUTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATION_FLOW`
--

DROP TABLE IF EXISTS `AUTHENTICATION_FLOW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATION_FLOW` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'basic-flow',
  `TOP_LEVEL` tinyint NOT NULL DEFAULT '0',
  `BUILT_IN` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IDX_AUTH_FLOW_REALM` (`REALM_ID`),
  CONSTRAINT `FK_AUTH_FLOW_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATION_FLOW`
--

LOCK TABLES `AUTHENTICATION_FLOW` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATION_FLOW` DISABLE KEYS */;
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('05a83ce7-f691-44a6-b20c-2617220ef72c','Handle Existing Account','Handle what to do if there is existing account with same email/username like authenticated identity provider','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('13bb4c05-3d45-4338-8c56-f861e6559b4f','Browser - Conditional 2FA','Flow to determine if any 2FA is required for the authentication','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('18f7dbe3-b9e1-4bfe-b6e4-e0633333649b','browser','Browser based authentication','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1),('1db10166-eef0-4dd0-80db-539916cd9bb5','Organization',NULL,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('1f1049c5-502a-4d3c-9b73-c6ededd07b1c','forms','Username, password, otp and other auth forms.','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('2171dcb5-2f36-468d-9620-002ac6875e4a','browser','Browser based authentication','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('2be9e75e-2e8b-4d7b-baa4-a89f17b9fc0a','User creation or linking','Flow for the existing/non-existing user alternatives','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('30023d6e-1e73-472d-a64f-ebac7b7225d4','registration','Registration flow','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('305caaa6-cd23-4801-8a44-340bee3de1f6','Browser - Conditional Organization','Flow to determine if the organization identity-first login is to be used','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('36c56211-874f-41f2-91ba-b007c19d2386','Verify Existing Account by Re-authentication','Reauthentication of existing account','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('37f96afe-b813-492c-85f9-6ac327b3cc7d','docker auth','Used by Docker clients to authenticate against the IDP','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('3a9f8f3f-3df2-4a0d-9cd0-9e55891d34ce','saml ecp','SAML ECP Profile Authentication Flow','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1),('42f88d19-f437-4c87-9852-b0d804c0237a','saml ecp','SAML ECP Profile Authentication Flow','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('547594ad-3454-40a5-8f68-6b2b5bda7c85','forms','Username, password, otp and other auth forms.','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('570e8e7e-f9cb-43f7-ba0b-4ead40a9a874','Direct Grant - Conditional OTP','Flow to determine if the OTP is required for the authentication','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('5fe1bd83-3d24-4e10-9738-df170015c921','registration form','Registration form','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','form-flow',0,1),('6a37e0ec-0488-4e26-93eb-d404bc21b066','direct grant','OpenID Connect Resource Owner Grant','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('70f5a9a3-23e9-48ac-979d-a6a1f2b2321d','First broker login - Conditional 2FA','Flow to determine if any 2FA is required for the authentication','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('7dd4bd33-42b5-435c-8646-ea53a60c154c','Browser - Conditional 2FA','Flow to determine if any 2FA is required for the authentication','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('8f97c36b-7ae0-4da3-b602-f5aea0af980a','User creation or linking','Flow for the existing/non-existing user alternatives','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('9277b8f3-ac0c-44fc-883d-ae764c53ca3e','registration','Registration flow','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1),('9290daee-5dd3-4f6b-abdb-7b7f90fc9f8d','Direct Grant - Conditional OTP','Flow to determine if the OTP is required for the authentication','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('94370c21-ce38-4c21-92ac-dec729416493','Handle Existing Account','Handle what to do if there is existing account with same email/username like authenticated identity provider','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('a4acbcfb-294f-462e-a9af-7066e899f78f','reset credentials','Reset credentials for a user if they forgot their password or something','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1),('ace3e7b2-4f53-411f-8937-15206446ee27','direct grant','OpenID Connect Resource Owner Grant','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1),('ad814251-0805-46fa-a0b9-4b0f36475fc7','reset credentials','Reset credentials for a user if they forgot their password or something','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('b329b136-1daa-4f76-97a6-9979c730a9ff','clients','Base authentication for clients','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','client-flow',1,1),('b4d48dee-1ddd-40bd-8c23-ee5a21e0d768','first broker login','Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',1,1),('bd6b69af-3043-4a92-bfc4-d88e6d4ce742','Account verification options','Method with which to verify the existing account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('c1ccae56-2953-4330-8b76-7a7c5c06b1e9','First broker login - Conditional 2FA','Flow to determine if any 2FA is required for the authentication','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('c27ea42c-a5ae-4cc9-a80b-130c19243ed0','docker auth','Used by Docker clients to authenticate against the IDP','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1),('c57bfc0d-426a-4394-952d-a97f085c5918','Verify Existing Account by Re-authentication','Reauthentication of existing account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('ca91350d-eaa1-4faf-8549-6b5ceb0191a1','Reset - Conditional OTP','Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('e305e857-a64c-47f6-a8c8-fd5fc3fd1b51','Reset - Conditional OTP','Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('e574065d-6406-45cd-8a66-ea5a8d017cc2','registration form','Registration form','84ab64b6-3491-4ad3-8d0b-34567e32e313','form-flow',0,1),('ef397a66-487e-4562-9e8d-713ef672e13c','First Broker Login - Conditional Organization','Flow to determine if the authenticator that adds organization members is to be used','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',0,1),('f3325618-1492-489a-9b7c-7ebe0dd6f317','Account verification options','Method with which to verify the existing account','84ab64b6-3491-4ad3-8d0b-34567e32e313','basic-flow',0,1),('f84dfc68-fb64-42d2-b465-813fb35926e5','clients','Base authentication for clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','client-flow',1,1),('fe9a8920-3135-4faf-bf53-430f105ca09b','first broker login','Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','basic-flow',1,1);
/*!40000 ALTER TABLE `AUTHENTICATION_FLOW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATOR_CONFIG`
--

DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATOR_CONFIG` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_AUTH_CONFIG_REALM` (`REALM_ID`),
  CONSTRAINT `FK_AUTH_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATOR_CONFIG`
--

LOCK TABLES `AUTHENTICATOR_CONFIG` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG` DISABLE KEYS */;
INSERT INTO `AUTHENTICATOR_CONFIG` VALUES ('05e9eb7e-9c64-4dc5-ac16-20693c64d671','review profile config','84ab64b6-3491-4ad3-8d0b-34567e32e313'),('614f5476-7533-4a48-9901-b7b191800459','review profile config','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd'),('72b12f01-3dfd-44cf-bfe1-0cbd888d3d4d','browser-conditional-credential','84ab64b6-3491-4ad3-8d0b-34567e32e313'),('76c9e684-b500-4e7c-bbb7-f35b4dc527c6','create unique user config','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd'),('8efd7b38-2e9c-4dcf-8f72-1f1345af5677','first-broker-login-conditional-credential','84ab64b6-3491-4ad3-8d0b-34567e32e313'),('a2a3f6e3-2a54-45d3-896c-7778b5244d20','first-broker-login-conditional-credential','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd'),('a5b1cb98-796e-4a1d-b90d-20d2374f600c','create unique user config','84ab64b6-3491-4ad3-8d0b-34567e32e313'),('ff65052a-5720-49c7-b830-6be3b0bb7cae','browser-conditional-credential','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd');
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATOR_CONFIG_ENTRY`
--

DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG_ENTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATOR_CONFIG_ENTRY` (
  `AUTHENTICATOR_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`AUTHENTICATOR_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATOR_CONFIG_ENTRY`
--

LOCK TABLES `AUTHENTICATOR_CONFIG_ENTRY` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG_ENTRY` DISABLE KEYS */;
INSERT INTO `AUTHENTICATOR_CONFIG_ENTRY` VALUES ('05e9eb7e-9c64-4dc5-ac16-20693c64d671','missing','update.profile.on.first.login'),('614f5476-7533-4a48-9901-b7b191800459','missing','update.profile.on.first.login'),('72b12f01-3dfd-44cf-bfe1-0cbd888d3d4d','webauthn-passwordless','credentials'),('76c9e684-b500-4e7c-bbb7-f35b4dc527c6','false','require.password.update.after.registration'),('8efd7b38-2e9c-4dcf-8f72-1f1345af5677','webauthn-passwordless','credentials'),('a2a3f6e3-2a54-45d3-896c-7778b5244d20','webauthn-passwordless','credentials'),('a5b1cb98-796e-4a1d-b90d-20d2374f600c','false','require.password.update.after.registration'),('ff65052a-5720-49c7-b830-6be3b0bb7cae','webauthn-passwordless','credentials');
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG_ENTRY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH_SESSION`
--

DROP TABLE IF EXISTS `AUTH_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH_SESSION` (
  `ROOT_AUTH_SESSION_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TAB_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_UUID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TIMESTAMP` bigint DEFAULT NULL,
  `VERSION` int DEFAULT NULL,
  `REDIRECT_URI` text COLLATE utf8mb4_unicode_ci,
  `ACTION` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROTOCOL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_SCOPES` text COLLATE utf8mb4_unicode_ci,
  `EXECUTION_STATUS` text COLLATE utf8mb4_unicode_ci,
  `CLIENT_NOTES` text COLLATE utf8mb4_unicode_ci,
  `AUTH_NOTES` text COLLATE utf8mb4_unicode_ci,
  `REQUIRED_ACTIONS` text COLLATE utf8mb4_unicode_ci,
  `USER_SESSION_NOTES` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`ROOT_AUTH_SESSION_ID`,`TAB_ID`),
  CONSTRAINT `FK_AUTH_SESSION_ROOT` FOREIGN KEY (`ROOT_AUTH_SESSION_ID`) REFERENCES `ROOT_AUTH_SESSION` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH_SESSION`
--

LOCK TABLES `AUTH_SESSION` WRITE;
/*!40000 ALTER TABLE `AUTH_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BROKER_LINK`
--

DROP TABLE IF EXISTS `BROKER_LINK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BROKER_LINK` (
  `IDENTITY_PROVIDER` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `BROKER_USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BROKER_USERNAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TOKEN` text COLLATE utf8mb4_unicode_ci,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`,`USER_ID`),
  KEY `IDX_BROKER_LINK_USER_ID` (`USER_ID`),
  KEY `IDX_BROKER_LINK_IDENTITY_PROVIDER` (`REALM_ID`,`IDENTITY_PROVIDER`,`BROKER_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BROKER_LINK`
--

LOCK TABLES `BROKER_LINK` WRITE;
/*!40000 ALTER TABLE `BROKER_LINK` DISABLE KEYS */;
/*!40000 ALTER TABLE `BROKER_LINK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT`
--

DROP TABLE IF EXISTS `CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENABLED` tinyint NOT NULL DEFAULT '0',
  `FULL_SCOPE_ALLOWED` tinyint NOT NULL DEFAULT '0',
  `CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NOT_BEFORE` int DEFAULT NULL,
  `PUBLIC_CLIENT` tinyint NOT NULL DEFAULT '0',
  `SECRET` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BASE_URL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BEARER_ONLY` tinyint NOT NULL DEFAULT '0',
  `MANAGEMENT_URL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SURROGATE_AUTH_REQUIRED` tinyint NOT NULL DEFAULT '0',
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROTOCOL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NODE_REREG_TIMEOUT` int DEFAULT '0',
  `FRONTCHANNEL_LOGOUT` tinyint NOT NULL DEFAULT '0',
  `CONSENT_REQUIRED` tinyint NOT NULL DEFAULT '0',
  `NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `SERVICE_ACCOUNTS_ENABLED` tinyint NOT NULL DEFAULT '0',
  `CLIENT_AUTHENTICATOR_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ROOT_URL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REGISTRATION_TOKEN` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `STANDARD_FLOW_ENABLED` tinyint NOT NULL DEFAULT '1',
  `IMPLICIT_FLOW_ENABLED` tinyint NOT NULL DEFAULT '0',
  `DIRECT_ACCESS_GRANTS_ENABLED` tinyint NOT NULL DEFAULT '0',
  `ALWAYS_DISPLAY_IN_CONSOLE` tinyint NOT NULL DEFAULT '0',
  `CREATED_TIMESTAMP` bigint DEFAULT NULL,
  `LAST_MODIFIED_TIMESTAMP` bigint DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_B71CJLBENV945RB6GCON438AT` (`REALM_ID`,`CLIENT_ID`),
  KEY `IDX_CLIENT_ID` (`CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT`
--

LOCK TABLES `CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT` VALUES ('012ee43d-aafd-493e-8a05-55fb09b91cd0',1,0,'broker',0,0,'qXtFXreEAwdvTm54ukQ8VOm8Atf2hDlgyyshrb6NB5WVV782px8dLfmUS58gLYRNEbOAweP2VK21mj6FwINhMb',NULL,1,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',0,0,0,'${client_broker}',0,'client-secret',NULL,NULL,NULL,1,0,0,0,1789954029061,1789954029099),('1f0e8266-2a00-4c51-abc1-7a0b09582410',1,1,'swagger-client',0,1,NULL,'/videolocadora/swagger-ui/index.html',0,'',0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',-1,1,0,'swagger-client',0,'client-secret','http://localhost:8080','',NULL,1,0,1,0,1789954029137,1789954029165),('2524ca06-c64e-4850-b4e5-af745f459add',1,1,'security-admin-console',0,1,NULL,'/admin/video-locadora/console/',0,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',0,0,0,'${client_security-admin-console}',0,'client-secret','${authAdminUrl}',NULL,NULL,1,0,0,0,1789954029111,1789954029148),('39076246-ac23-4c54-b55d-fefb0ab17939',1,0,'video-locadora-realm',0,0,NULL,NULL,1,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,0,0,0,'video-locadora Realm',0,'client-secret',NULL,NULL,NULL,1,0,0,0,1789954028751,1789954028757),('47b2e11a-979b-4582-a501-4551efac3954',1,0,'broker',0,0,NULL,NULL,1,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313','openid-connect',0,0,0,'${client_broker}',0,'client-secret',NULL,NULL,NULL,1,0,0,0,1789954027970,1789954027978),('5ba1d38b-7896-475c-a275-f8b0be01b81d',1,0,'account-console',0,1,NULL,'/realms/master/account/',0,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313','openid-connect',0,0,0,'${client_account-console}',0,'client-secret','${authBaseUrl}',NULL,NULL,1,0,0,0,1789954027961,1789954027965),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,0,'account',0,1,NULL,'/realms/master/account/',0,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313','openid-connect',0,0,0,'${client_account}',0,'client-secret','${authBaseUrl}',NULL,NULL,1,0,0,0,1789954027935,1789954027946),('629abc42-f3c2-47d5-8e7b-e6a61818e495',1,0,'account-console',0,1,NULL,'/realms/video-locadora/account/',0,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',0,0,0,'${client_account-console}',0,'client-secret','${authBaseUrl}',NULL,NULL,1,0,0,0,1789954028985,1789954029037),('62c26143-ea24-4ed0-aac2-7b01627a62c7',1,1,'bff-client',0,0,'bff-client-secret-change-me',NULL,0,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',-1,0,0,'bff-client',0,'client-secret',NULL,NULL,NULL,1,0,0,0,1792360074736,1792360074803),('82b7a479-742d-4ea5-a042-d9b286560c27',1,0,'realm-management',0,0,'i0tFZ1WC9HOxixQwKyPht8oDdBJSyoD4I8Hls5hEEuvXrqlUSc49QY1ezT6fqYOIYOhVycNptuuOIXSebUV91w',NULL,1,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',0,0,0,'${client_realm-management}',0,'client-secret',NULL,NULL,NULL,1,0,0,0,1789954029087,1789954029123),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df',1,1,'admin-cli',0,1,NULL,NULL,0,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',0,0,0,'${client_admin-cli}',0,'client-secret',NULL,NULL,NULL,0,0,1,0,1789954029021,1789954029074),('c1e0cfff-9220-423f-9320-c191c13802de',1,1,'security-admin-console',0,1,NULL,'/admin/master/console/',0,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313','openid-connect',0,0,0,'${client_security-admin-console}',0,'client-secret','${authAdminUrl}',NULL,NULL,1,0,0,0,1789954027984,1789954027991),('f303bf4d-7b07-4a58-85b6-455d24269265',1,0,'account',0,1,NULL,'/realms/video-locadora/account/',0,NULL,0,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','openid-connect',0,0,0,'${client_account}',0,'client-secret','${authBaseUrl}',NULL,NULL,1,0,0,0,1789954028934,1789954029002),('fa51df26-542b-4903-b522-58f8ee6800ae',1,1,'admin-cli',0,1,NULL,NULL,0,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313','openid-connect',0,0,0,'${client_admin-cli}',0,'client-secret',NULL,NULL,NULL,0,0,1,0,1789954027997,1789954028003),('fead954d-b832-4e09-a767-93f6ef398331',1,0,'master-realm',0,0,NULL,NULL,1,NULL,0,'84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,0,0,0,'master Realm',0,'client-secret',NULL,NULL,NULL,1,0,0,0,1789954027873,1789954027876);
/*!40000 ALTER TABLE `CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_ATTRIBUTES`
--

DROP TABLE IF EXISTS `CLIENT_ATTRIBUTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_ATTRIBUTES` (
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`CLIENT_ID`,`NAME`),
  KEY `IDX_CLIENT_ATT_BY_NAME_VALUE` (`NAME`,`VALUE`(255)),
  CONSTRAINT `FK3C47C64BEACCA966` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_ATTRIBUTES`
--

LOCK TABLES `CLIENT_ATTRIBUTES` WRITE;
/*!40000 ALTER TABLE `CLIENT_ATTRIBUTES` DISABLE KEYS */;
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('012ee43d-aafd-493e-8a05-55fb09b91cd0','client.secret.creation.time','1789954029'),('012ee43d-aafd-493e-8a05-55fb09b91cd0','post.logout.redirect.uris','+'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','backchannel.logout.revoke.offline.tokens','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','backchannel.logout.session.required','true'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','display.on.consent.screen','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','dpop.bound.access.tokens','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','frontchannel.logout.session.required','true'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','logout.confirmation.enabled','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','oauth2.device.authorization.grant.enabled','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','oauth2.jwt.authorization.grant.enabled','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','oidc.ciba.grant.enabled','false'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','post.logout.redirect.uris','+'),('1f0e8266-2a00-4c51-abc1-7a0b09582410','standard.token.exchange.enabled','false'),('2524ca06-c64e-4850-b4e5-af745f459add','client.use.lightweight.access.token.enabled','true'),('2524ca06-c64e-4850-b4e5-af745f459add','pkce.code.challenge.method','S256'),('2524ca06-c64e-4850-b4e5-af745f459add','post.logout.redirect.uris','+'),('5ba1d38b-7896-475c-a275-f8b0be01b81d','pkce.code.challenge.method','S256'),('5ba1d38b-7896-475c-a275-f8b0be01b81d','post.logout.redirect.uris','+'),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','post.logout.redirect.uris','+'),('629abc42-f3c2-47d5-8e7b-e6a61818e495','pkce.code.challenge.method','S256'),('629abc42-f3c2-47d5-8e7b-e6a61818e495','post.logout.redirect.uris','+'),('62c26143-ea24-4ed0-aac2-7b01627a62c7','backchannel.logout.revoke.offline.tokens','false'),('62c26143-ea24-4ed0-aac2-7b01627a62c7','backchannel.logout.session.required','true'),('82b7a479-742d-4ea5-a042-d9b286560c27','client.secret.creation.time','1789954029'),('82b7a479-742d-4ea5-a042-d9b286560c27','post.logout.redirect.uris','+'),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','client.use.lightweight.access.token.enabled','true'),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','post.logout.redirect.uris','+'),('c1e0cfff-9220-423f-9320-c191c13802de','client.use.lightweight.access.token.enabled','true'),('c1e0cfff-9220-423f-9320-c191c13802de','pkce.code.challenge.method','S256'),('c1e0cfff-9220-423f-9320-c191c13802de','post.logout.redirect.uris','+'),('f303bf4d-7b07-4a58-85b6-455d24269265','post.logout.redirect.uris','+'),('fa51df26-542b-4903-b522-58f8ee6800ae','client.use.lightweight.access.token.enabled','true');
/*!40000 ALTER TABLE `CLIENT_ATTRIBUTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_AUTH_FLOW_BINDINGS`
--

DROP TABLE IF EXISTS `CLIENT_AUTH_FLOW_BINDINGS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_AUTH_FLOW_BINDINGS` (
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FLOW_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BINDING_NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`BINDING_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_AUTH_FLOW_BINDINGS`
--

LOCK TABLES `CLIENT_AUTH_FLOW_BINDINGS` WRITE;
/*!40000 ALTER TABLE `CLIENT_AUTH_FLOW_BINDINGS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_AUTH_FLOW_BINDINGS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_INITIAL_ACCESS`
--

DROP TABLE IF EXISTS `CLIENT_INITIAL_ACCESS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_INITIAL_ACCESS` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TIMESTAMP` int DEFAULT NULL,
  `EXPIRATION` int DEFAULT NULL,
  `COUNT` int DEFAULT NULL,
  `REMAINING_COUNT` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_CLIENT_INIT_ACC_REALM` (`REALM_ID`),
  CONSTRAINT `FK_CLIENT_INIT_ACC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_INITIAL_ACCESS`
--

LOCK TABLES `CLIENT_INITIAL_ACCESS` WRITE;
/*!40000 ALTER TABLE `CLIENT_INITIAL_ACCESS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_INITIAL_ACCESS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_NODE_REGISTRATIONS`
--

DROP TABLE IF EXISTS `CLIENT_NODE_REGISTRATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_NODE_REGISTRATIONS` (
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` int DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`NAME`),
  CONSTRAINT `FK4129723BA992F594` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_NODE_REGISTRATIONS`
--

LOCK TABLES `CLIENT_NODE_REGISTRATIONS` WRITE;
/*!40000 ALTER TABLE `CLIENT_NODE_REGISTRATIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_NODE_REGISTRATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `PROTOCOL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_CLI_SCOPE` (`REALM_ID`,`NAME`),
  KEY `IDX_REALM_CLSCOPE` (`REALM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE`
--

LOCK TABLES `CLIENT_SCOPE` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE` VALUES ('03354559-2779-4844-808b-30f9fb5ac62c','role_list','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','SAML role list','saml'),('04c239dd-9551-429c-8449-9a2c2af1fbdb','address','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect built-in scope: address','openid-connect'),('0c7363ad-14dd-4251-b417-320066960b32','roles','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect scope for add user roles to the access token','openid-connect'),('16653460-af7b-4d28-ab0b-96c6fb09fe1a','address','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect built-in scope: address','openid-connect'),('1a80d43f-6fae-498e-99ec-9338390ea212','organization','84ab64b6-3491-4ad3-8d0b-34567e32e313','Additional claims about the organization a subject belongs to','openid-connect'),('1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea','email','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect built-in scope: email','openid-connect'),('200dfbf0-3014-41f3-bbbd-f5be3f86cd42','saml_organization','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','Organization Membership','saml'),('219699e4-526e-45e2-9b0c-d40f3b0256b3','email','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect built-in scope: email','openid-connect'),('2adeb05e-a6e4-43b5-ae58-51768990b844','web-origins','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect scope for add allowed web origins to the access token','openid-connect'),('2c753b35-118a-48d9-ab0f-8d33a8b5b0bd','service_account','84ab64b6-3491-4ad3-8d0b-34567e32e313','Specific scope for a client enabled for service accounts','openid-connect'),('363951aa-fdf3-4c95-8ec2-a380dc6a56c1','basic','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect scope for add all basic claims to the token','openid-connect'),('3d201784-6f27-40b2-ab39-08b4f5521031','phone','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect built-in scope: phone','openid-connect'),('3e4c76ce-54c0-48ad-80a0-3e59fd82b374','role_list','84ab64b6-3491-4ad3-8d0b-34567e32e313','SAML role list','saml'),('44025836-5c4a-4003-b9da-3cc785d53ef1','web-origins','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect scope for add allowed web origins to the access token','openid-connect'),('45184368-98fe-4bc6-acb6-fe4a82a66cc7','saml_organization','84ab64b6-3491-4ad3-8d0b-34567e32e313','Organization Membership','saml'),('54c528ba-746e-47f4-917f-9ad4b710b011','offline_access','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect built-in scope: offline_access','openid-connect'),('651c49f7-028b-456a-b4ae-9aef93eb1cc6','profile','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect built-in scope: profile','openid-connect'),('65212767-9df0-4e28-8c33-00546d81cf03','offline_access','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect built-in scope: offline_access','openid-connect'),('78e4132d-6e9c-429c-82b1-0bb738768f35','organization','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','Additional claims about the organization a subject belongs to','openid-connect'),('7d2e2940-2dd4-4bca-9c12-9ea859876e55','microprofile-jwt','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','Microprofile - JWT built-in scope','openid-connect'),('8d331b20-a42d-420b-9b2c-2caafb22ca64','service_account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','Specific scope for a client enabled for service accounts','openid-connect'),('cfaea429-dbd7-4700-81ea-3fc338cb3f77','AuthnContextClassRef','84ab64b6-3491-4ad3-8d0b-34567e32e313','AuthnContextClassRef Level of Authentiation','saml'),('d36a6820-93f8-4257-8cb0-f797106b49b1','acr','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect scope for add acr (authentication context class reference) to the token','openid-connect'),('de4d5fc0-a083-4965-9342-560b44260320','AuthnContextClassRef','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','AuthnContextClassRef Level of Authentiation','saml'),('e16864f1-ced5-4c30-bb89-bf358e8b1973','microprofile-jwt','84ab64b6-3491-4ad3-8d0b-34567e32e313','Microprofile - JWT built-in scope','openid-connect'),('ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81','basic','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect scope for add all basic claims to the token','openid-connect'),('f26107a8-8445-47e5-be56-a9c62d0acfd9','acr','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect scope for add acr (authentication context class reference) to the token','openid-connect'),('f696bde9-1154-4d45-b708-7fba87b83fbd','roles','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','OpenID Connect scope for add user roles to the access token','openid-connect'),('f9b9b4bf-db82-447f-b04a-8eadb2996ee6','phone','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect built-in scope: phone','openid-connect'),('ff30dceb-8390-442d-b3ba-58fdf6e9d253','profile','84ab64b6-3491-4ad3-8d0b-34567e32e313','OpenID Connect built-in scope: profile','openid-connect');
/*!40000 ALTER TABLE `CLIENT_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE_ATTRIBUTES`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE_ATTRIBUTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE_ATTRIBUTES` (
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`,`NAME`),
  KEY `IDX_CLSCOPE_ATTRS` (`SCOPE_ID`),
  CONSTRAINT `FK_CL_SCOPE_ATTR_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE_ATTRIBUTES`
--

LOCK TABLES `CLIENT_SCOPE_ATTRIBUTES` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE_ATTRIBUTES` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('03354559-2779-4844-808b-30f9fb5ac62c','${samlRoleListScopeConsentText}','consent.screen.text'),('03354559-2779-4844-808b-30f9fb5ac62c','true','display.on.consent.screen'),('04c239dd-9551-429c-8449-9a2c2af1fbdb','${addressScopeConsentText}','consent.screen.text'),('04c239dd-9551-429c-8449-9a2c2af1fbdb','true','display.on.consent.screen'),('04c239dd-9551-429c-8449-9a2c2af1fbdb','true','include.in.token.scope'),('0c7363ad-14dd-4251-b417-320066960b32','${rolesScopeConsentText}','consent.screen.text'),('0c7363ad-14dd-4251-b417-320066960b32','true','display.on.consent.screen'),('0c7363ad-14dd-4251-b417-320066960b32','false','include.in.token.scope'),('16653460-af7b-4d28-ab0b-96c6fb09fe1a','${addressScopeConsentText}','consent.screen.text'),('16653460-af7b-4d28-ab0b-96c6fb09fe1a','true','display.on.consent.screen'),('16653460-af7b-4d28-ab0b-96c6fb09fe1a','true','include.in.token.scope'),('1a80d43f-6fae-498e-99ec-9338390ea212','${organizationScopeConsentText}','consent.screen.text'),('1a80d43f-6fae-498e-99ec-9338390ea212','true','display.on.consent.screen'),('1a80d43f-6fae-498e-99ec-9338390ea212','true','include.in.token.scope'),('1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea','${emailScopeConsentText}','consent.screen.text'),('1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea','true','display.on.consent.screen'),('1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea','true','include.in.token.scope'),('200dfbf0-3014-41f3-bbbd-f5be3f86cd42','false','display.on.consent.screen'),('219699e4-526e-45e2-9b0c-d40f3b0256b3','${emailScopeConsentText}','consent.screen.text'),('219699e4-526e-45e2-9b0c-d40f3b0256b3','true','display.on.consent.screen'),('219699e4-526e-45e2-9b0c-d40f3b0256b3','true','include.in.token.scope'),('2adeb05e-a6e4-43b5-ae58-51768990b844','','consent.screen.text'),('2adeb05e-a6e4-43b5-ae58-51768990b844','false','display.on.consent.screen'),('2adeb05e-a6e4-43b5-ae58-51768990b844','false','include.in.token.scope'),('2c753b35-118a-48d9-ab0f-8d33a8b5b0bd','false','display.on.consent.screen'),('2c753b35-118a-48d9-ab0f-8d33a8b5b0bd','false','include.in.token.scope'),('363951aa-fdf3-4c95-8ec2-a380dc6a56c1','false','display.on.consent.screen'),('363951aa-fdf3-4c95-8ec2-a380dc6a56c1','false','include.in.token.scope'),('3d201784-6f27-40b2-ab39-08b4f5521031','${phoneScopeConsentText}','consent.screen.text'),('3d201784-6f27-40b2-ab39-08b4f5521031','true','display.on.consent.screen'),('3d201784-6f27-40b2-ab39-08b4f5521031','true','include.in.token.scope'),('3e4c76ce-54c0-48ad-80a0-3e59fd82b374','${samlRoleListScopeConsentText}','consent.screen.text'),('3e4c76ce-54c0-48ad-80a0-3e59fd82b374','true','display.on.consent.screen'),('44025836-5c4a-4003-b9da-3cc785d53ef1','','consent.screen.text'),('44025836-5c4a-4003-b9da-3cc785d53ef1','false','display.on.consent.screen'),('44025836-5c4a-4003-b9da-3cc785d53ef1','false','include.in.token.scope'),('45184368-98fe-4bc6-acb6-fe4a82a66cc7','false','display.on.consent.screen'),('54c528ba-746e-47f4-917f-9ad4b710b011','${offlineAccessScopeConsentText}','consent.screen.text'),('54c528ba-746e-47f4-917f-9ad4b710b011','true','display.on.consent.screen'),('651c49f7-028b-456a-b4ae-9aef93eb1cc6','${profileScopeConsentText}','consent.screen.text'),('651c49f7-028b-456a-b4ae-9aef93eb1cc6','true','display.on.consent.screen'),('651c49f7-028b-456a-b4ae-9aef93eb1cc6','true','include.in.token.scope'),('65212767-9df0-4e28-8c33-00546d81cf03','${offlineAccessScopeConsentText}','consent.screen.text'),('65212767-9df0-4e28-8c33-00546d81cf03','true','display.on.consent.screen'),('78e4132d-6e9c-429c-82b1-0bb738768f35','${organizationScopeConsentText}','consent.screen.text'),('78e4132d-6e9c-429c-82b1-0bb738768f35','true','display.on.consent.screen'),('78e4132d-6e9c-429c-82b1-0bb738768f35','true','include.in.token.scope'),('7d2e2940-2dd4-4bca-9c12-9ea859876e55','false','display.on.consent.screen'),('7d2e2940-2dd4-4bca-9c12-9ea859876e55','true','include.in.token.scope'),('8d331b20-a42d-420b-9b2c-2caafb22ca64','false','display.on.consent.screen'),('8d331b20-a42d-420b-9b2c-2caafb22ca64','false','include.in.token.scope'),('d36a6820-93f8-4257-8cb0-f797106b49b1','false','display.on.consent.screen'),('d36a6820-93f8-4257-8cb0-f797106b49b1','false','include.in.token.scope'),('e16864f1-ced5-4c30-bb89-bf358e8b1973','false','display.on.consent.screen'),('e16864f1-ced5-4c30-bb89-bf358e8b1973','true','include.in.token.scope'),('ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81','false','display.on.consent.screen'),('ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81','false','include.in.token.scope'),('f26107a8-8445-47e5-be56-a9c62d0acfd9','false','display.on.consent.screen'),('f26107a8-8445-47e5-be56-a9c62d0acfd9','false','include.in.token.scope'),('f696bde9-1154-4d45-b708-7fba87b83fbd','${rolesScopeConsentText}','consent.screen.text'),('f696bde9-1154-4d45-b708-7fba87b83fbd','true','display.on.consent.screen'),('f696bde9-1154-4d45-b708-7fba87b83fbd','false','include.in.token.scope'),('f9b9b4bf-db82-447f-b04a-8eadb2996ee6','${phoneScopeConsentText}','consent.screen.text'),('f9b9b4bf-db82-447f-b04a-8eadb2996ee6','true','display.on.consent.screen'),('f9b9b4bf-db82-447f-b04a-8eadb2996ee6','true','include.in.token.scope'),('ff30dceb-8390-442d-b3ba-58fdf6e9d253','${profileScopeConsentText}','consent.screen.text'),('ff30dceb-8390-442d-b3ba-58fdf6e9d253','true','display.on.consent.screen'),('ff30dceb-8390-442d-b3ba-58fdf6e9d253','true','include.in.token.scope');
/*!40000 ALTER TABLE `CLIENT_SCOPE_ATTRIBUTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE_CLIENT`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE_CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE_CLIENT` (
  `CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DEFAULT_SCOPE` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`CLIENT_ID`,`SCOPE_ID`),
  KEY `IDX_CLSCOPE_CL` (`CLIENT_ID`),
  KEY `IDX_CL_CLSCOPE` (`SCOPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE_CLIENT`
--

LOCK TABLES `CLIENT_SCOPE_CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE_CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('012ee43d-aafd-493e-8a05-55fb09b91cd0','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('012ee43d-aafd-493e-8a05-55fb09b91cd0','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('012ee43d-aafd-493e-8a05-55fb09b91cd0','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('012ee43d-aafd-493e-8a05-55fb09b91cd0','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('012ee43d-aafd-493e-8a05-55fb09b91cd0','3d201784-6f27-40b2-ab39-08b4f5521031',0),('012ee43d-aafd-493e-8a05-55fb09b91cd0','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('012ee43d-aafd-493e-8a05-55fb09b91cd0','65212767-9df0-4e28-8c33-00546d81cf03',0),('012ee43d-aafd-493e-8a05-55fb09b91cd0','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('012ee43d-aafd-493e-8a05-55fb09b91cd0','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('012ee43d-aafd-493e-8a05-55fb09b91cd0','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('012ee43d-aafd-493e-8a05-55fb09b91cd0','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('1f0e8266-2a00-4c51-abc1-7a0b09582410','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('1f0e8266-2a00-4c51-abc1-7a0b09582410','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('1f0e8266-2a00-4c51-abc1-7a0b09582410','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('1f0e8266-2a00-4c51-abc1-7a0b09582410','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('1f0e8266-2a00-4c51-abc1-7a0b09582410','3d201784-6f27-40b2-ab39-08b4f5521031',0),('1f0e8266-2a00-4c51-abc1-7a0b09582410','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('1f0e8266-2a00-4c51-abc1-7a0b09582410','65212767-9df0-4e28-8c33-00546d81cf03',0),('1f0e8266-2a00-4c51-abc1-7a0b09582410','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('1f0e8266-2a00-4c51-abc1-7a0b09582410','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('1f0e8266-2a00-4c51-abc1-7a0b09582410','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('1f0e8266-2a00-4c51-abc1-7a0b09582410','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('2524ca06-c64e-4850-b4e5-af745f459add','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('2524ca06-c64e-4850-b4e5-af745f459add','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('2524ca06-c64e-4850-b4e5-af745f459add','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('2524ca06-c64e-4850-b4e5-af745f459add','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('2524ca06-c64e-4850-b4e5-af745f459add','3d201784-6f27-40b2-ab39-08b4f5521031',0),('2524ca06-c64e-4850-b4e5-af745f459add','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('2524ca06-c64e-4850-b4e5-af745f459add','65212767-9df0-4e28-8c33-00546d81cf03',0),('2524ca06-c64e-4850-b4e5-af745f459add','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('2524ca06-c64e-4850-b4e5-af745f459add','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('2524ca06-c64e-4850-b4e5-af745f459add','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('2524ca06-c64e-4850-b4e5-af745f459add','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('47b2e11a-979b-4582-a501-4551efac3954','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('47b2e11a-979b-4582-a501-4551efac3954','0c7363ad-14dd-4251-b417-320066960b32',1),('47b2e11a-979b-4582-a501-4551efac3954','1a80d43f-6fae-498e-99ec-9338390ea212',0),('47b2e11a-979b-4582-a501-4551efac3954','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('47b2e11a-979b-4582-a501-4551efac3954','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('47b2e11a-979b-4582-a501-4551efac3954','54c528ba-746e-47f4-917f-9ad4b710b011',0),('47b2e11a-979b-4582-a501-4551efac3954','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('47b2e11a-979b-4582-a501-4551efac3954','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('47b2e11a-979b-4582-a501-4551efac3954','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('47b2e11a-979b-4582-a501-4551efac3954','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('47b2e11a-979b-4582-a501-4551efac3954','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1),('5ba1d38b-7896-475c-a275-f8b0be01b81d','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('5ba1d38b-7896-475c-a275-f8b0be01b81d','0c7363ad-14dd-4251-b417-320066960b32',1),('5ba1d38b-7896-475c-a275-f8b0be01b81d','1a80d43f-6fae-498e-99ec-9338390ea212',0),('5ba1d38b-7896-475c-a275-f8b0be01b81d','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('5ba1d38b-7896-475c-a275-f8b0be01b81d','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('5ba1d38b-7896-475c-a275-f8b0be01b81d','54c528ba-746e-47f4-917f-9ad4b710b011',0),('5ba1d38b-7896-475c-a275-f8b0be01b81d','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('5ba1d38b-7896-475c-a275-f8b0be01b81d','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('5ba1d38b-7896-475c-a275-f8b0be01b81d','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('5ba1d38b-7896-475c-a275-f8b0be01b81d','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('5ba1d38b-7896-475c-a275-f8b0be01b81d','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','0c7363ad-14dd-4251-b417-320066960b32',1),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','1a80d43f-6fae-498e-99ec-9338390ea212',0),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','54c528ba-746e-47f4-917f-9ad4b710b011',0),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1),('629abc42-f3c2-47d5-8e7b-e6a61818e495','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('629abc42-f3c2-47d5-8e7b-e6a61818e495','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('629abc42-f3c2-47d5-8e7b-e6a61818e495','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('629abc42-f3c2-47d5-8e7b-e6a61818e495','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('629abc42-f3c2-47d5-8e7b-e6a61818e495','3d201784-6f27-40b2-ab39-08b4f5521031',0),('629abc42-f3c2-47d5-8e7b-e6a61818e495','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('629abc42-f3c2-47d5-8e7b-e6a61818e495','65212767-9df0-4e28-8c33-00546d81cf03',0),('629abc42-f3c2-47d5-8e7b-e6a61818e495','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('629abc42-f3c2-47d5-8e7b-e6a61818e495','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('629abc42-f3c2-47d5-8e7b-e6a61818e495','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('629abc42-f3c2-47d5-8e7b-e6a61818e495','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('62c26143-ea24-4ed0-aac2-7b01627a62c7','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('62c26143-ea24-4ed0-aac2-7b01627a62c7','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('62c26143-ea24-4ed0-aac2-7b01627a62c7','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('62c26143-ea24-4ed0-aac2-7b01627a62c7','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('62c26143-ea24-4ed0-aac2-7b01627a62c7','3d201784-6f27-40b2-ab39-08b4f5521031',0),('62c26143-ea24-4ed0-aac2-7b01627a62c7','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('62c26143-ea24-4ed0-aac2-7b01627a62c7','65212767-9df0-4e28-8c33-00546d81cf03',0),('62c26143-ea24-4ed0-aac2-7b01627a62c7','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('62c26143-ea24-4ed0-aac2-7b01627a62c7','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('62c26143-ea24-4ed0-aac2-7b01627a62c7','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('62c26143-ea24-4ed0-aac2-7b01627a62c7','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('82b7a479-742d-4ea5-a042-d9b286560c27','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('82b7a479-742d-4ea5-a042-d9b286560c27','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('82b7a479-742d-4ea5-a042-d9b286560c27','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('82b7a479-742d-4ea5-a042-d9b286560c27','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('82b7a479-742d-4ea5-a042-d9b286560c27','3d201784-6f27-40b2-ab39-08b4f5521031',0),('82b7a479-742d-4ea5-a042-d9b286560c27','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('82b7a479-742d-4ea5-a042-d9b286560c27','65212767-9df0-4e28-8c33-00546d81cf03',0),('82b7a479-742d-4ea5-a042-d9b286560c27','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('82b7a479-742d-4ea5-a042-d9b286560c27','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('82b7a479-742d-4ea5-a042-d9b286560c27','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('82b7a479-742d-4ea5-a042-d9b286560c27','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','3d201784-6f27-40b2-ab39-08b4f5521031',0),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','65212767-9df0-4e28-8c33-00546d81cf03',0),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('a4cb2ae3-c55c-4d05-a869-6d7a4bc6a8df','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('c1e0cfff-9220-423f-9320-c191c13802de','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('c1e0cfff-9220-423f-9320-c191c13802de','0c7363ad-14dd-4251-b417-320066960b32',1),('c1e0cfff-9220-423f-9320-c191c13802de','1a80d43f-6fae-498e-99ec-9338390ea212',0),('c1e0cfff-9220-423f-9320-c191c13802de','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('c1e0cfff-9220-423f-9320-c191c13802de','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('c1e0cfff-9220-423f-9320-c191c13802de','54c528ba-746e-47f4-917f-9ad4b710b011',0),('c1e0cfff-9220-423f-9320-c191c13802de','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('c1e0cfff-9220-423f-9320-c191c13802de','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('c1e0cfff-9220-423f-9320-c191c13802de','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('c1e0cfff-9220-423f-9320-c191c13802de','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('c1e0cfff-9220-423f-9320-c191c13802de','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1),('f303bf4d-7b07-4a58-85b6-455d24269265','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('f303bf4d-7b07-4a58-85b6-455d24269265','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('f303bf4d-7b07-4a58-85b6-455d24269265','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('f303bf4d-7b07-4a58-85b6-455d24269265','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('f303bf4d-7b07-4a58-85b6-455d24269265','3d201784-6f27-40b2-ab39-08b4f5521031',0),('f303bf4d-7b07-4a58-85b6-455d24269265','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('f303bf4d-7b07-4a58-85b6-455d24269265','65212767-9df0-4e28-8c33-00546d81cf03',0),('f303bf4d-7b07-4a58-85b6-455d24269265','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('f303bf4d-7b07-4a58-85b6-455d24269265','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('f303bf4d-7b07-4a58-85b6-455d24269265','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('f303bf4d-7b07-4a58-85b6-455d24269265','f696bde9-1154-4d45-b708-7fba87b83fbd',1),('fa51df26-542b-4903-b522-58f8ee6800ae','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('fa51df26-542b-4903-b522-58f8ee6800ae','0c7363ad-14dd-4251-b417-320066960b32',1),('fa51df26-542b-4903-b522-58f8ee6800ae','1a80d43f-6fae-498e-99ec-9338390ea212',0),('fa51df26-542b-4903-b522-58f8ee6800ae','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('fa51df26-542b-4903-b522-58f8ee6800ae','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('fa51df26-542b-4903-b522-58f8ee6800ae','54c528ba-746e-47f4-917f-9ad4b710b011',0),('fa51df26-542b-4903-b522-58f8ee6800ae','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('fa51df26-542b-4903-b522-58f8ee6800ae','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('fa51df26-542b-4903-b522-58f8ee6800ae','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('fa51df26-542b-4903-b522-58f8ee6800ae','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('fa51df26-542b-4903-b522-58f8ee6800ae','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1),('fead954d-b832-4e09-a767-93f6ef398331','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('fead954d-b832-4e09-a767-93f6ef398331','0c7363ad-14dd-4251-b417-320066960b32',1),('fead954d-b832-4e09-a767-93f6ef398331','1a80d43f-6fae-498e-99ec-9338390ea212',0),('fead954d-b832-4e09-a767-93f6ef398331','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('fead954d-b832-4e09-a767-93f6ef398331','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('fead954d-b832-4e09-a767-93f6ef398331','54c528ba-746e-47f4-917f-9ad4b710b011',0),('fead954d-b832-4e09-a767-93f6ef398331','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('fead954d-b832-4e09-a767-93f6ef398331','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('fead954d-b832-4e09-a767-93f6ef398331','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('fead954d-b832-4e09-a767-93f6ef398331','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('fead954d-b832-4e09-a767-93f6ef398331','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1);
/*!40000 ALTER TABLE `CLIENT_SCOPE_CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE_ROLE_MAPPING` (
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ROLE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`,`ROLE_ID`),
  KEY `IDX_CLSCOPE_ROLE` (`SCOPE_ID`),
  KEY `IDX_ROLE_CLSCOPE` (`ROLE_ID`),
  CONSTRAINT `FK_CL_SCOPE_RM_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE_ROLE_MAPPING`
--

LOCK TABLES `CLIENT_SCOPE_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE_ROLE_MAPPING` VALUES ('54c528ba-746e-47f4-917f-9ad4b710b011','9973cd36-52e9-4f65-8b87-ea9b8b1e6a4e'),('65212767-9df0-4e28-8c33-00546d81cf03','867f4629-ba03-4a3f-9992-2369e7de4ff6');
/*!40000 ALTER TABLE `CLIENT_SCOPE_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLUSTER_EVENT`
--

DROP TABLE IF EXISTS `CLUSTER_EVENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLUSTER_EVENT` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TARGET_CLUSTER` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SENDER_CLUSTER` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `EVENT_DATA` blob NOT NULL,
  `CREATED_AT` bigint NOT NULL,
  PRIMARY KEY (`ID`,`TARGET_CLUSTER`),
  KEY `IDX_CLUSTER_EVENT_TARGET` (`TARGET_CLUSTER`,`CREATED_AT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLUSTER_EVENT`
--

LOCK TABLES `CLUSTER_EVENT` WRITE;
/*!40000 ALTER TABLE `CLUSTER_EVENT` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLUSTER_EVENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPONENT`
--

DROP TABLE IF EXISTS `COMPONENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPONENT` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PARENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SUB_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_COMPONENT_REALM` (`REALM_ID`),
  KEY `IDX_COMPONENT_PROVIDER_TYPE` (`PROVIDER_TYPE`),
  CONSTRAINT `FK_COMPONENT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPONENT`
--

LOCK TABLES `COMPONENT` WRITE;
/*!40000 ALTER TABLE `COMPONENT` DISABLE KEYS */;
INSERT INTO `COMPONENT` VALUES ('0a61c9c9-6e3f-4e51-b5bd-9dfa10699212','Allowed Registration Web Origins','84ab64b6-3491-4ad3-8d0b-34567e32e313','registration-web-origins','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','authenticated'),('0a63cf8c-db67-475d-82b9-1da6b3c5c0e7','Full Scope Disabled','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','scope','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous'),('1498e14f-8c3d-4a58-b3c6-8fe947ccc841','Trusted Hosts','84ab64b6-3491-4ad3-8d0b-34567e32e313','trusted-hosts','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('1a99d0b6-32ee-4dfa-b142-9ad378f31275','Allowed Protocol Mapper Types','84ab64b6-3491-4ad3-8d0b-34567e32e313','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','authenticated'),('2335df59-2405-454c-9cea-f5751979b9ba','aes-generated','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','aes-generated','org.keycloak.keys.KeyProvider','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL),('2a0b726f-631d-475c-94c0-8e49f115140d','rsa-enc-generated','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','rsa-enc-generated','org.keycloak.keys.KeyProvider','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL),('32353394-1a42-4615-8001-4ee413a0c480','Allowed Protocol Mapper Types','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','authenticated'),('336d8d0d-1f29-485e-be91-d27b905b31bc','Consent Required','84ab64b6-3491-4ad3-8d0b-34567e32e313','consent-required','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('3cd8b89a-6cf2-4118-b20f-179f42adb7d5','hmac-generated-hs512','84ab64b6-3491-4ad3-8d0b-34567e32e313','hmac-generated','org.keycloak.keys.KeyProvider','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL),('43e4e437-d6d3-47a1-8e1c-73c67322331c','Allowed Client Scopes','84ab64b6-3491-4ad3-8d0b-34567e32e313','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('47c1d251-7a3c-4a46-b9bc-adcd58968a8b','Allowed Client Scopes','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous'),('4828a249-951c-4bb5-90c1-997604397c6a','Max Clients Limit','84ab64b6-3491-4ad3-8d0b-34567e32e313','max-clients','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('4a587e7c-4aa7-43d7-86e8-f4b9cb1d989e','Trusted Hosts','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','trusted-hosts','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous'),('55b697db-2a3c-47e7-b6b6-a85fca24f267','hmac-generated-hs512','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','hmac-generated','org.keycloak.keys.KeyProvider','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL),('7d223051-a352-4b9e-8814-8ee6fe45b924','Allowed Client Scopes','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','authenticated'),('80d3ae82-35ce-4a4e-93c5-b2d41f0ac89f','Allowed Registration Web Origins','84ab64b6-3491-4ad3-8d0b-34567e32e313','registration-web-origins','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('83822e15-3a4c-4f8a-8978-55073d7b83d9','Max Clients Limit','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','max-clients','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous'),('8aa73b5d-f110-4c4c-a692-2348ae329fba','Allowed Client Scopes','84ab64b6-3491-4ad3-8d0b-34567e32e313','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','authenticated'),('a12a5fb8-c032-4156-9a71-95a3a433be9f',NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','declarative-user-profile','org.keycloak.userprofile.UserProfileProvider','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL),('b8bc1379-7ccd-4557-8457-2fd78516ac62','rsa-generated','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','rsa-generated','org.keycloak.keys.KeyProvider','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL),('d28fc518-956e-4a81-9eef-84cad5f15d70','aes-generated','84ab64b6-3491-4ad3-8d0b-34567e32e313','aes-generated','org.keycloak.keys.KeyProvider','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL),('d63fd3f5-d03c-48a8-9416-108245a45b6f','Allowed Protocol Mapper Types','84ab64b6-3491-4ad3-8d0b-34567e32e313','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('dff02f13-3c6c-4154-bf92-9588343ff423','Consent Required','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','consent-required','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous'),('e665617c-c6ff-4ce0-a770-bc6ef99770ab','rsa-generated','84ab64b6-3491-4ad3-8d0b-34567e32e313','rsa-generated','org.keycloak.keys.KeyProvider','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL),('e6ae7821-66f1-4892-b37d-6dc375188509','Allowed Registration Web Origins','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','registration-web-origins','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous'),('e79ae8d4-3683-4f59-8085-fbcaf726018c','Full Scope Disabled','84ab64b6-3491-4ad3-8d0b-34567e32e313','scope','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','anonymous'),('e817b717-2877-4ecc-ac74-e7058dcfe9a5','rsa-enc-generated','84ab64b6-3491-4ad3-8d0b-34567e32e313','rsa-enc-generated','org.keycloak.keys.KeyProvider','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL),('f32e049e-0315-485f-aa52-764254e2f120','Allowed Registration Web Origins','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','registration-web-origins','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','authenticated'),('ff81e470-0870-4656-82be-2651c4dd9f1e','Allowed Protocol Mapper Types','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','anonymous');
/*!40000 ALTER TABLE `COMPONENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPONENT_CONFIG`
--

DROP TABLE IF EXISTS `COMPONENT_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPONENT_CONFIG` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `COMPONENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_COMPO_CONFIG_COMPO` (`COMPONENT_ID`),
  CONSTRAINT `FK_COMPONENT_CONFIG` FOREIGN KEY (`COMPONENT_ID`) REFERENCES `COMPONENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPONENT_CONFIG`
--

LOCK TABLES `COMPONENT_CONFIG` WRITE;
/*!40000 ALTER TABLE `COMPONENT_CONFIG` DISABLE KEYS */;
INSERT INTO `COMPONENT_CONFIG` VALUES ('0254e16b-f7f1-4251-aa65-1f3ac0d3912a','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','oidc-address-mapper'),('06599d42-48ba-4a90-b664-8169f27950ce','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','saml-user-property-mapper'),('0972bacb-7d25-4ce8-80c5-2740bbb00ccf','7d223051-a352-4b9e-8814-8ee6fe45b924','allow-default-scopes','true'),('0decabee-a437-475c-88c8-7e945da7043e','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','saml-role-list-mapper'),('0fa0c00d-6f9e-4c99-90a6-0bf44c55340e','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','saml-role-list-mapper'),('12a822cb-26cf-48d2-98a2-d982ceb7a592','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','saml-user-property-mapper'),('1e0d0333-099e-45bd-8432-1af8f8ef845b','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','oidc-full-name-mapper'),('269ddec5-9357-4a47-9ce8-84b043dd2da9','e817b717-2877-4ecc-ac74-e7058dcfe9a5','keyUse','ENC'),('29cb37a5-73e9-48aa-9048-ea66b64a7981','b8bc1379-7ccd-4557-8457-2fd78516ac62','priority','100'),('2e5e66c9-e1ab-4f8c-807b-238030936708','4828a249-951c-4bb5-90c1-997604397c6a','max-clients','200'),('31a94922-8c30-42f8-9eef-29efe44ac88c','3cd8b89a-6cf2-4118-b20f-179f42adb7d5','priority','100'),('38db70eb-4bab-418c-9112-42b175b0529c','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','oidc-address-mapper'),('3dc93130-f97c-4c0c-bcf7-1b3c8e88cc47','3cd8b89a-6cf2-4118-b20f-179f42adb7d5','secret','fVhvk0abq_zh7r-RtXZUtFB6qcKsB0Nh4knvF4SH28YJsQlVqXVINoO3pPxppb3-aT73jnP2o8DcTva2Hz-naBTfngjwwy4Csow075O-Zn-tKylyD34TcM_dbaM16LJJPJxwxMq2NRXDJw9Yh7t_67nizDrDUuZogFQUdpllazA'),('3f8d0888-9752-472f-813e-922911f03dc3','2a0b726f-631d-475c-94c0-8e49f115140d','algorithm','RSA-OAEP'),('434496ce-9a67-40f4-ac7c-3285be75acdf','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('470f5a03-c1a1-4b27-801e-0ec699bc430c','2a0b726f-631d-475c-94c0-8e49f115140d','certificate','MIICqzCCAZMCBgGgwZL3lzANBgkqhkiG9w0BAQsFADAZMRcwFQYDVQQDDA52aWRlby1sb2NhZG9yYTAeFw0yNjA5MjEwMTI1MjlaFw0zNjA5MjEwMTI3MDlaMBkxFzAVBgNVBAMMDnZpZGVvLWxvY2Fkb3JhMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqZXWbzNcila+pQADxRdLneMQUySq00+v0tq5d/VQKkzfUxmDpH3MUq+omlY2xrBJlv79SPTzWFtd55EZn+k0xhTnr5NFv4j2iTkeG4KqU42EsU9BDloAxOyFrF3nBMEIn61iC5YOC5zFWLrROZKLvlYXT60HFu/ZMYZ2G4t7uRakmwbzlJO+HnxrwvIeOkUY60XPtdrvZa47g98In93t/p8kjwKvyjdhbmTTG4HJU83IefLQ7393qFfU8BTB0qZ6gbRd3CLhTdnjOSpi9CmoZhVcQLXcWrVPTUEgR6kKKPX8/xdtfHodxTNuvFp4WrRvD3pleE4un+JZtn7ZgRTxUQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQA6cka1fU1wg4tMTqk9vCdrTNmWIlsUPApwPEuu1IUEVjSBurlituH44mOjI39orj6zNH+niiS8Wp8szBjSQDu2jXmLZCiO4IB2j0KeAJpJJYM9PN8mh6cqyu4RW6NnaRbNQe+9c78z/+9pUQDJ6nzsrwyjTxLsvOItjA3MFrM2rj/wjqQDafOxKjVnfhBnB7a4j0hr1cTPWaLyXod780lpyp9xnYDqr3XXTmvNaX4gVdUdZ9X0TMSNkUdvsDcv0R78yvvajFx0Ci+qEiWBzJPLQczK7I/TUzs58DXwZ2U7RuRacs+RghM04USkXMprPkgEerIirG6f32m63u5TBGq8'),('4c7190a1-ffdb-4d58-8ca2-5c0401404a62','b8bc1379-7ccd-4557-8457-2fd78516ac62','certificate','MIICqzCCAZMCBgGgwZL4DjANBgkqhkiG9w0BAQsFADAZMRcwFQYDVQQDDA52aWRlby1sb2NhZG9yYTAeFw0yNjA5MjEwMTI1MjlaFw0zNjA5MjEwMTI3MDlaMBkxFzAVBgNVBAMMDnZpZGVvLWxvY2Fkb3JhMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzmZ+ecoSiKwD+efKeOoHBLMLfYrrw6+Arx1tMLVe//WdxYLAsthBgq61L9/UWm0WxM6pKUd+prU5zmVJySZHvg9uWj70HzJ+Yc+DDpgMimGHAPmhAN6alkj0zMlXp7OeUtehCW1HV0aZvtj1UfJ+fyHxdq4vwkPF29DnKLL/ihvPQkwa12+4tLYXn4a/U+BUH/4S7dphNToMwx7X2eMieNuEDE4rOdp/j0ufPXE+0nkTZZoyLw2pCRMFcVGh5pZg1HPpRczq+K7gULAMU2JTrDOCMusNkOlLPnphrD0/BDDwRuWX1zKtds0a+0VR2VlHDwJ4PRg6l9W/i9VA83mD2wIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAsJ4GHfDQZV60lwUzqNfzst6PZCaFDu7d6fLnvavQ8XWYv43bLBSiatHOLmSw8qJkk9pgJx452iV/REw33xT9gnHTSkbKL9q7fXOu5jo16SGjk/zjOYDRBjGHIFblM9uFvdvrZY1oGpK39V60t/l89Tg4ffGQCfx2WgPog5C5NBiASCXg2yG/3JGI9GOUqY2gIn97xl4MJu2TwTEbYoyZBr+NTPB3ClgKitXsDE8WB7Fl0rEjpEdOikccnvyVTc8hT7+gwFJ1rq3S9UvomA4Acu80HhzdB7e1r68BaJqdWiod5QEcF7+k7BPbnawQEUjYAOje0/MF8lNf0CFXvLxAH'),('4f6c41d0-0583-4373-b4bb-2707c57e1b7d','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('5363c2ba-f7cd-4ea4-b9dc-0352cddf2938','e817b717-2877-4ecc-ac74-e7058dcfe9a5','certificate','MIICmzCCAYMCBgGgwZL0nzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwOTIxMDEyNTI4WhcNMzYwOTIxMDEyNzA4WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDLzsZwyw9HOnUTTm0JSl9vZKKZ2a9R25+JzOd3x3ZVX65lZ52lccA8mV2l+oQtNDxGhHJGmtxUmgiyF00tE7/mysM+LtqoosP+l014vYl4uGyM6e3SQh+atFM17gKgrHD6sDgj4VWY/ID7fhdK2GfHzPTLKVz/csxZ+rsihlzSfec0rjZJ8hiqAIdM4OMqhoMLuIUzMTTVuSTGZN0sUJTaWHlArmAbJ+OR07S2Ky46geslAxhzS1yNvW7i15htQafuJsaufJU/197FhOUmlZUACzWs/9G1HL4iYt/sLY30ToWFGNjxBFy1oZqSG49WslosDZTSg52WqO56W11uE+wtAgMBAAEwDQYJKoZIhvcNAQELBQADggEBALh9mJecyI5eDJUz6JWE6xW3s4EuWQPyGWTsauToYs35vy1KQMN54d2DmO28kLjqiQBv6WD8qfPSB9XfqydlO8FAniUBjGcmsjYnmeYlo8zlVk50fVd674ceOaGaN7UxFdOPUVJcWqyYOQd0i+wugp2k5Af7lKXBDMDTKjcERo4/QEv5CB12qQthcM+SusASKmbCgpkDjd1O3op0PmzrVqvdmIQLXwd5QvFRqAi69LVWHPwkm917g98PD7QDktYN+wBczfZEP27vX7OAURVutBlefRHWv0aqupmkeAhEwrSge1V+vY6nUxWR+q2jFeaHIBe/hY45/o0oOPh72JnbAMI='),('5677854b-716f-4c6c-8d3c-9270f787e44e','2a0b726f-631d-475c-94c0-8e49f115140d','privateKey','MIIEogIBAAKCAQEAqZXWbzNcila+pQADxRdLneMQUySq00+v0tq5d/VQKkzfUxmDpH3MUq+omlY2xrBJlv79SPTzWFtd55EZn+k0xhTnr5NFv4j2iTkeG4KqU42EsU9BDloAxOyFrF3nBMEIn61iC5YOC5zFWLrROZKLvlYXT60HFu/ZMYZ2G4t7uRakmwbzlJO+HnxrwvIeOkUY60XPtdrvZa47g98In93t/p8kjwKvyjdhbmTTG4HJU83IefLQ7393qFfU8BTB0qZ6gbRd3CLhTdnjOSpi9CmoZhVcQLXcWrVPTUEgR6kKKPX8/xdtfHodxTNuvFp4WrRvD3pleE4un+JZtn7ZgRTxUQIDAQABAoIBAAHF7o5OmezbX9ZvU9rDddeyiFjqNPwNJQA+J7rMnpg2og4nIeR+KT0DF673cE6vCLHyvBi/cOzvVaHGd19f65yXmt2P22aXisZgCcPNX7UMcYL+GmbJQ6FLfNFS0QfQcePjhvcqjD6MVtbo6yegM+RbV5aOb1jKzLlTF9iNYo+Km/SqhZUD3bbp5gaKwoHU0kJJWjdjgJQ90MhajNKX/V41zUVu7GsCjRmcQRjThRC0whqhcN8KMAJEnT7oOKsFiED6x60ZeqObc0CAOLSP3zu+5MHIYDsV8A7k4rCgu3REBLYUKkLGZfm72hjdVo+AdIXsuAN0cOzV7v46t513uhECgYEA2vhHMON0Smh5gV7S3famARHxDDWRsCVupEuymXwwZSBgb1Cod72fnlfXCXwKwBM9EwaDDm8WQydjVN/mXWhn7FMVVwEm9VoPl/j8SOA9WYPGR3RjFOs/j6MX00GKMvRSPMwNIJIYfU7/SPHOXuKAtv+YEtWKTa1r7KSQo6xjKBkCgYEAxkOWGzfR8MIEbsGZTU49RfJR3gdxU4U25VRBSgHYUxcnRbvN/isNNr8AloFBF+yq7kcOcJmbJ3HfS0lCQfRNlS6zs97xL3IfVmIXy+Ry4CpFLiLaMvL+Jbdx1q96Psh/Jd83YKUFiZ+kkR3JrQCmBu8C8Pi0+ua/Vt/Kl0SMmfkCgYA5AqFOajnx0YepFi4imkAYUTqIKj5XNTe8UPUcHwhem/JfqQlju5weVtJm5sPJxHiHRo/Cp0uNimjDRVQuB6vfDLamo2coRB2BPNM6ih+O+c8a9YOCg8lVtWnTl+HKaHAs4hec3ky/+1xd+o73h1Np0dwfMzfCB5/syd/arVxXqQKBgG1jlutXhga/FXECchHcDCSOiSrmkllRk7M+JHOvxuo5SRrJfuMwX68H/UwM7pxDoR+spsPrjFZcFqZUOjFnmHKp/M5OQGY8IhwoLRb66YLS765/3kHkHeMzbqTT1q/TMYv0t3okMoT3RvYmKELCq9gBgW7w2fHg5EsLWJzTXnwJAoGAddaK5tnlWsElRlZGNv4sus9NIaM1X3uuRMyW7Yf+BY3KRIbwm9wTpbbZqHmkUJdyNQYNQYzxca2/tI8RnD1l1GHan/bJxIT1yPEC+F24fMMUa8fduEumoy2CT+KemOOp+pK1oLOnUP6dtkQGdCUWmYBToitXLd1dbTmDUYAtHtA='),('57ed143d-0deb-40a8-9c81-2af7ceccf411','47c1d251-7a3c-4a46-b9bc-adcd58968a8b','allow-default-scopes','true'),('5afa2988-1e6a-472d-bf30-17ffa6df81a4','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('5b29cf0d-1680-4b59-9c03-ff0841cd7788','2335df59-2405-454c-9cea-f5751979b9ba','kid','b78cb3b9-873c-4c89-9487-05ceadcc1a34'),('5c2bf7a3-743d-4f46-861c-232ddcc4bd69','d28fc518-956e-4a81-9eef-84cad5f15d70','kid','617f3f27-06ea-4c05-b813-2a91e01acf7b'),('5c7d340e-8336-4bc2-b5d0-461e65f08cf7','55b697db-2a3c-47e7-b6b6-a85fca24f267','algorithm','HS512'),('60267237-deb8-4c5a-87d3-b15615799796','1498e14f-8c3d-4a58-b3c6-8fe947ccc841','host-sending-registration-request-must-match','true'),('622f534b-8230-4a31-ba37-afd4cf8f673e','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('62bdbffa-6636-416b-ab74-c01c817a01c3','a12a5fb8-c032-4156-9a71-95a3a433be9f','kc.user.profile.config','{\"attributes\":[{\"name\":\"username\",\"displayName\":\"${username}\",\"validations\":{\"length\":{\"min\":3,\"max\":255},\"username-prohibited-characters\":{},\"up-username-not-idn-homograph\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"email\",\"displayName\":\"${email}\",\"validations\":{\"email\":{},\"length\":{\"max\":255}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"firstName\",\"displayName\":\"${firstName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"lastName\",\"displayName\":\"${lastName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false}],\"groups\":[{\"name\":\"user-metadata\",\"displayHeader\":\"User metadata\",\"displayDescription\":\"Attributes, which refer to user metadata\"}]}'),('630d179e-a9e5-4f80-8b4a-e9c62b6402fd','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','oidc-address-mapper'),('63953a86-f5cc-4769-a1d7-9b2ecb2262c0','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','saml-user-property-mapper'),('67bf8849-c537-4bdb-88e3-433f07883b01','4a587e7c-4aa7-43d7-86e8-f4b9cb1d989e','client-uris-must-match','true'),('6a1e0831-144d-4ce6-b064-d5ad8076e7be','55b697db-2a3c-47e7-b6b6-a85fca24f267','kid','bc1e79e9-88db-4dee-bf16-18ba58f5669e'),('6ee18edc-7fea-4003-a0af-428efe81a8b7','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','saml-user-property-mapper'),('78466085-90c6-4a11-af95-41bba3115a0b','2a0b726f-631d-475c-94c0-8e49f115140d','priority','100'),('7a3e9d17-63b3-427e-a37a-96a8b21abfe8','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','oidc-address-mapper'),('810d24c1-3077-45e8-8aba-c493c2bfc7e5','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','saml-role-list-mapper'),('84cb207a-3237-4088-a62a-24cb8855af10','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('8ab65655-bb13-42ae-a488-4552a628956b','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','oidc-full-name-mapper'),('95cbf99d-c5ec-4c88-b26b-a4933e3ab854','3cd8b89a-6cf2-4118-b20f-179f42adb7d5','algorithm','HS512'),('9817527d-8a11-473f-977d-5595d5b7bac2','d28fc518-956e-4a81-9eef-84cad5f15d70','priority','100'),('9debcb01-759c-4afe-88df-ee959934af20','e665617c-c6ff-4ce0-a770-bc6ef99770ab','priority','100'),('a4661cda-be5e-4476-a5d4-99256ddb568c','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('a5710f7d-7b3d-4838-8849-18e75320e589','b8bc1379-7ccd-4557-8457-2fd78516ac62','privateKey','MIIEowIBAAKCAQEAzmZ+ecoSiKwD+efKeOoHBLMLfYrrw6+Arx1tMLVe//WdxYLAsthBgq61L9/UWm0WxM6pKUd+prU5zmVJySZHvg9uWj70HzJ+Yc+DDpgMimGHAPmhAN6alkj0zMlXp7OeUtehCW1HV0aZvtj1UfJ+fyHxdq4vwkPF29DnKLL/ihvPQkwa12+4tLYXn4a/U+BUH/4S7dphNToMwx7X2eMieNuEDE4rOdp/j0ufPXE+0nkTZZoyLw2pCRMFcVGh5pZg1HPpRczq+K7gULAMU2JTrDOCMusNkOlLPnphrD0/BDDwRuWX1zKtds0a+0VR2VlHDwJ4PRg6l9W/i9VA83mD2wIDAQABAoIBAAZex6cgbPtp4ukhVcoiLI6t35XQcuyQ68+ImkU6e9DTkFSEIuI1ZkQ1xy+ck83DEZGICiGIUtwRum1PCmMNoU44F+eFWBYazvRbqe3wrgZnvyzXbeti2dheLqwGLmqyUpmE85pT+wBlersXFojUC3Wgb91O8ytmpkjEBRzOjxazxpTS9Abi+6kG8Vb/8yguwuS3nRRU8mOprK/n4zKy2o6RxPuhi+LNPMUgPvPy+NDyZgNm64+f/j/+b6795NUQ1xoRQPVU3TVvR0kTnGKHk3GlQUJAmkPMk242W8kXYZ+Jf8uBDzxZ4wPituk3qffxcIleqQq10bbG1DKxgf32Bh0CgYEA+yjVN68kt15s+T8p3CVWdYmKUgAGgZbroNPIVQBQxbTDpi7GdPqdnwuUV3yUyT7qewaj8HHXx+7MODMpTx5XQIZklxsErXXYItkEQS9yc3C3hQnq7B3ZsrcQcI+cq8qd7LzIQse5E9mEicvkO0c1BJXAFc91s85yvyl+cd/55mcCgYEA0mDURage8UmahA1Z5LJJ8f4bVjezDYwMPDkTuRwC0dWUukNSSYxWW5onVGKRdk7ef/GyB/UH4Gu8DZJMvsvu3RyED1SvPSgoXvsYVtlE/kNej/XSt64cPFqwC68QvxolTfVbi7wKnuu/w9toVFH/i9DnqYxLIZ/+unr0eIx0Bm0CgYEA2LXu49E3uRC8roOVtuJwq5I1y3NCKebzAR47qTxQdYb3mhiaHK1x+52eLa7NIqgq4mRkaD+SlGyzwXpDloTzfDV57ffeHV2lVMw0I5qxAnKrpxtbnMhU4yOaB8WixYhao75wfU6fn0T8W3mWQJ+8W2xrBWawhKkJ0XAYLmG32tkCgYA7g8EJY6I9SEE6EjzYAcgBeY1qOp+guXnMn6kAuPfjPLSybNEelWDo0RdHPAtCmNVBBLMEpUDxMAknHbgwUajlTGffnmlkt7OUCxy7lQN7mrtppnVSGSNLv6wF4iSuq0raXwri4PNwOekqEyvUjs3oU9T1lga7IHQDdT0rzTAVkQKBgG3AwaKUh9qKxE506L7avc1R+SGcIXxBdx30o7iwTc/khC4uAh9C1kd2HLl//sJVL50KhUHUGzrRxXiwxE5ANQXRWdgG7f9+bbx1u5uDtKpBpWNFeOaTf9S9xKlQEgF/NEYXjZ6MwJIvzS3s/ne74S4uNDoRt6DcyCNn8YCCJPB9'),('adfc5bbc-b34f-4a4d-ac3c-c6e16f038894','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('b2cf9202-abed-4971-8a61-12d5424dd6ae','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('b2d90069-f42d-498f-8a37-a2ffaa85b866','e817b717-2877-4ecc-ac74-e7058dcfe9a5','priority','100'),('b90bce9e-d410-4940-b189-f0923f80cac0','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','oidc-full-name-mapper'),('be54d513-fee0-4433-ba0f-f09f0bcfaee3','2335df59-2405-454c-9cea-f5751979b9ba','secret','Jbw9PBEZwtyWA2xywf_3haKvl5J6XvzIEPdn8-Z-qU0'),('be884cfa-5794-4aff-949e-563f51e9240d','43e4e437-d6d3-47a1-8e1c-73c67322331c','allow-default-scopes','true'),('c50dc2de-664d-40ef-814a-f7ae4a54be81','3cd8b89a-6cf2-4118-b20f-179f42adb7d5','kid','ce6361ac-ee37-43d4-9f7f-891a3c21bed5'),('c5d9c347-a02d-450c-b39b-3f74d64f27fb','e817b717-2877-4ecc-ac74-e7058dcfe9a5','algorithm','RSA-OAEP'),('c8a9ec5b-b9d6-470d-b04f-1210b2d188ee','e665617c-c6ff-4ce0-a770-bc6ef99770ab','privateKey','MIIEogIBAAKCAQEAq17AUSl/SuPkEyUqHw89pKy00T4Yt/YRzV+b/Wdv8k/No6y7a0GP4ghaD8vGT9P/H+0pGvGOYRPqaCFPSr/0ZbOfeg9K689KWhtuZkeKBiJF38ZEOrswuJbwikzkSIMdqAdGgAuJSZPE5SBBIH26bTV+WOs61CTM0j/HLG/zZPok6tPPL32LxDHUC85H8XkFQW6xy2Td1j+ZHoBDjly5/4FfmJjj4XYzgUzxpgk3ctIRP4UDKEXFq08tFbmS8Lsa0mD/HtBKNcWXK2zE1iaFnbEkYcoJeQ3BjT59Xq13rxXfSXR88dq1ChK23EmbikVW412kgpilu4bH5yOlnHorwwIDAQABAoIBAAKndhmWXoqx2HMlpmwYreFHr/c99BYBsIZGsmdvlsIClow2Gk2rFE4M4FmLwatrFPfUHjx081iAqCb3JUvKJ1iaqAq6/RgwHUDOQQ1/MW/lgJzUbLyf18+81igtDWi+MTfksbcMf9WrfVgpsnY9xKTmyoGrDRktUuxmCM+Cc7ORVOHlaxilF21HY4Yf+YLJHU128CXAalREaA+MvLUPUn6W2asmRhpY9TH90kWisMheMbNO+EAqEuCHU9Hycfh4WtCi8gLbCIW6xqrSwEvmtbcuAW4JUp4LiAahqNP9gFuxeGOGeqRcwAVVix5cQqTtNYbZaIhY6FRN4mAvNX+f84kCgYEA3dCbZwVUEY8obEenwiLXkI9MJMstg12Tfaq+RoHvD7UyxoDrKBlGXbNpa7iSLWjj77RWlajIk+tcIbdRTuhbscGxwgt0MTPCUmJ8pxIOrq5jDievMcYcpLZ5qkf9gZN9g/RuJ4OgHIYcB+tMqIC3ovh+cjdcvIL/aCPe0/dRPZsCgYEAxcfq8az7aCJ939hblC112uxiDLQruzhiFzlCglbRL0gf03F+A5bk9CwjrKQNEj0oqzIytmCMJHPwuPuU8iO7zDv5oKcskyAtxKkpdUG4+Q2ayQu+EXoDRZ64IldVFWYeYVByO1MhpPRkMmKuf6VQDIyB4NNK+BcCSyFViGVTwPkCgYBfFTYYYjtYT5KXX9v0pzTafeK4/vNilXFM9C0eUkJk7Fp4pvimtrboIak2COd4WbcjoJ1hB/n7Fm/m8AsFlSsBNrN5J6nGEZbh89/VSjNLA+voPHCoGHFc1e+vY66ypcOvFc9GVvECaSaI6n9w18RgMr8ZPMwe7tSHEqFJIYIMswKBgBJq/pcI69STubMZu9V9skbz0mGqeZQSuRe+jlIC8bH8fnI7VGfTKnkOjzfpgwoaxenDX/OZ5BMU9OrVCtbNuxRW1XU/fCgrS/fPZPv1ZdtTiAGG5WlNOnbGRBF2nobCnrujOTALGsv4skf65pMeeujgQMwGASo/Qkhqz0NHZFhJAoGAVBBuIySA5nmab8qEcKGxueIpW6BOkxEfiA0k0iNBUTKFjHnydKt6s/OCO4xGCPGEW2/tiRwLUbifQ55s1wjuPaqkjDpccS0v0B5jkiTph2ojB8EqpVXg65uLVnVP7T4H2Jq8TSdNnHSvpkOwghOm5tnJtUX0mM/R0VnExZa0nnc='),('cc1a227c-8faf-4f54-82a9-d6dfbb33cae4','55b697db-2a3c-47e7-b6b6-a85fca24f267','priority','100'),('cc883391-6519-4c2d-a6ee-85cccf294ca3','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','oidc-full-name-mapper'),('ce42f037-2bb3-44a4-94df-5eaf2b728823','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('ce905348-c07d-4246-8735-e92cfe4d5d6d','2335df59-2405-454c-9cea-f5751979b9ba','priority','100'),('d86f31ed-eb6e-4f77-b77b-33af73892961','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('dc6deda5-8a10-49e4-b1f3-7bb98957b73b','4a587e7c-4aa7-43d7-86e8-f4b9cb1d989e','host-sending-registration-request-must-match','true'),('e0043af6-5959-4ada-939f-71314187375b','1498e14f-8c3d-4a58-b3c6-8fe947ccc841','client-uris-must-match','true'),('e5b8e5e6-5c2d-45f6-8785-94817b84c4c6','e817b717-2877-4ecc-ac74-e7058dcfe9a5','privateKey','MIIEpAIBAAKCAQEAy87GcMsPRzp1E05tCUpfb2SimdmvUduficznd8d2VV+uZWedpXHAPJldpfqELTQ8RoRyRprcVJoIshdNLRO/5srDPi7aqKLD/pdNeL2JeLhsjOnt0kIfmrRTNe4CoKxw+rA4I+FVmPyA+34XSthnx8z0yylc/3LMWfq7IoZc0n3nNK42SfIYqgCHTODjKoaDC7iFMzE01bkkxmTdLFCU2lh5QK5gGyfjkdO0tisuOoHrJQMYc0tcjb1u4teYbUGn7ibGrnyVP9fexYTlJpWVAAs1rP/RtRy+ImLf7C2N9E6FhRjY8QRctaGakhuPVrJaLA2U0oOdlqjueltdbhPsLQIDAQABAoIBABTnEKgp01fRUYeY4Ar3Y0FX92tDDb2eAkdOSiEZRnQsG4VP8rWwrHAqpJWs01iVhmcPF29RW66bm6+0PxiT8XcYrZyXjpqEEwjt+Kac/dfxRkTPizIo0Pf7bZtW3VMgTHgRkbhwWGiX4RyqCnaFKmOuDB84D08ttXK3CfFZCXUXALjPesTDL/O8UskpA26k+28kdoMnAyWPVJAQHQ+AZvAe2dgi0s7BvymcL8pdqIqxccazsp0a1F7eWIleHCOJ5/qRwswtJ430vcCvEBwmiLqLTFio+zdb+qZPW7I4PoIFY7+LfGAgVZ+Yi4ooyCL52TYNsYtXG6iZ1uWkHSNfY1sCgYEA7K4QR0eq+U2W/IhUFo/WG0z5AbXqxP1JOq4BxbKE1gYa6NKJC3uC+/BkzIQePI/Nm2bxoG0ESo2LpB98bVleG1hwhdFguC4+u0hMdklX09If3IL67wg933l5KwL7RIxt+KLzyfq2QK2Fh8l94Vp1qPMtaGOIDFUPwqRS3H+6c/cCgYEA3HHGm3TYKuxZwRlgdncP7H3fCyZhGvKHB0YVnlsF8bsrHMym095Ldg+4GC7LzNe0UAqkgnyiYlsxy7Anovz1fMK9iHM6wxvBj0vnt1DsmKvQYxZalddjEYheFJnTcS1hPDL5leFPsxr5qCbs7UaQXJjgfltX2gNTmxtyJUadT/sCgYEAw7ZYDalMz2SCswZEinecc+zdh7WXkhdkY5qaKpGpWJWp0NavrogO0yiBIcEqg6fiPFwO+DrNrpyHWUsUCBQ7Rl+GhJGT6hmLlDB/0dxqPOVnpV/GAr0M9Ous741Cm/eHxG9zKpUf+jHC1nselafI3dFgvg535MK+CpT5VA5m7xcCgYB9lfPnrHFaQrv/Xk2uL7ZKrIrc90hq6bAzXKIETSbdyBuPlKeWHBYxdFMUs9Q3Jsv6rZV7ITYBgqKjv/9Uw3e3U9pWWg8oCDAFSuD/doLTl05opNuGceZmnqG6asgiug+jFAdMc8fL6ZpBSavAoWqs1gtO8QrjkPGYc9JbmhcU8QKBgQDPflO2/19c6caDZgOSYWcYZA+MhqD4iCAND8uysdL1ImSxgmaGTFu85omP3KbrFQ734ZZtybia5W4ZG1FvqQbtLSErZfFLN2wRxFmokHX3dIok1fV0ooI9yY53vrWMVlqAxQW856TgdnuUbhgWWMvwruTcZ8jM8jGSfUQUrHbdhg=='),('e603ea7d-b18a-4065-8d4d-d251b33f3ad0','8aa73b5d-f110-4c4c-a692-2348ae329fba','allow-default-scopes','true'),('e6b7ac8d-bd81-436d-a66a-3a6206072e3d','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('e6c2a24d-6fc8-4da2-9bd9-561b6d3730ee','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('ed0d7006-9a1b-4c7f-870e-c5329aaefe5b','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','saml-role-list-mapper'),('edb474b6-8f38-4ddb-993f-aab1f3836503','d28fc518-956e-4a81-9eef-84cad5f15d70','secret','RqIrGpcJ2L2SMn4crTZpDXp0_zX31-sZSRsxFa3nakQ'),('ee23de3b-7157-4558-a14f-e345087060d9','d63fd3f5-d03c-48a8-9416-108245a45b6f','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('efea5d42-47dc-4fd9-898e-973230d15e75','ff81e470-0870-4656-82be-2651c4dd9f1e','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('f1f4b492-1a59-4326-87ca-b1983441a630','83822e15-3a4c-4f8a-8978-55073d7b83d9','max-clients','200'),('f40919f7-4ae8-4834-8f06-80a0e9057744','e665617c-c6ff-4ce0-a770-bc6ef99770ab','keyUse','SIG'),('f54dd283-b2e6-4830-90ed-8a6bac80b367','e665617c-c6ff-4ce0-a770-bc6ef99770ab','certificate','MIICmzCCAYMCBgGgwZLz2jANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwOTIxMDEyNTI4WhcNMzYwOTIxMDEyNzA4WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCrXsBRKX9K4+QTJSofDz2krLTRPhi39hHNX5v9Z2/yT82jrLtrQY/iCFoPy8ZP0/8f7Ska8Y5hE+poIU9Kv/Rls596D0rrz0paG25mR4oGIkXfxkQ6uzC4lvCKTORIgx2oB0aAC4lJk8TlIEEgfbptNX5Y6zrUJMzSP8csb/Nk+iTq088vfYvEMdQLzkfxeQVBbrHLZN3WP5kegEOOXLn/gV+YmOPhdjOBTPGmCTdy0hE/hQMoRcWrTy0VuZLwuxrSYP8e0Eo1xZcrbMTWJoWdsSRhygl5DcGNPn1erXevFd9JdHzx2rUKErbcSZuKRVbjXaSCmKW7hsfnI6WceivDAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAJWd67ORXdcZs1CjTFqmLyzRHBaMcWvV0isfcEQs3L8xk2p4kN7CGXSiv8eb21rLGOoH113yf/68JzBmuTI9DrfEaz4XOaZ2Oj/gfQj4oHsd964QgARfyHDFbdVFH9ffI95/7H9jXddUwXoENar9IRnRlpSV9OvunJGZsHSFCOGhC1vDOtyfV3zd3T44SxJ5+kYVCGL/UmjeXQqY4Pe5hsJoAirGTQwGHD3qFRl58kzj7WglXUfnTfnR+ucDQ99nCWvpK8Ykv/8FuaLh6IydzbFrnNvJ9VM4eXWc//EYaKXSgyT2NvIrpLQuOY49WtUDNiPPipuy1HjkUCpSoXqlTK4='),('f786b5c8-f9c9-4d7e-9f18-0afa04734bbd','1a99d0b6-32ee-4dfa-b142-9ad378f31275','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('f848f51f-5bd8-4a6c-a937-ee7f9b8b04d6','32353394-1a42-4615-8001-4ee413a0c480','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('f8c728a1-bbb0-4be4-a35c-44a3b89d7bad','55b697db-2a3c-47e7-b6b6-a85fca24f267','secret','NPkOeM8nMY3D2EWvXvTjmMH44e5t0OPPiiHMWCL-jU6X5ZJC2sl1vrLMhJKI3DIe92HwlivCHPWMO7SICPJP56GwMTEN9qMCXt_AsEXZxuWDfODyZmG8jmFHoZeZJzjLIyyY_iwnKnB2x8Q-6ezkIAgOFnxa4Zb4-jNlmVMdxw8');
/*!40000 ALTER TABLE `COMPONENT_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPOSITE_ROLE`
--

DROP TABLE IF EXISTS `COMPOSITE_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPOSITE_ROLE` (
  `COMPOSITE` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CHILD_ROLE` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`COMPOSITE`,`CHILD_ROLE`),
  KEY `IDX_COMPOSITE` (`COMPOSITE`),
  KEY `IDX_COMPOSITE_CHILD` (`CHILD_ROLE`),
  CONSTRAINT `FK_A63WVEKFTU8JO1PNJ81E7MCE2` FOREIGN KEY (`COMPOSITE`) REFERENCES `KEYCLOAK_ROLE` (`ID`),
  CONSTRAINT `FK_GR7THLLB9LU8Q4VQA4524JJY8` FOREIGN KEY (`CHILD_ROLE`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPOSITE_ROLE`
--

LOCK TABLES `COMPOSITE_ROLE` WRITE;
/*!40000 ALTER TABLE `COMPOSITE_ROLE` DISABLE KEYS */;
INSERT INTO `COMPOSITE_ROLE` VALUES ('05a0f015-abfa-4d60-bf0c-a94408b279cd','b09b9c87-c1ab-4e1d-816e-5a1c6c6ae11d'),('1ad8c6fd-75c7-4ffd-b3c2-3544bff05760','dafcf648-dd5d-4246-b188-5ab506970f57'),('20969521-24ee-4d4d-9fe9-691ca00ae4f6','35c80c1d-f511-43ad-8b72-de2207b99aac'),('20969521-24ee-4d4d-9fe9-691ca00ae4f6','7b2eef06-8d2d-40ab-b338-c366f7bb410a'),('2501c436-5b3a-4b6f-82f0-d1f6230dd84f','6dfd1a90-0dc2-4c3c-b215-73b22b80bb45'),('2517fdcc-2bd6-412c-9af6-e722b36b2831','1342c39d-7291-4898-95f0-5e06975cf062'),('2517fdcc-2bd6-412c-9af6-e722b36b2831','dd44bb70-568e-4ec1-b23b-ebd9e13668e6'),('25777294-becf-4448-a78c-64c10a80f012','04b1dcd0-52c8-4902-99f1-5232813c9903'),('25777294-becf-4448-a78c-64c10a80f012','05a0f015-abfa-4d60-bf0c-a94408b279cd'),('25777294-becf-4448-a78c-64c10a80f012','097b6ab6-76e0-4b43-8409-7d5f99b7db33'),('25777294-becf-4448-a78c-64c10a80f012','0b2d58d7-e130-43ee-be42-829d77bffb6f'),('25777294-becf-4448-a78c-64c10a80f012','1e8957e0-981a-4901-b610-c0aea6955bd6'),('25777294-becf-4448-a78c-64c10a80f012','20969521-24ee-4d4d-9fe9-691ca00ae4f6'),('25777294-becf-4448-a78c-64c10a80f012','2ae01de1-213a-44f7-b00b-4aafc6ca5c78'),('25777294-becf-4448-a78c-64c10a80f012','2bafb2c6-5463-4725-9368-2633f5aac513'),('25777294-becf-4448-a78c-64c10a80f012','30645722-cc32-4365-85cf-423ec12fe978'),('25777294-becf-4448-a78c-64c10a80f012','35634423-ce74-46f9-8b1c-b768eb998875'),('25777294-becf-4448-a78c-64c10a80f012','35c80c1d-f511-43ad-8b72-de2207b99aac'),('25777294-becf-4448-a78c-64c10a80f012','35d0292a-eb78-4448-8b19-84dc5c1d4808'),('25777294-becf-4448-a78c-64c10a80f012','36b5f3c5-d5f7-4a5e-891c-ff96de42cc3e'),('25777294-becf-4448-a78c-64c10a80f012','400a4b6f-9e6b-4f42-9475-b596d3305093'),('25777294-becf-4448-a78c-64c10a80f012','45c7d519-83a7-4d9e-aba6-c51ad8917b6c'),('25777294-becf-4448-a78c-64c10a80f012','52b17038-7b5d-40a7-8066-9821bf5c9436'),('25777294-becf-4448-a78c-64c10a80f012','57edf169-286e-4350-942b-64975150d34c'),('25777294-becf-4448-a78c-64c10a80f012','5dfb9358-9b3c-43a8-b67b-ce455746b14e'),('25777294-becf-4448-a78c-64c10a80f012','6614c47c-1dc7-4772-be37-671dfc613b5a'),('25777294-becf-4448-a78c-64c10a80f012','7b2eef06-8d2d-40ab-b338-c366f7bb410a'),('25777294-becf-4448-a78c-64c10a80f012','7d3b78f7-59fe-4779-85c2-ce175e73ef44'),('25777294-becf-4448-a78c-64c10a80f012','86311bed-a30d-4921-8ae7-36bcf8e4a9d2'),('25777294-becf-4448-a78c-64c10a80f012','86aa1c0d-0fc4-4330-bab8-801a0a53b0cf'),('25777294-becf-4448-a78c-64c10a80f012','8fc88c63-502d-476c-a60e-8e01a19a460a'),('25777294-becf-4448-a78c-64c10a80f012','904c740f-3767-41b9-aec5-228da80c63d4'),('25777294-becf-4448-a78c-64c10a80f012','907c30c9-4a85-463e-9291-71d379a83ac1'),('25777294-becf-4448-a78c-64c10a80f012','985de630-1e4d-48a7-8b2d-55d717c11cc1'),('25777294-becf-4448-a78c-64c10a80f012','9f02de6a-c205-440b-8dbd-c41f3e72db34'),('25777294-becf-4448-a78c-64c10a80f012','a3427169-9a5a-46a1-8e99-7ec8c2c9e3de'),('25777294-becf-4448-a78c-64c10a80f012','aae5998d-061e-455c-999b-3901bd486f81'),('25777294-becf-4448-a78c-64c10a80f012','ae11bf96-e7f6-4ef6-924c-a4a193acb0db'),('25777294-becf-4448-a78c-64c10a80f012','aff53c8b-768c-46f0-9149-6aa7ed5e2874'),('25777294-becf-4448-a78c-64c10a80f012','b09b9c87-c1ab-4e1d-816e-5a1c6c6ae11d'),('25777294-becf-4448-a78c-64c10a80f012','b21942c2-d0b2-46eb-b925-213a1bca2ca2'),('25777294-becf-4448-a78c-64c10a80f012','b89ef273-0124-4edb-84c2-589a587a795d'),('25777294-becf-4448-a78c-64c10a80f012','b8c2c844-4cdb-4aad-b53b-0be7b9c20675'),('25777294-becf-4448-a78c-64c10a80f012','bfad8187-d5d1-4012-88b5-92df67a694ca'),('25777294-becf-4448-a78c-64c10a80f012','c443b4f6-b105-422c-9b98-5743d2b4b378'),('25777294-becf-4448-a78c-64c10a80f012','d119dc27-6970-4b4f-9b0b-71485d78abfb'),('25777294-becf-4448-a78c-64c10a80f012','d94d1505-4279-4956-8017-64dbb2eb87b0'),('25777294-becf-4448-a78c-64c10a80f012','d99dab99-14e8-44af-be55-7f85a98dc3ae'),('25777294-becf-4448-a78c-64c10a80f012','e5980985-aeb2-456a-9a35-f8ac3b9441ae'),('25777294-becf-4448-a78c-64c10a80f012','fbbeac5e-5f79-40b8-aa21-7a868e0ef82f'),('4f6eaa8f-e2b9-44bd-8034-5230aae3f141','a5972f9d-5c81-4e00-982f-bedbe3358701'),('6123245b-7a96-4fc4-94aa-4276443ef839','bec49d6f-1e07-4f6e-9ba6-ce3a8aa8f0d2'),('690188dd-5aa0-4586-99ff-a0e575c77300','0f6975b9-def4-41e9-a518-826275c1e2b6'),('690188dd-5aa0-4586-99ff-a0e575c77300','6123245b-7a96-4fc4-94aa-4276443ef839'),('690188dd-5aa0-4586-99ff-a0e575c77300','867f4629-ba03-4a3f-9992-2369e7de4ff6'),('690188dd-5aa0-4586-99ff-a0e575c77300','da77e38c-d138-42a6-aa8e-c6fb622dabb4'),('8fc88c63-502d-476c-a60e-8e01a19a460a','52b17038-7b5d-40a7-8066-9821bf5c9436'),('90380dde-63e1-4ff4-8c55-58a993da9e3a','e4bacb5d-92b6-4d64-a6cd-33c6e1430bd9'),('985de630-1e4d-48a7-8b2d-55d717c11cc1','b8c2c844-4cdb-4aad-b53b-0be7b9c20675'),('b853b351-450d-4118-bc11-5e368f4ee393','1342c39d-7291-4898-95f0-5e06975cf062'),('b853b351-450d-4118-bc11-5e368f4ee393','1ad8c6fd-75c7-4ffd-b3c2-3544bff05760'),('b853b351-450d-4118-bc11-5e368f4ee393','1ceab581-252e-4fbf-94e0-f54a95b3d392'),('b853b351-450d-4118-bc11-5e368f4ee393','227a1dfc-6770-4e44-9275-27f7288cc105'),('b853b351-450d-4118-bc11-5e368f4ee393','2501c436-5b3a-4b6f-82f0-d1f6230dd84f'),('b853b351-450d-4118-bc11-5e368f4ee393','2517fdcc-2bd6-412c-9af6-e722b36b2831'),('b853b351-450d-4118-bc11-5e368f4ee393','2b3703cf-7a23-4287-8623-52a9f898b6c9'),('b853b351-450d-4118-bc11-5e368f4ee393','2fc80083-38ba-481f-8ef1-a61204cf8d96'),('b853b351-450d-4118-bc11-5e368f4ee393','3d7f93cd-f290-4264-bf0e-c41209e661be'),('b853b351-450d-4118-bc11-5e368f4ee393','3f088c44-2438-4c12-a059-9c5f7cd7bb91'),('b853b351-450d-4118-bc11-5e368f4ee393','4a1ba9fc-8c9e-483b-a571-5eb9c32deab7'),('b853b351-450d-4118-bc11-5e368f4ee393','598187ac-1269-4a03-86cc-d750c2bdf38f'),('b853b351-450d-4118-bc11-5e368f4ee393','6545b863-d2fa-405a-9652-b865ce2a18d2'),('b853b351-450d-4118-bc11-5e368f4ee393','6dfd1a90-0dc2-4c3c-b215-73b22b80bb45'),('b853b351-450d-4118-bc11-5e368f4ee393','99d17210-eacd-4532-ae63-5f12ed3e18c0'),('b853b351-450d-4118-bc11-5e368f4ee393','ac4c458d-0efb-45db-bf3a-2e0ed1b4cd8d'),('b853b351-450d-4118-bc11-5e368f4ee393','bc936911-f489-4dc2-bc09-7470857311ed'),('b853b351-450d-4118-bc11-5e368f4ee393','d78f0286-a725-4368-83e5-65f10698f5af'),('b853b351-450d-4118-bc11-5e368f4ee393','dafcf648-dd5d-4246-b188-5ab506970f57'),('b853b351-450d-4118-bc11-5e368f4ee393','dd44bb70-568e-4ec1-b23b-ebd9e13668e6'),('b853b351-450d-4118-bc11-5e368f4ee393','ff79f9e7-c35d-467e-872c-6029814954c3'),('c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','24d4e71d-0b43-4fb0-b8a2-b4ae92f37508'),('c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','9973cd36-52e9-4f65-8b87-ea9b8b1e6a4e'),('c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','b1da0d05-f18b-4a05-a697-1a92843d3a18'),('c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','e0e28484-ed84-43ab-8925-b7ad0c900cf4'),('c443b4f6-b105-422c-9b98-5743d2b4b378','9f02de6a-c205-440b-8dbd-c41f3e72db34'),('d94d1505-4279-4956-8017-64dbb2eb87b0','0b2d58d7-e130-43ee-be42-829d77bffb6f'),('d94d1505-4279-4956-8017-64dbb2eb87b0','1e8957e0-981a-4901-b610-c0aea6955bd6'),('e0e28484-ed84-43ab-8925-b7ad0c900cf4','4999c871-223f-4858-808a-c89b75c02a48');
/*!40000 ALTER TABLE `COMPOSITE_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CREDENTIAL`
--

DROP TABLE IF EXISTS `CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CREDENTIAL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SALT` tinyblob,
  `TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `USER_LABEL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SECRET_DATA` longtext COLLATE utf8mb4_unicode_ci,
  `CREDENTIAL_DATA` longtext COLLATE utf8mb4_unicode_ci,
  `PRIORITY` int DEFAULT NULL,
  `VERSION` int DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IDX_USER_CREDENTIAL` (`USER_ID`),
  CONSTRAINT `FK_PFYR0GLASQYL0DEI3KL69R6V0` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CREDENTIAL`
--

LOCK TABLES `CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `CREDENTIAL` DISABLE KEYS */;
INSERT INTO `CREDENTIAL` VALUES ('0b521c66-d97b-4b09-8183-2421f26c6bf2',NULL,'password','6f56e56d-f8ef-4d1a-8f6b-032448476e28',1789954252872,'My password','{\"value\":\"B9TK2NEeCgo8lnxJ7zjr4i4vnY3E9Lk3P0Ii5sHirsE=\",\"salt\":\"cu8ZeanTxkEuW8CKdt0jWg==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10,1),('5cfb4409-b8d0-4d73-ab17-f3f2161cffd4',NULL,'password','ba1c28da-a84e-493c-9114-cbe05fdb502f',1789954029811,NULL,'{\"value\":\"2yWuRWou2aen+qXclPAUP2CV70jR3/M+OAV4lTuR0zg=\",\"salt\":\"a3IPe3PwrcAnaq2itav3+g==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10,0);
/*!40000 ALTER TABLE `CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `AUTHOR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FILENAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int NOT NULL,
  `EXECTYPE` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MD5SUM` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `COMMENTS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LIQUIBASE` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CONTEXTS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LABELS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`,`AUTHOR`,`FILENAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES ('1.0.0.Final-KEYCLOAK-5461','sthorger@redhat.com','META-INF/db2-jpa-changelog-1.0.0.Final.xml','2026-09-20 22:26:56',2,'MARK_RAN','9:828775b1596a07d1200ba1d49e5e3941','createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.0.0.Final-KEYCLOAK-5461','sthorger@redhat.com','META-INF/jpa-changelog-1.0.0.Final.xml','2026-09-20 22:26:56',1,'EXECUTED','9:6f1016664e21e16d26517a4418f5e3df','createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.1.0.Beta1','sthorger@redhat.com','META-INF/jpa-changelog-1.1.0.Beta1.xml','2026-09-20 22:26:56',3,'EXECUTED','9:5f090e44a7d595883c1fb61f4b41fd38','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.1.0.Final','sthorger@redhat.com','META-INF/jpa-changelog-1.1.0.Final.xml','2026-09-20 22:26:56',4,'EXECUTED','9:c07e577387a3d2c04d1adc9aaad8730e','renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.2.0.Beta1','psilva@redhat.com','META-INF/db2-jpa-changelog-1.2.0.Beta1.xml','2026-09-20 22:26:57',6,'MARK_RAN','9:543b5c9989f024fe35c6f6c5a97de88e','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.2.0.Beta1','psilva@redhat.com','META-INF/jpa-changelog-1.2.0.Beta1.xml','2026-09-20 22:26:57',5,'EXECUTED','9:b68ce996c655922dbcd2fe6b6ae72686','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.2.0.Final','keycloak','META-INF/jpa-changelog-1.2.0.Final.xml','2026-09-20 22:26:57',9,'EXECUTED','9:9d05c7be10cdb873f8bcb41bc3a8ab23','update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.2.0.RC1','bburke@redhat.com','META-INF/db2-jpa-changelog-1.2.0.CR1.xml','2026-09-20 22:26:57',8,'MARK_RAN','9:db4a145ba11a6fdaefb397f6dbf829a1','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.2.0.RC1','bburke@redhat.com','META-INF/jpa-changelog-1.2.0.CR1.xml','2026-09-20 22:26:57',7,'EXECUTED','9:765afebbe21cf5bbca048e632df38336','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.3.0','bburke@redhat.com','META-INF/jpa-changelog-1.3.0.xml','2026-09-20 22:26:58',10,'EXECUTED','9:18593702353128d53111f9b1ff0b82b8','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.4.0','bburke@redhat.com','META-INF/db2-jpa-changelog-1.4.0.xml','2026-09-20 22:26:58',12,'MARK_RAN','9:e1ff28bf7568451453f844c5d54bb0b5','delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.4.0','bburke@redhat.com','META-INF/jpa-changelog-1.4.0.xml','2026-09-20 22:26:58',11,'EXECUTED','9:6122efe5f090e41a85c0f1c9e52cbb62','delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.5.0','bburke@redhat.com','META-INF/jpa-changelog-1.5.0.xml','2026-09-20 22:26:58',13,'EXECUTED','9:7af32cd8957fbc069f796b61217483fd','delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.6.1','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2026-09-20 22:26:58',17,'EXECUTED','9:d41d8cd98f00b204e9800998ecf8427e','empty','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.6.1_from15','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2026-09-20 22:26:58',14,'EXECUTED','9:6005e15e84714cd83226bf7879f54190','addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.6.1_from16','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2026-09-20 22:26:58',16,'MARK_RAN','9:f8dadc9284440469dcf71e25ca6ab99b','dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.6.1_from16-pre','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2026-09-20 22:26:58',15,'MARK_RAN','9:bf656f5a2b055d07f314431cae76f06c','delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.7.0','bburke@redhat.com','META-INF/jpa-changelog-1.7.0.xml','2026-09-20 22:26:59',18,'EXECUTED','9:3368ff0be4c2855ee2dd9ca813b38d8e','createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.8.0','mposolda@redhat.com','META-INF/db2-jpa-changelog-1.8.0.xml','2026-09-20 22:26:59',21,'MARK_RAN','9:831e82914316dc8a57dc09d755f23c51','addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.8.0','mposolda@redhat.com','META-INF/jpa-changelog-1.8.0.xml','2026-09-20 22:26:59',19,'EXECUTED','9:8ac2fb5dd030b24c0570a763ed75ed20','addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.8.0-2','keycloak','META-INF/db2-jpa-changelog-1.8.0.xml','2026-09-20 22:26:59',22,'MARK_RAN','9:f91ddca9b19743db60e3057679810e6c','dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.8.0-2','keycloak','META-INF/jpa-changelog-1.8.0.xml','2026-09-20 22:26:59',20,'EXECUTED','9:f91ddca9b19743db60e3057679810e6c','dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.9.0','mposolda@redhat.com','META-INF/jpa-changelog-1.9.0.xml','2026-09-20 22:26:59',23,'EXECUTED','9:bc3d0f9e823a69dc21e23e94c7a94bb1','update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.9.1','keycloak','META-INF/db2-jpa-changelog-1.9.1.xml','2026-09-20 22:26:59',25,'MARK_RAN','9:0d6c65c6f58732d81569e77b10ba301d','modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.9.1','keycloak','META-INF/jpa-changelog-1.9.1.xml','2026-09-20 22:26:59',24,'EXECUTED','9:c9999da42f543575ab790e76439a2679','modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('1.9.2','keycloak','META-INF/jpa-changelog-1.9.2.xml','2026-09-20 22:26:59',26,'EXECUTED','9:fc576660fc016ae53d2d4778d84d86d0','createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('12.1.0-add-realm-localization-table','keycloak','META-INF/jpa-changelog-12.0.0.xml','2026-09-20 22:27:04',88,'EXECUTED','9:fffabce2bc01e1a8f5110d5278500065','createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS','',NULL,'4.33.0',NULL,NULL,'9954013300'),('13.0.0-increase-column-size-federated','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',94,'EXECUTED','9:43c0c1055b6761b4b3e89de76d612ccf','modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('13.0.0-KEYCLOAK-16844','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',91,'EXECUTED','9:ad1194d66c937e3ffc82386c050ba089','createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('13.0.0-KEYCLOAK-17992-drop-constraints','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',93,'MARK_RAN','9:544d201116a0fcc5a5da0925fbbc3bde','dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('13.0.0-KEYCLOAK-17992-recreate-constraints','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',95,'MARK_RAN','9:8bd711fd0330f4fe980494ca43ab1139','addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('14.0.0-KEYCLOAK-11019','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',97,'EXECUTED','9:24fb8611e97f29989bea412aa38d12b7','createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('14.0.0-KEYCLOAK-18286','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',98,'MARK_RAN','9:259f89014ce2506ee84740cbf7163aa7','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('14.0.0-KEYCLOAK-18286-revert','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',99,'MARK_RAN','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('14.0.0-KEYCLOAK-18286-supported-dbs','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',100,'EXECUTED','9:bd2bd0fc7768cf0845ac96a8786fa735','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('14.0.0-KEYCLOAK-18286-unsupported-dbs','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',101,'MARK_RAN','9:d3d977031d431db16e2c181ce49d73e9','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('15.0.0-KEYCLOAK-18467','keycloak','META-INF/jpa-changelog-15.0.0.xml','2026-09-20 22:27:04',104,'EXECUTED','9:47a760639ac597360a8219f5b768b4de','addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('17.0.0-9562','keycloak','META-INF/jpa-changelog-17.0.0.xml','2026-09-20 22:27:04',105,'EXECUTED','9:a6272f0576727dd8cad2522335f5d99e','createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('18.0.0-10625-IDX_ADMIN_EVENT_TIME','keycloak','META-INF/jpa-changelog-18.0.0.xml','2026-09-20 22:27:04',106,'EXECUTED','9:015479dbd691d9cc8669282f4828c41d','createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('18.0.15-30992-index-consent','keycloak','META-INF/jpa-changelog-18.0.15.xml','2026-09-20 22:27:04',107,'EXECUTED','9:80071ede7a05604b1f4906f3bf3b00f0','createIndex indexName=IDX_USCONSENT_SCOPE_ID, tableName=USER_CONSENT_CLIENT_SCOPE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('19.0.0-10135','keycloak','META-INF/jpa-changelog-19.0.0.xml','2026-09-20 22:27:04',108,'EXECUTED','9:9518e495fdd22f78ad6425cc30630221','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.1.0-KEYCLOAK-5461','bburke@redhat.com','META-INF/jpa-changelog-2.1.0.xml','2026-09-20 22:27:00',29,'EXECUTED','9:bd88e1f833df0420b01e114533aee5e8','createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.2.0','bburke@redhat.com','META-INF/jpa-changelog-2.2.0.xml','2026-09-20 22:27:00',30,'EXECUTED','9:a7022af5267f019d020edfe316ef4371','addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.3.0','bburke@redhat.com','META-INF/jpa-changelog-2.3.0.xml','2026-09-20 22:27:00',31,'EXECUTED','9:fc155c394040654d6a79227e56f5e25a','createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.4.0','bburke@redhat.com','META-INF/jpa-changelog-2.4.0.xml','2026-09-20 22:27:00',32,'EXECUTED','9:eac4ffb2a14795e5dc7b426063e54d88','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.5.0','bburke@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2026-09-20 22:27:00',33,'EXECUTED','9:54937c05672568c4c64fc9524c1e9462','customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.5.0-duplicate-email-support','slawomir@dabek.name','META-INF/jpa-changelog-2.5.0.xml','2026-09-20 22:27:00',36,'EXECUTED','9:61b6d3d7a4c0e0024b0c839da283da0c','addColumn tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.5.0-unicode-oracle','hmlnarik@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2026-09-20 22:27:00',34,'MARK_RAN','9:737ee933fd399814ed5e24f3b1bbe39d','modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.5.0-unicode-other-dbs','hmlnarik@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2026-09-20 22:27:00',35,'EXECUTED','9:33d72168746f81f98ae3a1e8e0ca3554','modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.5.0-unique-group-names','hmlnarik@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2026-09-20 22:27:00',37,'EXECUTED','9:8dcac7bdf7378e7d823cdfddebf72fda','addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('2.5.1','bburke@redhat.com','META-INF/jpa-changelog-2.5.1.xml','2026-09-20 22:27:00',38,'EXECUTED','9:a2b870802540cb3faa72098db5388af3','addColumn tableName=FED_USER_CONSENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('20.0.0-12964-supported-dbs','keycloak','META-INF/jpa-changelog-20.0.0.xml','2026-09-20 22:27:04',109,'EXECUTED','9:f2e1331a71e0aa85e5608fe42f7f681c','createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('20.0.0-12964-supported-dbs-edb-migration','keycloak','META-INF/jpa-changelog-20.0.0.xml','2026-09-20 22:27:04',110,'MARK_RAN','9:a6b18a8e38062df5793edbe064f4aecd','dropIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE; createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('20.0.0-12964-unsupported-dbs','keycloak','META-INF/jpa-changelog-20.0.0.xml','2026-09-20 22:27:04',111,'MARK_RAN','9:1a6fcaa85e20bdeae0a9ce49b41946a5','createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('21.0.2-17277','keycloak','META-INF/jpa-changelog-21.0.2.xml','2026-09-20 22:27:04',115,'EXECUTED','9:7ee1f7a3fb8f5588f171fb9a6ab623c0','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('21.1.0-19404','keycloak','META-INF/jpa-changelog-21.1.0.xml','2026-09-20 22:27:04',116,'EXECUTED','9:3d7e830b52f33676b9d64f7f2b2ea634','modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('21.1.0-19404-2','keycloak','META-INF/jpa-changelog-21.1.0.xml','2026-09-20 22:27:04',117,'MARK_RAN','9:627d032e3ef2c06c0e1f73d2ae25c26c','addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('22.0.0-17484-updated','keycloak','META-INF/jpa-changelog-22.0.0.xml','2026-09-20 22:27:04',118,'EXECUTED','9:90af0bfd30cafc17b9f4d6eccd92b8b3','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('22.0.5-24031','keycloak','META-INF/jpa-changelog-22.0.0.xml','2026-09-20 22:27:04',119,'MARK_RAN','9:a60d2d7b315ec2d3eba9e2f145f9df28','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('23.0.0-12062','keycloak','META-INF/jpa-changelog-23.0.0.xml','2026-09-20 22:27:04',120,'EXECUTED','9:2168fbe728fec46ae9baf15bf80927b8','addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG','',NULL,'4.33.0',NULL,NULL,'9954013300'),('23.0.0-17258','keycloak','META-INF/jpa-changelog-23.0.0.xml','2026-09-20 22:27:04',121,'EXECUTED','9:36506d679a83bbfda85a27ea1864dca8','addColumn tableName=EVENT_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.0-26618-drop-index-if-present','keycloak','META-INF/jpa-changelog-24.0.0.xml','2026-09-20 22:27:04',124,'MARK_RAN','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.0-26618-edb-migration','keycloak','META-INF/jpa-changelog-24.0.0.xml','2026-09-20 22:27:04',126,'MARK_RAN','9:2f684b29d414cd47efe3a3599f390741','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES; createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.0-26618-reindex','keycloak','META-INF/jpa-changelog-24.0.0.xml','2026-09-20 22:27:04',125,'EXECUTED','9:bd2bd0fc7768cf0845ac96a8786fa735','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.0-9758','keycloak','META-INF/jpa-changelog-24.0.0.xml','2026-09-20 22:27:04',122,'EXECUTED','9:502c557a5189f600f0f445a9b49ebbce','addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.0-9758-2','keycloak','META-INF/jpa-changelog-24.0.0.xml','2026-09-20 22:27:04',123,'EXECUTED','9:bf0fdee10afdf597a987adbf291db7b2','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.2-27228','keycloak','META-INF/jpa-changelog-24.0.2.xml','2026-09-20 22:27:04',127,'EXECUTED','9:eaee11f6b8aa25d2cc6a84fb86fc6238','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.2-27967-drop-index-if-present','keycloak','META-INF/jpa-changelog-24.0.2.xml','2026-09-20 22:27:04',128,'MARK_RAN','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('24.0.2-27967-reindex','keycloak','META-INF/jpa-changelog-24.0.2.xml','2026-09-20 22:27:04',129,'MARK_RAN','9:d3d977031d431db16e2c181ce49d73e9','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-2-mysql','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',136,'EXECUTED','9:b7ef76036d3126bb83c2423bf4d449d6','createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-2-not-mysql','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',137,'MARK_RAN','9:23396cf51ab8bc1ae6f0cac7f9f6fcf7','createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-cleanup-css-preload','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',135,'EXECUTED','9:5411d2fb2891d3e8d63ddb55dfa3c0c9','dropIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-cleanup-uss-by-usersess','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',134,'EXECUTED','9:6eee220d024e38e89c799417ec33667f','dropIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-cleanup-uss-createdon','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',132,'EXECUTED','9:78ab4fc129ed5e8265dbcc3485fba92f','dropIndex indexName=IDX_OFFLINE_USS_CREATEDON, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-cleanup-uss-preload','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',133,'EXECUTED','9:de5f7c1f7e10994ed8b62e621d20eaab','dropIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-index-creation','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',131,'EXECUTED','9:3e96709818458ae49f3c679ae58d263a','createIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28265-tables','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',130,'EXECUTED','9:deda2df035df23388af95bbd36c17cef','addColumn tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-28861-index-creation','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',142,'EXECUTED','9:b9acb58ac958d9ada0fe12a5d4794ab1','createIndex indexName=IDX_PERM_TICKET_REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; createIndex indexName=IDX_PERM_TICKET_OWNER, tableName=RESOURCE_SERVER_PERM_TICKET','',NULL,'4.33.0',NULL,NULL,'9954013300'),('25.0.0-org','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',138,'EXECUTED','9:5c859965c2c9b9c72136c360649af157','createTable tableName=ORG; addUniqueConstraint constraintName=UK_ORG_NAME, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_GROUP, tableName=ORG; createTable tableName=ORG_DOMAIN','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-32583-drop-redundant-index-on-client-session','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',150,'EXECUTED','9:24972d83bf27317a055d234187bb4af9','dropIndex indexName=IDX_US_SESS_ID_ON_CL_SESS, tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-33201-org-redirect-url','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',152,'EXECUTED','9:4d0e22b0ac68ebe9794fa9cb752ea660','addColumn tableName=ORG','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-idps-for-login','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',149,'EXECUTED','9:51f5fffadf986983d4bd59582c6c1604','addColumn tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_REALM_ORG, tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER; customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-org-alias','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',143,'EXECUTED','9:6ef7d63e4412b3c2d66ed179159886a4','addColumn tableName=ORG; update tableName=ORG; addNotNullConstraint columnName=ALIAS, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_ALIAS, tableName=ORG','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-org-group','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',144,'EXECUTED','9:da8e8087d80ef2ace4f89d8c5b9ca223','addColumn tableName=KEYCLOAK_GROUP; update tableName=KEYCLOAK_GROUP; addNotNullConstraint columnName=TYPE, tableName=KEYCLOAK_GROUP; customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-org-group-membership','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',146,'EXECUTED','9:a6ace2ce583a421d89b01ba2a28dc2d4','addColumn tableName=USER_GROUP_MEMBERSHIP; update tableName=USER_GROUP_MEMBERSHIP; addNotNullConstraint columnName=MEMBERSHIP_TYPE, tableName=USER_GROUP_MEMBERSHIP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0-org-indexes','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',145,'EXECUTED','9:79b05dcd610a8c7f25ec05135eec0857','createIndex indexName=IDX_ORG_DOMAIN_ORG_ID, tableName=ORG_DOMAIN','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.0.0.32582-remove-tables-user-session-user-session-note-and-client-session','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',151,'EXECUTED','9:febdc0f47f2ed241c59e60f58c3ceea5','dropTable tableName=CLIENT_SESSION_ROLE; dropTable tableName=CLIENT_SESSION_NOTE; dropTable tableName=CLIENT_SESSION_PROT_MAPPER; dropTable tableName=CLIENT_SESSION_AUTH_STATUS; dropTable tableName=CLIENT_USER_SESSION_NOTE; dropTable tableName=CLI...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.1.0-34013','keycloak','META-INF/jpa-changelog-26.1.0.xml','2026-09-20 22:27:05',154,'EXECUTED','9:e6b686a15759aef99a6d758a5c4c6a26','addColumn tableName=ADMIN_EVENT_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.1.0-34380','keycloak','META-INF/jpa-changelog-26.1.0.xml','2026-09-20 22:27:05',155,'EXECUTED','9:ac8b9edb7c2b6c17a1c7a11fcf5ccf01','dropTable tableName=USERNAME_LOGIN_FAILURE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.2.0-26106','keycloak','META-INF/jpa-changelog-26.2.0.xml','2026-09-20 22:27:05',157,'EXECUTED','9:b5877d5dab7d10ff3a9d209d7beb6680','addColumn tableName=CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.2.0-36750','keycloak','META-INF/jpa-changelog-26.2.0.xml','2026-09-20 22:27:05',156,'EXECUTED','9:b49ce951c22f7eb16480ff085640a33a','createTable tableName=SERVER_CONFIG','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.2.6-39866-duplicate','keycloak','META-INF/jpa-changelog-26.2.6.xml','2026-09-20 22:27:05',158,'EXECUTED','9:1dc67ccee24f30331db2cba4f372e40e','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.2.6-39866-uk','keycloak','META-INF/jpa-changelog-26.2.6.xml','2026-09-20 22:27:05',159,'EXECUTED','9:b70b76f47210cf0a5f4ef0e219eac7cd','addUniqueConstraint constraintName=UK_MIGRATION_VERSION, tableName=MIGRATION_MODEL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.2.6-40088-duplicate','keycloak','META-INF/jpa-changelog-26.2.6.xml','2026-09-20 22:27:05',160,'EXECUTED','9:cc7e02ed69ab31979afb1982f9670e8f','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.2.6-40088-uk','keycloak','META-INF/jpa-changelog-26.2.6.xml','2026-09-20 22:27:05',161,'EXECUTED','9:5bb848128da7bc4595cc507383325241','addUniqueConstraint constraintName=UK_MIGRATION_UPDATE_TIME, tableName=MIGRATION_MODEL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.3.0-groups-description','keycloak','META-INF/jpa-changelog-26.3.0.xml','2026-09-20 22:27:05',162,'EXECUTED','9:e1a3c05574326fb5b246b73b9a4c4d49','addColumn tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.4.0-40933-saml-encryption-attributes','keycloak','META-INF/jpa-changelog-26.4.0.xml','2026-09-20 22:27:05',163,'EXECUTED','9:7e9eaba362ca105efdda202303a4fe49','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.4.0-51321','keycloak','META-INF/jpa-changelog-26.4.0.xml','2026-09-20 22:27:05',164,'EXECUTED','9:34bab2bc56f75ffd7e347c580874e306','createIndex indexName=IDX_EVENT_ENTITY_USER_ID_TYPE, tableName=EVENT_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-add-remember-me','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',172,'EXECUTED','9:a7273ea8b21bd2f674c9c49141999f05','addColumn tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-add-sess-create-idx','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',174,'EXECUTED','9:aaee09e23a4d8468fbc5c51b7b314c58','createIndex indexName=IDX_USER_SESSION_EXPIRATION_LAST_REFRESH, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-add-sess-refresh-idx','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',173,'EXECUTED','9:ce49383d317ccbcd3434d1f21172b0b7','createIndex indexName=IDX_USER_SESSION_EXPIRATION_CREATED, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-drop-sess-refresh-idx','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',175,'EXECUTED','9:f0082210b6ccbbaf81287c27aa23753c','dropIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-idp-config-allow-null','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',169,'EXECUTED','9:b667fb087874303b324c1af7fae4f606','dropDefaultValue columnName=TRUST_EMAIL, tableName=IDENTITY_PROVIDER; dropNotNullConstraint columnName=TRUST_EMAIL, tableName=IDENTITY_PROVIDER; dropNotNullConstraint columnName=STORE_TOKEN, tableName=IDENTITY_PROVIDER; dropDefaultValue columnName...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-idp-config-allow-null-fixed-create-mssql-index','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',170,'MARK_RAN','9:dcbbb24c151c3b0b59f12fede23cc94d','createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-idp-config-allow-null-fixed-drop-mssql-index','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',168,'MARK_RAN','9:50c51d2c98cd1d624eb1c485c3cf1f75','dropIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-index-offline-css-by-client','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',166,'EXECUTED','9:680b59ca7854fa5b77a303301bb2a941','createIndex indexName=IDX_OFFLINE_CSS_BY_CLIENT, tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-index-offline-css-by-client-storage-provider','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',167,'EXECUTED','9:809bc160e2bc92f9c28eea39db323ae2','createIndex indexName=IDX_OFFLINE_CSS_BY_CLIENT_STORAGE_PROVIDER, tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-invitations-table-fixed2','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',177,'EXECUTED','9:322cb11fc03181903dcd67a54f8b3cf0','createTable tableName=ORG_INVITATION; addForeignKeyConstraint baseTableName=ORG_INVITATION, constraintName=FK_ORG_INVITATION_ORG, referencedTableName=ORG; createIndex indexName=IDX_ORG_INVITATION_ORG_ID, tableName=ORG_INVITATION; createIndex index...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-mysql-mariadb-default-charset-collation','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',176,'EXECUTED','9:1b383fa60d2db0a8952b365e725f9d16','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.5.0-remove-workflow-provider-id-column','keycloak','META-INF/jpa-changelog-26.5.0.xml','2026-09-20 22:27:05',171,'EXECUTED','9:d8eeb324484d45e946d03b953e168b21','dropIndex indexName=IDX_WORKFLOW_STATE_PROVIDER, tableName=WORKFLOW_STATE; createIndex indexName=IDX_WORKFLOW_STATE_PROVIDER, tableName=WORKFLOW_STATE; dropColumn columnName=WORKFLOW_PROVIDER_ID, tableName=WORKFLOW_STATE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-43829-user-created-timestamp-index','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',187,'EXECUTED','9:f2531a49b8bb21a7a97966d88fd1a411','createIndex indexName=IDX_USER_CREATED_TIMESTAMP, tableName=USER_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-44424-create-realm-in-client-session','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',182,'EXECUTED','9:77dbbc72d943e98cfe472ba8cc56a31c','addColumn tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-44424-idx-css-realm-and-clients','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',184,'EXECUTED','9:a093877fff41185ac24103be80e00968','createIndex indexName=IDX_OFFLINE_CSS_BY_CLIENT_AND_REALM, tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-44424-index-css-user-session-and-offline','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',181,'EXECUTED','9:a704d8598df241a3fd3cb91b6ab4b2d4','createIndex indexName=IDX_OFFLINE_CSS_BY_USER_SESSION_AND_OFFLINE, tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-44424-set-realm-in-client-session','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',183,'EXECUTED','9:3964a3148d32a55ef81126e23cdf6721','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-45009-broker-link-identity-provider','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',179,'EXECUTED','9:7d9a0253c9de7be754efef8bba4265bd','createIndex indexName=IDX_BROKER_LINK_IDENTITY_PROVIDER, tableName=BROKER_LINK','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-45009-broker-link-user-id','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',178,'EXECUTED','9:05026bbbc8d2ead5afcbda2f5fdf3a2b','createIndex indexName=IDX_BROKER_LINK_USER_ID, tableName=BROKER_LINK','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-48716-create-mssql-idp-index','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',188,'MARK_RAN','9:dcbbb24c151c3b0b59f12fede23cc94d','createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-add-last-modified-timestamp-user','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',185,'EXECUTED','9:8aa583d2cdd9e913dff42fecd626c560','addColumn tableName=USER_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-add-timestamps-group','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',186,'EXECUTED','9:4363d45dc25105a3fc5db9ff6936b0a9','addColumn tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.6.0-org-group-relationship','keycloak','META-INF/jpa-changelog-26.6.0.xml','2026-09-20 22:27:05',180,'EXECUTED','9:05685853fba030f53548ac6bf23245e3','addColumn tableName=KEYCLOAK_GROUP; addForeignKeyConstraint baseTableName=KEYCLOAK_GROUP, constraintName=FK_GROUP_ORGANIZATION, referencedTableName=ORG; createIndex indexName=IDX_GROUP_ORG_ID, tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-45292-realm-display-name-add-column','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',190,'EXECUTED','9:1de8c7824ce4fd7c739db6195f42be21','addColumn tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-45292-realm-display-name-migrate-data','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',191,'EXECUTED','9:293096bc554dd51428d1d9882f2de1dd','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-45292-realm-display-name-remove-attribute','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',192,'EXECUTED','9:a08357e3b0908c09d478e692cf82f865','delete tableName=REALM_ATTRIBUTE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-46204-issued-ver-credential-table','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',197,'EXECUTED','9:4918c6f68ba90ce417f1aaa031013168','createTable tableName=ISSUED_VER_CREDENTIAL; addPrimaryKey constraintName=PK_ISSUED_VER_CREDENTIAL, tableName=ISSUED_VER_CREDENTIAL; addForeignKeyConstraint baseTableName=ISSUED_VER_CREDENTIAL, constraintName=FK_ISSUED_VER_CREDENTIAL_USER, referen...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-9686-dynamic-scopes-consent','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',196,'EXECUTED','9:fb689bc3ff64e174d6319014b38876f1','addColumn tableName=USER_CONSENT_CLIENT_SCOPE; dropPrimaryKey constraintName=CONSTRAINT_GRNTCSNT_CLSC_PM, tableName=USER_CONSENT_CLIENT_SCOPE; addPrimaryKey constraintName=CONSTRAINT_GRNTCSNT_CLSC_PM, tableName=USER_CONSENT_CLIENT_SCOPE; addColumn...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-add-last-modified-timestamp-client','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:06',209,'EXECUTED','9:bae67d2faa5438ee35adfbb20a53c3c6','addColumn tableName=CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-add-timestamps-client','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',208,'EXECUTED','9:df5324c82398b446690b206c07649d40','addColumn tableName=CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-cluster-event','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:06',210,'EXECUTED','9:556b201eb9c378fa05d5bf22ec9c8dcf','createTable tableName=CLUSTER_EVENT; addPrimaryKey constraintName=PK_CLUSTER_EVENT, tableName=CLUSTER_EVENT; createIndex indexName=IDX_CLUSTER_EVENT_TARGET, tableName=CLUSTER_EVENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-federated-issued-ver-credential','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',200,'EXECUTED','9:3d610f5527879623a0d2362e64fa667f','createTable tableName=FED_ISSUED_VER_CREDENTIAL; addForeignKeyConstraint baseTableName=FED_ISSUED_VER_CREDENTIAL, constraintName=FK_FED_ISSUED_VC_VER_CRED, referencedTableName=FED_USER_VER_CREDENTIAL; createIndex indexName=IDX_FED_ISSUED_VC_USER, ...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-federated-verifiable-credentials-1','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',194,'EXECUTED','9:49092fa73b1c2b3afca48d91b8111c65','createTable tableName=FED_USER_VER_CREDENTIAL; addUniqueConstraint constraintName=UK_FED_USER_VC, tableName=FED_USER_VER_CREDENTIAL; createIndex indexName=IDX_FED_USER_VC_REALM_USER, tableName=FED_USER_VER_CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-issued-ver-credential-expires-at-index','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',198,'EXECUTED','9:ab9e4c0c9f21d9217ffe52968a3cf732','createIndex indexName=IDX_ISSUED_VER_CREDENTIAL_EXPIRES_AT, tableName=ISSUED_VER_CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-issued-ver-credential-vc-id-index','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',199,'EXECUTED','9:1c9b18926e48b4b66d0341400bd13834','createIndex indexName=IDX_ISSUED_VER_CREDENTIAL_VC, tableName=ISSUED_VER_CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-jdbcping-timestamp','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',189,'EXECUTED','9:9a91f62e494bd013594e007b74d01638','addColumn tableName=JGROUPS_PING','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-login-failure-index','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',207,'EXECUTED','9:f554afc6ad14784c99f6ad8811ac30ec','createIndex indexName=IDX_LOGIN_FAILURE_EXPIRE, tableName=LOGIN_FAILURE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-login-failure-table','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',206,'EXECUTED','9:671b50f88904b24ceb02463dd2d0c045','createTable tableName=LOGIN_FAILURE; addPrimaryKey constraintName=PK_LOGIN_FAILURE, tableName=LOGIN_FAILURE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-outbox','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',195,'EXECUTED','9:338b2743ca1be95f895d8f9b0cbe7b55','createTable tableName=OUTBOX_ENTRY; addUniqueConstraint constraintName=UC_OUTBOX_KIND_OWNER_CORRELATION, tableName=OUTBOX_ENTRY; createIndex indexName=IDX_OUTBOX_DRAIN, tableName=OUTBOX_ENTRY; createIndex indexName=IDX_OUTBOX_REALM, tableName=OUTB...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-persistent-auth-session-root-index','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',202,'EXECUTED','9:3090cd11d2dfeb5df754f41c0ffa35d7','createIndex indexName=IDX_ROOT_AUTH_SESSION_REALM, tableName=ROOT_AUTH_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-persistent-auth-session-root-table','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',201,'EXECUTED','9:ad622d5eebdf468747a0d08d2367a68e','createTable tableName=ROOT_AUTH_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-persistent-auth-session-table','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',203,'EXECUTED','9:609b8a172e43f617bb8920efd2b9ae5f','createTable tableName=AUTH_SESSION; addPrimaryKey constraintName=PK_AUTH_SESSION, tableName=AUTH_SESSION; addForeignKeyConstraint baseTableName=AUTH_SESSION, constraintName=FK_AUTH_SESSION_ROOT, referencedTableName=ROOT_AUTH_SESSION','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-single-use-object-index','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',205,'EXECUTED','9:b2ad66c013f48dc131ce109eface7fa5','createIndex indexName=IDX_SINGLE_USE_OBJ_EXPIRE, tableName=SINGLE_USE_OBJECT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-single-use-object-table','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',204,'EXECUTED','9:22bc4eb8e456b3b7be2808e457a44cb7','createTable tableName=SINGLE_USE_OBJECT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('26.7.0-verifiable-credential','keycloak','META-INF/jpa-changelog-26.7.0.xml','2026-09-20 22:27:05',193,'EXECUTED','9:68d8df23794085e79ba08b5046cba31d','createTable tableName=USER_VER_CREDENTIAL; addPrimaryKey constraintName=CONSTRAINT_VCRED_PM, tableName=USER_VER_CREDENTIAL; addForeignKeyConstraint baseTableName=USER_VER_CREDENTIAL, constraintName=FK_VCRED_USER, referencedTableName=USER_ENTITY; a...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('29399-jdbc-ping-default','keycloak','META-INF/jpa-changelog-26.1.0.xml','2026-09-20 22:27:04',153,'EXECUTED','9:007dbe99d7203fca403b89d4edfdf21e','createTable tableName=JGROUPS_PING; addPrimaryKey constraintName=CONSTRAINT_JGROUPS_PING, tableName=JGROUPS_PING','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.0.0','bburke@redhat.com','META-INF/jpa-changelog-3.0.0.xml','2026-09-20 22:27:00',39,'EXECUTED','9:132a67499ba24bcc54fb5cbdcfe7e4c0','addColumn tableName=IDENTITY_PROVIDER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.2.0-fix','keycloak','META-INF/jpa-changelog-3.2.0.xml','2026-09-20 22:27:00',40,'MARK_RAN','9:938f894c032f5430f2b0fafb1a243462','addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.2.0-fix-offline-sessions','hmlnarik','META-INF/jpa-changelog-3.2.0.xml','2026-09-20 22:27:00',42,'EXECUTED','9:fc86359c079781adc577c5a217e4d04c','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.2.0-fix-with-keycloak-5416','keycloak','META-INF/jpa-changelog-3.2.0.xml','2026-09-20 22:27:00',41,'MARK_RAN','9:845c332ff1874dc5d35974b0babf3006','dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.2.0-fixed','keycloak','META-INF/jpa-changelog-3.2.0.xml','2026-09-20 22:27:01',43,'EXECUTED','9:59a64800e3c0d09b825f8a3b444fa8f4','addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.3.0','keycloak','META-INF/jpa-changelog-3.3.0.xml','2026-09-20 22:27:01',44,'EXECUTED','9:d48d6da5c6ccf667807f633fe489ce88','addColumn tableName=USER_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.4.0','keycloak','META-INF/jpa-changelog-3.4.0.xml','2026-09-20 22:27:02',50,'EXECUTED','9:cfdd8736332ccdd72c5256ccb42335db','addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.4.0-KEYCLOAK-5230','hmlnarik@redhat.com','META-INF/jpa-changelog-3.4.0.xml','2026-09-20 22:27:02',51,'EXECUTED','9:7c84de3d9bd84d7f077607c1a4dcb714','createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.4.1','psilva@redhat.com','META-INF/jpa-changelog-3.4.1.xml','2026-09-20 22:27:02',52,'EXECUTED','9:5a6bb36cbefb6a9d6928452c0852af2d','modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.4.2','keycloak','META-INF/jpa-changelog-3.4.2.xml','2026-09-20 22:27:02',53,'EXECUTED','9:8f23e334dbc59f82e0a328373ca6ced0','update tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('3.4.2-KEYCLOAK-5172','mkanis@redhat.com','META-INF/jpa-changelog-3.4.2.xml','2026-09-20 22:27:02',54,'EXECUTED','9:9156214268f09d970cdf0e1564d866af','update tableName=CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('31296-persist-revoked-access-tokens','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',147,'EXECUTED','9:64ef94489d42a358e8304b0e245f0ed4','createTable tableName=REVOKED_TOKEN; addPrimaryKey constraintName=CONSTRAINT_RT, tableName=REVOKED_TOKEN','',NULL,'4.33.0',NULL,NULL,'9954013300'),('31725-index-persist-revoked-access-tokens','keycloak','META-INF/jpa-changelog-26.0.0.xml','2026-09-20 22:27:04',148,'EXECUTED','9:b994246ec2bf7c94da881e1d28782c7b','createIndex indexName=IDX_REV_TOKEN_ON_EXPIRE, tableName=REVOKED_TOKEN','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.0.0-CLEANUP-UNUSED-TABLE','bburke@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2026-09-20 22:27:02',56,'EXECUTED','9:229a041fb72d5beac76bb94a5fa709de','dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.0.0-KEYCLOAK-5579-fixed','mposolda@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2026-09-20 22:27:02',58,'EXECUTED','9:139b79bcbbfe903bb1c2d2a4dbf001d9','dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.0.0-KEYCLOAK-6228','bburke@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2026-09-20 22:27:02',57,'EXECUTED','9:079899dade9c1e683f26b2aa9ca6ff04','dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.0.0-KEYCLOAK-6335','bburke@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2026-09-20 22:27:02',55,'EXECUTED','9:db806613b1ed154826c02610b7dbdf74','createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.2.0-KEYCLOAK-6313','wadahiro@gmail.com','META-INF/jpa-changelog-4.2.0.xml','2026-09-20 22:27:03',63,'EXECUTED','9:92143a6daea0a3f3b8f598c97ce55c3d','addColumn tableName=REQUIRED_ACTION_PROVIDER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.3.0-KEYCLOAK-7984','wadahiro@gmail.com','META-INF/jpa-changelog-4.3.0.xml','2026-09-20 22:27:03',64,'EXECUTED','9:82bab26a27195d889fb0429003b18f40','update tableName=REQUIRED_ACTION_PROVIDER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.6.0-KEYCLOAK-7950','psilva@redhat.com','META-INF/jpa-changelog-4.6.0.xml','2026-09-20 22:27:03',65,'EXECUTED','9:e590c88ddc0b38b0ae4249bbfcb5abc3','update tableName=RESOURCE_SERVER_RESOURCE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.6.0-KEYCLOAK-8377','keycloak','META-INF/jpa-changelog-4.6.0.xml','2026-09-20 22:27:03',66,'EXECUTED','9:5c1f475536118dbdc38d5d7977950cc0','createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.6.0-KEYCLOAK-8555','gideonray@gmail.com','META-INF/jpa-changelog-4.6.0.xml','2026-09-20 22:27:03',67,'EXECUTED','9:e7c9f5f9c4d67ccbbcc215440c718a17','createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.7.0-KEYCLOAK-1267','sguilhen@redhat.com','META-INF/jpa-changelog-4.7.0.xml','2026-09-20 22:27:03',68,'EXECUTED','9:88e0bfdda924690d6f4e430c53447dd5','addColumn tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.7.0-KEYCLOAK-7275','keycloak','META-INF/jpa-changelog-4.7.0.xml','2026-09-20 22:27:03',69,'EXECUTED','9:f53177f137e1c46b6a88c59ec1cb5218','renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('4.8.0-KEYCLOAK-8835','sguilhen@redhat.com','META-INF/jpa-changelog-4.8.0.xml','2026-09-20 22:27:03',70,'EXECUTED','9:a74d33da4dc42a37ec27121580d1459f','addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('40343-workflow-state-table','keycloak','META-INF/jpa-changelog-26.4.0.xml','2026-09-20 22:27:05',165,'EXECUTED','9:ed3ab4723ceed210e5b5e60ac4562106','createTable tableName=WORKFLOW_STATE; addPrimaryKey constraintName=PK_WORKFLOW_STATE, tableName=WORKFLOW_STATE; addUniqueConstraint constraintName=UQ_WORKFLOW_RESOURCE, tableName=WORKFLOW_STATE; createIndex indexName=IDX_WORKFLOW_STATE_STEP, table...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('8.0.0-adding-credential-columns','keycloak','META-INF/jpa-changelog-8.0.0.xml','2026-09-20 22:27:03',72,'EXECUTED','9:aa072ad090bbba210d8f18781b8cebf4','addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('8.0.0-credential-cleanup-fixed','keycloak','META-INF/jpa-changelog-8.0.0.xml','2026-09-20 22:27:03',75,'EXECUTED','9:2b9cc12779be32c5b40e2e67711a218b','dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('8.0.0-resource-tag-support','keycloak','META-INF/jpa-changelog-8.0.0.xml','2026-09-20 22:27:03',76,'EXECUTED','9:91fa186ce7a5af127a2d7a91ee083cc5','addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('8.0.0-updating-credential-data-not-oracle-fixed','keycloak','META-INF/jpa-changelog-8.0.0.xml','2026-09-20 22:27:03',73,'EXECUTED','9:1ae6be29bab7c2aa376f6983b932be37','update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('8.0.0-updating-credential-data-oracle-fixed','keycloak','META-INF/jpa-changelog-8.0.0.xml','2026-09-20 22:27:03',74,'MARK_RAN','9:14706f286953fc9a25286dbd8fb30d97','update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.0-always-display-client','keycloak','META-INF/jpa-changelog-9.0.0.xml','2026-09-20 22:27:03',77,'EXECUTED','9:6335e5c94e83a2639ccd68dd24e2e5ad','addColumn tableName=CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.0-drop-constraints-for-column-increase','keycloak','META-INF/jpa-changelog-9.0.0.xml','2026-09-20 22:27:03',78,'MARK_RAN','9:6bdb5658951e028bfe16fa0a8228b530','dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.0-increase-column-size-federated-fk','keycloak','META-INF/jpa-changelog-9.0.0.xml','2026-09-20 22:27:03',79,'EXECUTED','9:d5bc15a64117ccad481ce8792d4c608f','modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.0-recreate-constraints-after-column-increase','keycloak','META-INF/jpa-changelog-9.0.0.xml','2026-09-20 22:27:03',80,'MARK_RAN','9:077cba51999515f4d3e7ad5619ab592c','addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.1-add-index-to-client.client_id','keycloak','META-INF/jpa-changelog-9.0.1.xml','2026-09-20 22:27:04',81,'EXECUTED','9:be969f08a163bf47c6b9e9ead8ac2afb','createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.1-add-index-to-events','keycloak','META-INF/jpa-changelog-9.0.1.xml','2026-09-20 22:27:04',85,'EXECUTED','9:7d93d602352a30c0c317e6a609b56599','createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.1-KEYCLOAK-12579-add-not-null-constraint','keycloak','META-INF/jpa-changelog-9.0.1.xml','2026-09-20 22:27:04',83,'EXECUTED','9:966bda61e46bebf3cc39518fbed52fa7','addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.1-KEYCLOAK-12579-drop-constraints','keycloak','META-INF/jpa-changelog-9.0.1.xml','2026-09-20 22:27:04',82,'MARK_RAN','9:6d3bb4408ba5a72f39bd8a0b301ec6e3','dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('9.0.1-KEYCLOAK-12579-recreate-constraints','keycloak','META-INF/jpa-changelog-9.0.1.xml','2026-09-20 22:27:04',84,'MARK_RAN','9:8dcac7bdf7378e7d823cdfddebf72fda','addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authn-3.4.0.CR1-refresh-token-max-reuse','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2026-09-20 22:27:01',49,'EXECUTED','9:d198654156881c46bfba39abd7769e69','addColumn tableName=REALM','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-2.0.0','psilva@redhat.com','META-INF/jpa-changelog-authz-2.0.0.xml','2026-09-20 22:26:59',27,'EXECUTED','9:43ed6b0da89ff77206289e87eaa9c024','createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-2.5.1','psilva@redhat.com','META-INF/jpa-changelog-authz-2.5.1.xml','2026-09-20 22:26:59',28,'EXECUTED','9:44bae577f551b3738740281eceb4ea70','update tableName=RESOURCE_SERVER_POLICY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-3.4.0.CR1-resource-server-pk-change-part1','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2026-09-20 22:27:01',45,'EXECUTED','9:dde36f7973e80d71fceee683bc5d2951','addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095','hmlnarik@redhat.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2026-09-20 22:27:01',46,'EXECUTED','9:b855e9b0a406b34fa323235a0cf4f640','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-3.4.0.CR1-resource-server-pk-change-part3-fixed','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2026-09-20 22:27:01',47,'MARK_RAN','9:51abbacd7b416c50c4421a8cabf7927e','dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2026-09-20 22:27:01',48,'EXECUTED','9:bdc99e567b3398bac83263d375aad143','addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-4.0.0.Beta3','psilva@redhat.com','META-INF/jpa-changelog-authz-4.0.0.Beta3.xml','2026-09-20 22:27:03',60,'EXECUTED','9:e0057eac39aa8fc8e09ac6cfa4ae15fe','addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-4.0.0.CR1','psilva@redhat.com','META-INF/jpa-changelog-authz-4.0.0.CR1.xml','2026-09-20 22:27:03',59,'EXECUTED','9:b55738ad889860c625ba2bf483495a04','createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-4.2.0.Final','mhajas@redhat.com','META-INF/jpa-changelog-authz-4.2.0.Final.xml','2026-09-20 22:27:03',61,'EXECUTED','9:42a33806f3a0443fe0e7feeec821326c','createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-4.2.0.Final-KEYCLOAK-9944','hmlnarik@redhat.com','META-INF/jpa-changelog-authz-4.2.0.Final.xml','2026-09-20 22:27:03',62,'EXECUTED','9:9968206fca46eecc1f51db9c024bfe56','addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS','',NULL,'4.33.0',NULL,NULL,'9954013300'),('authz-7.0.0-KEYCLOAK-10443','psilva@redhat.com','META-INF/jpa-changelog-authz-7.0.0.xml','2026-09-20 22:27:03',71,'EXECUTED','9:fd4ade7b90c3b67fae0bfcfcb42dfb5f','addColumn tableName=RESOURCE_SERVER','',NULL,'4.33.0',NULL,NULL,'9954013300'),('client-attributes-string-accomodation-fixed','keycloak','META-INF/jpa-changelog-20.0.0.xml','2026-09-20 22:27:04',113,'EXECUTED','9:3f332e13e90739ed0c35b0b25b7822ca','addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('client-attributes-string-accomodation-fixed-post-create-index','keycloak','META-INF/jpa-changelog-20.0.0.xml','2026-09-20 22:27:04',114,'MARK_RAN','9:bd2bd0fc7768cf0845ac96a8786fa735','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('client-attributes-string-accomodation-fixed-pre-drop-index','keycloak','META-INF/jpa-changelog-20.0.0.xml','2026-09-20 22:27:04',112,'EXECUTED','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('default-roles','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',89,'EXECUTED','9:fa8a5b5445e3857f4b010bafb5009957','addColumn tableName=REALM; customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('default-roles-cleanup','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',90,'EXECUTED','9:67ac3241df9a8582d591c5ed87125f39','dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES','',NULL,'4.33.0',NULL,NULL,'9954013300'),('json-string-accomodation-fixed','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',96,'EXECUTED','9:e07d2bc0970c348bb06fb63b1f82ddbf','addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('KEYCLOAK-17267-add-index-to-user-attributes','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',102,'EXECUTED','9:0b305d8d1277f3a89a0a53a659ad274c','createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE','',NULL,'4.33.0',NULL,NULL,'9954013300'),('KEYCLOAK-18146-add-saml-art-binding-identifier','keycloak','META-INF/jpa-changelog-14.0.0.xml','2026-09-20 22:27:04',103,'EXECUTED','9:2c374ad2cdfe20e2905a84c8fac48460','customChange','',NULL,'4.33.0',NULL,NULL,'9954013300'),('map-remove-ri','keycloak','META-INF/jpa-changelog-11.0.0.xml','2026-09-20 22:27:04',86,'EXECUTED','9:71c5969e6cdd8d7b6f47cebc86d37627','dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9','',NULL,'4.33.0',NULL,NULL,'9954013300'),('map-remove-ri','keycloak','META-INF/jpa-changelog-12.0.0.xml','2026-09-20 22:27:04',87,'EXECUTED','9:a9ba7d47f065f041b7da856a81762021','dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('map-remove-ri-13.0.0','keycloak','META-INF/jpa-changelog-13.0.0.xml','2026-09-20 22:27:04',92,'EXECUTED','9:d9be619d94af5a2f5d07b9f003543b91','dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('unique-consentuser','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',139,'MARK_RAN','9:5857626a2ea8767e9a6c66bf3a2cb32f','customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('unique-consentuser-edb-migration','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',140,'MARK_RAN','9:5857626a2ea8767e9a6c66bf3a2cb32f','customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...','',NULL,'4.33.0',NULL,NULL,'9954013300'),('unique-consentuser-mysql','keycloak','META-INF/jpa-changelog-25.0.0.xml','2026-09-20 22:27:04',141,'EXECUTED','9:b79478aad5adaa1bc428e31563f55e8e','customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...','',NULL,'4.33.0',NULL,NULL,'9954013300');
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int NOT NULL,
  `LOCKED` tinyint NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1,0,NULL,NULL),(1000,0,NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEFAULT_CLIENT_SCOPE`
--

DROP TABLE IF EXISTS `DEFAULT_CLIENT_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DEFAULT_CLIENT_SCOPE` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DEFAULT_SCOPE` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`REALM_ID`,`SCOPE_ID`),
  KEY `IDX_DEFCLS_REALM` (`REALM_ID`),
  KEY `IDX_DEFCLS_SCOPE` (`SCOPE_ID`),
  CONSTRAINT `FK_R_DEF_CLI_SCOPE_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEFAULT_CLIENT_SCOPE`
--

LOCK TABLES `DEFAULT_CLIENT_SCOPE` WRITE;
/*!40000 ALTER TABLE `DEFAULT_CLIENT_SCOPE` DISABLE KEYS */;
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('84ab64b6-3491-4ad3-8d0b-34567e32e313','04c239dd-9551-429c-8449-9a2c2af1fbdb',0),('84ab64b6-3491-4ad3-8d0b-34567e32e313','0c7363ad-14dd-4251-b417-320066960b32',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','1a80d43f-6fae-498e-99ec-9338390ea212',0),('84ab64b6-3491-4ad3-8d0b-34567e32e313','219699e4-526e-45e2-9b0c-d40f3b0256b3',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','3e4c76ce-54c0-48ad-80a0-3e59fd82b374',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','44025836-5c4a-4003-b9da-3cc785d53ef1',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','45184368-98fe-4bc6-acb6-fe4a82a66cc7',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','54c528ba-746e-47f4-917f-9ad4b710b011',0),('84ab64b6-3491-4ad3-8d0b-34567e32e313','cfaea429-dbd7-4700-81ea-3fc338cb3f77',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','d36a6820-93f8-4257-8cb0-f797106b49b1',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','e16864f1-ced5-4c30-bb89-bf358e8b1973',0),('84ab64b6-3491-4ad3-8d0b-34567e32e313','ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81',1),('84ab64b6-3491-4ad3-8d0b-34567e32e313','f9b9b4bf-db82-447f-b04a-8eadb2996ee6',0),('84ab64b6-3491-4ad3-8d0b-34567e32e313','ff30dceb-8390-442d-b3ba-58fdf6e9d253',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','03354559-2779-4844-808b-30f9fb5ac62c',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','16653460-af7b-4d28-ab0b-96c6fb09fe1a',0),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','200dfbf0-3014-41f3-bbbd-f5be3f86cd42',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','2adeb05e-a6e4-43b5-ae58-51768990b844',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','363951aa-fdf3-4c95-8ec2-a380dc6a56c1',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','3d201784-6f27-40b2-ab39-08b4f5521031',0),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','651c49f7-028b-456a-b4ae-9aef93eb1cc6',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','65212767-9df0-4e28-8c33-00546d81cf03',0),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','78e4132d-6e9c-429c-82b1-0bb738768f35',0),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','7d2e2940-2dd4-4bca-9c12-9ea859876e55',0),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','de4d5fc0-a083-4965-9342-560b44260320',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f26107a8-8445-47e5-be56-a9c62d0acfd9',1),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f696bde9-1154-4d45-b708-7fba87b83fbd',1);
/*!40000 ALTER TABLE `DEFAULT_CLIENT_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_ENTITY`
--

DROP TABLE IF EXISTS `EVENT_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EVENT_ENTITY` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DETAILS_JSON` text COLLATE utf8mb4_unicode_ci,
  `ERROR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SESSION_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EVENT_TIME` bigint DEFAULT NULL,
  `TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DETAILS_JSON_LONG_VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_EVENT_TIME` (`REALM_ID`,`EVENT_TIME`),
  KEY `IDX_EVENT_ENTITY_USER_ID_TYPE` (`USER_ID`,`TYPE`,`EVENT_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_ENTITY`
--

LOCK TABLES `EVENT_ENTITY` WRITE;
/*!40000 ALTER TABLE `EVENT_ENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `EVENT_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FEDERATED_IDENTITY`
--

DROP TABLE IF EXISTS `FEDERATED_IDENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FEDERATED_IDENTITY` (
  `IDENTITY_PROVIDER` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FEDERATED_USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FEDERATED_USERNAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TOKEN` text COLLATE utf8mb4_unicode_ci,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`,`USER_ID`),
  KEY `IDX_FEDIDENTITY_USER` (`USER_ID`),
  KEY `IDX_FEDIDENTITY_FEDUSER` (`FEDERATED_USER_ID`),
  CONSTRAINT `FK404288B92EF007A6` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEDERATED_IDENTITY`
--

LOCK TABLES `FEDERATED_IDENTITY` WRITE;
/*!40000 ALTER TABLE `FEDERATED_IDENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `FEDERATED_IDENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FEDERATED_USER`
--

DROP TABLE IF EXISTS `FEDERATED_USER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FEDERATED_USER` (
  `ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEDERATED_USER`
--

LOCK TABLES `FEDERATED_USER` WRITE;
/*!40000 ALTER TABLE `FEDERATED_USER` DISABLE KEYS */;
/*!40000 ALTER TABLE `FEDERATED_USER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_ISSUED_VER_CREDENTIAL`
--

DROP TABLE IF EXISTS `FED_ISSUED_VER_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_ISSUED_VER_CREDENTIAL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VER_CREDENTIAL_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ISSUED_AT` bigint NOT NULL,
  `EXPIRES_AT` bigint DEFAULT NULL,
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REVISION` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_FED_ISSUED_VC_USER` (`USER_ID`,`REALM_ID`,`ISSUED_AT`),
  KEY `IDX_FED_ISSUED_VC_EXPIRES` (`EXPIRES_AT`),
  KEY `IDX_FED_ISSUED_VC_CRED_ID` (`VER_CREDENTIAL_ID`),
  KEY `IDX_FED_ISSUED_VC_STORAGE` (`STORAGE_PROVIDER_ID`),
  CONSTRAINT `FK_FED_ISSUED_VC_VER_CRED` FOREIGN KEY (`VER_CREDENTIAL_ID`) REFERENCES `FED_USER_VER_CREDENTIAL` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_ISSUED_VER_CREDENTIAL`
--

LOCK TABLES `FED_ISSUED_VER_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `FED_ISSUED_VER_CREDENTIAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_ISSUED_VER_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_ATTRIBUTE`
--

DROP TABLE IF EXISTS `FED_USER_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_ATTRIBUTE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `VALUE` text COLLATE utf8mb4_unicode_ci,
  `LONG_VALUE_HASH` binary(64) DEFAULT NULL,
  `LONG_VALUE_HASH_LOWER_CASE` binary(64) DEFAULT NULL,
  `LONG_VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_FU_ATTRIBUTE` (`USER_ID`,`REALM_ID`,`NAME`),
  KEY `FED_USER_ATTR_LONG_VALUES` (`LONG_VALUE_HASH`,`NAME`),
  KEY `FED_USER_ATTR_LONG_VALUES_LOWER_CASE` (`LONG_VALUE_HASH_LOWER_CASE`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_ATTRIBUTE`
--

LOCK TABLES `FED_USER_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `FED_USER_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_CONSENT`
--

DROP TABLE IF EXISTS `FED_USER_CONSENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_CONSENT` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `LAST_UPDATED_DATE` bigint DEFAULT NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EXTERNAL_CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_FU_CONSENT` (`USER_ID`,`CLIENT_ID`),
  KEY `IDX_FU_CONSENT_RU` (`REALM_ID`,`USER_ID`),
  KEY `IDX_FU_CNSNT_EXT` (`USER_ID`,`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_CONSENT`
--

LOCK TABLES `FED_USER_CONSENT` WRITE;
/*!40000 ALTER TABLE `FED_USER_CONSENT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_CONSENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_CONSENT_CL_SCOPE`
--

DROP TABLE IF EXISTS `FED_USER_CONSENT_CL_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_CONSENT_CL_SCOPE` (
  `USER_CONSENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PARAMETER` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#N A#',
  PRIMARY KEY (`USER_CONSENT_ID`,`SCOPE_ID`,`PARAMETER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_CONSENT_CL_SCOPE`
--

LOCK TABLES `FED_USER_CONSENT_CL_SCOPE` WRITE;
/*!40000 ALTER TABLE `FED_USER_CONSENT_CL_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_CONSENT_CL_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_CREDENTIAL`
--

DROP TABLE IF EXISTS `FED_USER_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_CREDENTIAL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SALT` tinyblob,
  `TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_LABEL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SECRET_DATA` longtext COLLATE utf8mb4_unicode_ci,
  `CREDENTIAL_DATA` longtext COLLATE utf8mb4_unicode_ci,
  `PRIORITY` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_FU_CREDENTIAL` (`USER_ID`,`TYPE`),
  KEY `IDX_FU_CREDENTIAL_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_CREDENTIAL`
--

LOCK TABLES `FED_USER_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `FED_USER_CREDENTIAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_GROUP_MEMBERSHIP`
--

DROP TABLE IF EXISTS `FED_USER_GROUP_MEMBERSHIP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_GROUP_MEMBERSHIP` (
  `GROUP_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`,`USER_ID`),
  KEY `IDX_FU_GROUP_MEMBERSHIP` (`USER_ID`,`GROUP_ID`),
  KEY `IDX_FU_GROUP_MEMBERSHIP_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_GROUP_MEMBERSHIP`
--

LOCK TABLES `FED_USER_GROUP_MEMBERSHIP` WRITE;
/*!40000 ALTER TABLE `FED_USER_GROUP_MEMBERSHIP` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_GROUP_MEMBERSHIP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_REQUIRED_ACTION`
--

DROP TABLE IF EXISTS `FED_USER_REQUIRED_ACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_REQUIRED_ACTION` (
  `REQUIRED_ACTION` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`REQUIRED_ACTION`,`USER_ID`),
  KEY `IDX_FU_REQUIRED_ACTION` (`USER_ID`,`REQUIRED_ACTION`),
  KEY `IDX_FU_REQUIRED_ACTION_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_REQUIRED_ACTION`
--

LOCK TABLES `FED_USER_REQUIRED_ACTION` WRITE;
/*!40000 ALTER TABLE `FED_USER_REQUIRED_ACTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_REQUIRED_ACTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `FED_USER_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_ROLE_MAPPING` (
  `ROLE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ROLE_ID`,`USER_ID`),
  KEY `IDX_FU_ROLE_MAPPING` (`USER_ID`,`ROLE_ID`),
  KEY `IDX_FU_ROLE_MAPPING_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_ROLE_MAPPING`
--

LOCK TABLES `FED_USER_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `FED_USER_ROLE_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_VER_CREDENTIAL`
--

DROP TABLE IF EXISTS `FED_USER_VER_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_VER_CREDENTIAL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REVISION` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ATTRIBUTES` text COLLATE utf8mb4_unicode_ci,
  `CREATED_DATE` bigint DEFAULT NULL,
  `UPDATED_DATE` bigint DEFAULT NULL,
  `VERSION` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FED_USER_VC` (`USER_ID`,`CLIENT_SCOPE_ID`),
  KEY `IDX_FED_USER_VC_REALM_USER` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_VER_CREDENTIAL`
--

LOCK TABLES `FED_USER_VER_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `FED_USER_VER_CREDENTIAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_VER_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GROUP_ATTRIBUTE`
--

DROP TABLE IF EXISTS `GROUP_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GROUP_ATTRIBUTE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_GROUP_ATTR_GROUP` (`GROUP_ID`),
  KEY `IDX_GROUP_ATT_BY_NAME_VALUE` (`NAME`,`VALUE`),
  CONSTRAINT `FK_GROUP_ATTRIBUTE_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GROUP_ATTRIBUTE`
--

LOCK TABLES `GROUP_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `GROUP_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `GROUP_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GROUP_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `GROUP_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GROUP_ROLE_MAPPING` (
  `ROLE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `GROUP_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`GROUP_ID`),
  KEY `IDX_GROUP_ROLE_MAPP_GROUP` (`GROUP_ID`),
  CONSTRAINT `FK_GROUP_ROLE_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GROUP_ROLE_MAPPING`
--

LOCK TABLES `GROUP_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `GROUP_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `GROUP_ROLE_MAPPING` VALUES ('3243b7c1-abdf-4cfa-861c-84feab741b42','2b170f91-dec1-452a-946c-becbdab73b7c'),('8c639144-56a4-4acf-945e-570f501cd1fe','2b170f91-dec1-452a-946c-becbdab73b7c'),('b26bb5b6-2bb3-4fa7-8806-19109bec9cde','2b170f91-dec1-452a-946c-becbdab73b7c'),('b47c1454-cda5-43ae-b926-b35311f01578','2b170f91-dec1-452a-946c-becbdab73b7c'),('d2a3b217-9aae-4e35-8b35-4cc7e43f9bcb','2b170f91-dec1-452a-946c-becbdab73b7c');
/*!40000 ALTER TABLE `GROUP_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDENTITY_PROVIDER` (
  `INTERNAL_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENABLED` tinyint NOT NULL DEFAULT '0',
  `PROVIDER_ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `STORE_TOKEN` tinyint,
  `AUTHENTICATE_BY_DEFAULT` tinyint DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ADD_TOKEN_ROLE` tinyint DEFAULT NULL,
  `TRUST_EMAIL` tinyint DEFAULT NULL,
  `FIRST_BROKER_LOGIN_FLOW_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `POST_BROKER_LOGIN_FLOW_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_DISPLAY_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LINK_ONLY` tinyint DEFAULT NULL,
  `ORGANIZATION_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `HIDE_ON_LOGIN` tinyint,
  PRIMARY KEY (`INTERNAL_ID`),
  UNIQUE KEY `UK_2DAELWNIBJI49AVXSRTUF6XJ33` (`PROVIDER_ALIAS`,`REALM_ID`),
  KEY `IDX_IDENT_PROV_REALM` (`REALM_ID`),
  KEY `IDX_IDP_REALM_ORG` (`REALM_ID`,`ORGANIZATION_ID`),
  KEY `IDX_IDP_FOR_LOGIN` (`REALM_ID`,`ENABLED`,`LINK_ONLY`,`HIDE_ON_LOGIN`,`ORGANIZATION_ID`),
  CONSTRAINT `FK2B4EBC52AE5C3B34` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER`
--

LOCK TABLES `IDENTITY_PROVIDER` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER_CONFIG`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDENTITY_PROVIDER_CONFIG` (
  `IDENTITY_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER_ID`,`NAME`),
  CONSTRAINT `FKDC4897CF864C4E43` FOREIGN KEY (`IDENTITY_PROVIDER_ID`) REFERENCES `IDENTITY_PROVIDER` (`INTERNAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER_CONFIG`
--

LOCK TABLES `IDENTITY_PROVIDER_CONFIG` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER_MAPPER`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDENTITY_PROVIDER_MAPPER` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IDP_ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IDP_MAPPER_NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ID_PROV_MAPP_REALM` (`REALM_ID`),
  CONSTRAINT `FK_IDPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER_MAPPER`
--

LOCK TABLES `IDENTITY_PROVIDER_MAPPER` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDP_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `IDP_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDP_MAPPER_CONFIG` (
  `IDP_MAPPER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDP_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_IDPMCONFIG` FOREIGN KEY (`IDP_MAPPER_ID`) REFERENCES `IDENTITY_PROVIDER_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDP_MAPPER_CONFIG`
--

LOCK TABLES `IDP_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `IDP_MAPPER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDP_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ISSUED_VER_CREDENTIAL`
--

DROP TABLE IF EXISTS `ISSUED_VER_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ISSUED_VER_CREDENTIAL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VER_CREDENTIAL_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ISSUED_AT` bigint NOT NULL,
  `EXPIRES_AT` bigint DEFAULT NULL,
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REVISION` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ISSUED_VER_CREDENTIAL_USER` (`USER_ID`,`ISSUED_AT`),
  KEY `IDX_ISSUED_VER_CREDENTIAL_EXPIRES_AT` (`EXPIRES_AT`),
  KEY `IDX_ISSUED_VER_CREDENTIAL_VC` (`VER_CREDENTIAL_ID`),
  CONSTRAINT `FK_ISSUED_VER_CREDENTIAL_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`),
  CONSTRAINT `FK_ISSUED_VER_CREDENTIAL_VC` FOREIGN KEY (`VER_CREDENTIAL_ID`) REFERENCES `USER_VER_CREDENTIAL` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ISSUED_VER_CREDENTIAL`
--

LOCK TABLES `ISSUED_VER_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `ISSUED_VER_CREDENTIAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `ISSUED_VER_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JGROUPS_PING`
--

DROP TABLE IF EXISTS `JGROUPS_PING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JGROUPS_PING` (
  `address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cluster_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coord` tinyint DEFAULT NULL,
  `last_update` bigint DEFAULT NULL,
  `coordinated_by` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JGROUPS_PING`
--

LOCK TABLES `JGROUPS_PING` WRITE;
/*!40000 ALTER TABLE `JGROUPS_PING` DISABLE KEYS */;
/*!40000 ALTER TABLE `JGROUPS_PING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KEYCLOAK_GROUP`
--

DROP TABLE IF EXISTS `KEYCLOAK_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KEYCLOAK_GROUP` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `PARENT_GROUP` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TYPE` int NOT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ORG_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint DEFAULT NULL,
  `LAST_MODIFIED_TIMESTAMP` bigint DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SIBLING_NAMES` (`REALM_ID`,`PARENT_GROUP`,`NAME`),
  KEY `IDX_GROUP_ORG_ID` (`ORG_ID`),
  CONSTRAINT `FK_GROUP_ORGANIZATION` FOREIGN KEY (`ORG_ID`) REFERENCES `ORG` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KEYCLOAK_GROUP`
--

LOCK TABLES `KEYCLOAK_GROUP` WRITE;
/*!40000 ALTER TABLE `KEYCLOAK_GROUP` DISABLE KEYS */;
INSERT INTO `KEYCLOAK_GROUP` VALUES ('2b170f91-dec1-452a-946c-becbdab73b7c','swagger',' ','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'swagger',NULL,1789954029358,1789954029358);
/*!40000 ALTER TABLE `KEYCLOAK_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KEYCLOAK_ROLE`
--

DROP TABLE IF EXISTS `KEYCLOAK_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KEYCLOAK_ROLE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_REALM_CONSTRAINT` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_ROLE` tinyint DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_J3RWUVD56ONTGSUHOGM184WW2-2` (`NAME`,`CLIENT_REALM_CONSTRAINT`),
  KEY `IDX_KEYCLOAK_ROLE_CLIENT` (`CLIENT`),
  KEY `IDX_KEYCLOAK_ROLE_REALM` (`REALM`),
  CONSTRAINT `FK_6VYQFE4CN4WLQ8R6KT5VDSJ5C` FOREIGN KEY (`REALM`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KEYCLOAK_ROLE`
--

LOCK TABLES `KEYCLOAK_ROLE` WRITE;
/*!40000 ALTER TABLE `KEYCLOAK_ROLE` DISABLE KEYS */;
INSERT INTO `KEYCLOAK_ROLE` VALUES ('04b1dcd0-52c8-4902-99f1-5232813c9903','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-authorization}','view-authorization','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('05a0f015-abfa-4d60-bf0c-a94408b279cd','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-organizations}','view-organizations','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('097b6ab6-76e0-4b43-8409-7d5f99b7db33','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-realm}','view-realm','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('0b2d58d7-e130-43ee-be42-829d77bffb6f','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_query-groups}','query-groups','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('0f6975b9-def4-41e9-a518-826275c1e2b6','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_view-profile}','view-profile','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('1342c39d-7291-4898-95f0-5e06975cf062','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_query-users}','query-users','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('1ad8c6fd-75c7-4ffd-b3c2-3544bff05760','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-organizations}','view-organizations','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('1ceab581-252e-4fbf-94e0-f54a95b3d392','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-events}','manage-events','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('1e8957e0-981a-4901-b610-c0aea6955bd6','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_query-users}','query-users','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('20969521-24ee-4d4d-9fe9-691ca00ae4f6','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-users}','view-users','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('20da5824-73db-41d3-bbac-12746edfc486','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_view-groups}','view-groups','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('227a1dfc-6770-4e44-9275-27f7288cc105','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-events}','view-events','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('24d4e71d-0b43-4fb0-b8a2-b4ae92f37508','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,'${role_uma_authorization}','uma_authorization','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,NULL),('2501c436-5b3a-4b6f-82f0-d1f6230dd84f','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-clients}','view-clients','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('2517fdcc-2bd6-412c-9af6-e722b36b2831','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-users}','view-users','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('25777294-becf-4448-a78c-64c10a80f012','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,'${role_admin}','admin','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,NULL),('2ae01de1-213a-44f7-b00b-4aafc6ca5c78','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-realm}','manage-realm','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('2b3703cf-7a23-4287-8623-52a9f898b6c9','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-authorization}','manage-authorization','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('2bafb2c6-5463-4725-9368-2633f5aac513','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_impersonation}','impersonation','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('2fc80083-38ba-481f-8ef1-a61204cf8d96','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_create-client}','create-client','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('30645722-cc32-4365-85cf-423ec12fe978','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-realm}','manage-realm','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('3243b7c1-abdf-4cfa-861c-84feab741b42','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'Atualizar cadastrado','adm_cust_u','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('35634423-ce74-46f9-8b1c-b768eb998875','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-clients}','manage-clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('35c80c1d-f511-43ad-8b72-de2207b99aac','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_query-groups}','query-groups','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('35d0292a-eb78-4448-8b19-84dc5c1d4808','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,'${role_create-realm}','create-realm','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,NULL),('36b5f3c5-d5f7-4a5e-891c-ff96de42cc3e','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-identity-providers}','view-identity-providers','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('3d7f93cd-f290-4264-bf0e-c41209e661be','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-users}','manage-users','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('3f088c44-2438-4c12-a059-9c5f7cd7bb91','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-realm}','view-realm','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('400a4b6f-9e6b-4f42-9475-b596d3305093','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-identity-providers}','manage-identity-providers','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('45c7d519-83a7-4d9e-aba6-c51ad8917b6c','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-authorization}','manage-authorization','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('4999c871-223f-4858-808a-c89b75c02a48','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_manage-account-links}','manage-account-links','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('4a1ba9fc-8c9e-483b-a571-5eb9c32deab7','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-authorization}','view-authorization','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('4d6c35a0-d078-4276-819d-73907a4f8922','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_view-applications}','view-applications','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('4f6eaa8f-e2b9-44bd-8034-5230aae3f141','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_manage-consent}','manage-consent','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('52b17038-7b5d-40a7-8066-9821bf5c9436','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_query-organizations}','query-organizations','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('57edf169-286e-4350-942b-64975150d34c','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-identity-providers}','manage-identity-providers','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('598187ac-1269-4a03-86cc-d750c2bdf38f','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-realm}','manage-realm','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('5dfb9358-9b3c-43a8-b67b-ce455746b14e','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-realm}','view-realm','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('6123245b-7a96-4fc4-94aa-4276443ef839','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_manage-account}','manage-account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('6545b863-d2fa-405a-9652-b865ce2a18d2','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_query-realms}','query-realms','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('6614c47c-1dc7-4772-be37-671dfc613b5a','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-clients}','manage-clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('690188dd-5aa0-4586-99ff-a0e575c77300','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'${role_default-roles}','default-roles-video-locadora','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('6dfd1a90-0dc2-4c3c-b215-73b22b80bb45','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_query-clients}','query-clients','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('6e46c2ec-ee23-4c04-9b38-d31bbefcd68d','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_delete-account}','delete-account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('7b2eef06-8d2d-40ab-b338-c366f7bb410a','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_query-users}','query-users','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('7d3b78f7-59fe-4779-85c2-ce175e73ef44','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-users}','manage-users','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('86311bed-a30d-4921-8ae7-36bcf8e4a9d2','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_create-client}','create-client','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('867f4629-ba03-4a3f-9992-2369e7de4ff6','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'${role_offline-access}','offline_access','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('86aa1c0d-0fc4-4330-bab8-801a0a53b0cf','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_impersonation}','impersonation','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('8c639144-56a4-4acf-945e-570f501cd1fe','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'deletar usuario ','adm_cust_d','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('8e835bb4-953e-46c1-9b87-01a136f67f27','47b2e11a-979b-4582-a501-4551efac3954',1,'${role_read-token}','read-token','84ab64b6-3491-4ad3-8d0b-34567e32e313','47b2e11a-979b-4582-a501-4551efac3954',NULL),('8fc88c63-502d-476c-a60e-8e01a19a460a','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-organizations}','view-organizations','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('90380dde-63e1-4ff4-8c55-58a993da9e3a','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_manage-consent}','manage-consent','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('904c740f-3767-41b9-aec5-228da80c63d4','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-authorization}','manage-authorization','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('907c30c9-4a85-463e-9291-71d379a83ac1','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-authorization}','view-authorization','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('975f0ace-f7a6-4014-a595-91235de56b6d','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_delete-account}','delete-account','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('985de630-1e4d-48a7-8b2d-55d717c11cc1','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-clients}','view-clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('9973cd36-52e9-4f65-8b87-ea9b8b1e6a4e','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,'${role_offline-access}','offline_access','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,NULL),('99d17210-eacd-4532-ae63-5f12ed3e18c0','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-identity-providers}','manage-identity-providers','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('9f02de6a-c205-440b-8dbd-c41f3e72db34','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_query-clients}','query-clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('a3427169-9a5a-46a1-8e99-7ec8c2c9e3de','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-users}','manage-users','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('a5972f9d-5c81-4e00-982f-bedbe3358701','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_view-consent}','view-consent','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('aae5998d-061e-455c-999b-3901bd486f81','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-events}','manage-events','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('ac4c458d-0efb-45db-bf3a-2e0ed1b4cd8d','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-clients}','manage-clients','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('ae11bf96-e7f6-4ef6-924c-a4a193acb0db','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-events}','view-events','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('aff53c8b-768c-46f0-9149-6aa7ed5e2874','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-events}','view-events','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('b09b9c87-c1ab-4e1d-816e-5a1c6c6ae11d','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_query-organizations}','query-organizations','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('b1da0d05-f18b-4a05-a697-1a92843d3a18','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_view-profile}','view-profile','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('b21942c2-d0b2-46eb-b925-213a1bca2ca2','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_manage-organizations}','manage-organizations','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('b26bb5b6-2bb3-4fa7-8806-19109bec9cde','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'Atualizar cliente','cust_u','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('b47c1454-cda5-43ae-b926-b35311f01578','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'Acesso do usuario padrao','cust_r','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('b853b351-450d-4118-bc11-5e368f4ee393','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_realm-admin}','realm-admin','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('b89ef273-0124-4edb-84c2-589a587a795d','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_view-identity-providers}','view-identity-providers','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('b8c2c844-4cdb-4aad-b53b-0be7b9c20675','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_query-clients}','query-clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('bc936911-f489-4dc2-bc09-7470857311ed','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_impersonation}','impersonation','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('bec49d6f-1e07-4f6e-9ba6-ce3a8aa8f0d2','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_manage-account-links}','manage-account-links','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('bf6100b6-1dff-4195-b8ed-82be1645dfc8','012ee43d-aafd-493e-8a05-55fb09b91cd0',1,'${role_read-token}','read-token','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','012ee43d-aafd-493e-8a05-55fb09b91cd0',NULL),('bfad8187-d5d1-4012-88b5-92df67a694ca','39076246-ac23-4c54-b55d-fefb0ab17939',1,'${role_query-realms}','query-realms','84ab64b6-3491-4ad3-8d0b-34567e32e313','39076246-ac23-4c54-b55d-fefb0ab17939',NULL),('c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,'${role_default-roles}','default-roles-master','84ab64b6-3491-4ad3-8d0b-34567e32e313',NULL,NULL),('c443b4f6-b105-422c-9b98-5743d2b4b378','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-clients}','view-clients','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('ce1beaab-6d75-4d98-b4a4-84a41aff73d9','f303bf4d-7b07-4a58-85b6-455d24269265',1,'${role_view-groups}','view-groups','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','f303bf4d-7b07-4a58-85b6-455d24269265',NULL),('d119dc27-6970-4b4f-9b0b-71485d78abfb','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-events}','manage-events','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('d2a3b217-9aae-4e35-8b35-4cc7e43f9bcb','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'Acesso adminstrativo','adm_cust_r','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('d3db78fb-d7b6-4bac-9a5c-22a762db9438','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_view-applications}','view-applications','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('d78f0286-a725-4368-83e5-65f10698f5af','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_view-identity-providers}','view-identity-providers','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('d94d1505-4279-4956-8017-64dbb2eb87b0','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_view-users}','view-users','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('d99dab99-14e8-44af-be55-7f85a98dc3ae','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_query-realms}','query-realms','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('da77e38c-d138-42a6-aa8e-c6fb622dabb4','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,'${role_uma_authorization}','uma_authorization','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',NULL,NULL),('dafcf648-dd5d-4246-b188-5ab506970f57','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_query-organizations}','query-organizations','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('dd44bb70-568e-4ec1-b23b-ebd9e13668e6','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_query-groups}','query-groups','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL),('e0e28484-ed84-43ab-8925-b7ad0c900cf4','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_manage-account}','manage-account','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('e4bacb5d-92b6-4d64-a6cd-33c6e1430bd9','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',1,'${role_view-consent}','view-consent','84ab64b6-3491-4ad3-8d0b-34567e32e313','5fc24b16-6cf5-400c-aecb-c7f50ddd7003',NULL),('e5980985-aeb2-456a-9a35-f8ac3b9441ae','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_manage-organizations}','manage-organizations','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('fbbeac5e-5f79-40b8-aa21-7a868e0ef82f','fead954d-b832-4e09-a767-93f6ef398331',1,'${role_create-client}','create-client','84ab64b6-3491-4ad3-8d0b-34567e32e313','fead954d-b832-4e09-a767-93f6ef398331',NULL),('ff79f9e7-c35d-467e-872c-6029814954c3','82b7a479-742d-4ea5-a042-d9b286560c27',1,'${role_manage-organizations}','manage-organizations','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','82b7a479-742d-4ea5-a042-d9b286560c27',NULL);
/*!40000 ALTER TABLE `KEYCLOAK_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOGIN_FAILURE`
--

DROP TABLE IF EXISTS `LOGIN_FAILURE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOGIN_FAILURE` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FAILED_LOGIN_NOT_BEFORE` bigint DEFAULT '0',
  `NUM_FAILURES` int DEFAULT '0',
  `NUM_TEMPORARY_LOCKOUTS` int DEFAULT '0',
  `LAST_FAILURE` bigint DEFAULT '0',
  `LAST_IP_FAILURE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NUM_SECONDARY_AUTH_FAILURES` int DEFAULT '0',
  PRIMARY KEY (`REALM_ID`,`USER_ID`),
  KEY `IDX_LOGIN_FAILURE_EXPIRE` (`LAST_FAILURE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOGIN_FAILURE`
--

LOCK TABLES `LOGIN_FAILURE` WRITE;
/*!40000 ALTER TABLE `LOGIN_FAILURE` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOGIN_FAILURE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATION_MODEL`
--

DROP TABLE IF EXISTS `MIGRATION_MODEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATION_MODEL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VERSION` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UPDATE_TIME` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_MIGRATION_UPDATE_TIME` (`UPDATE_TIME`),
  UNIQUE KEY `UK_MIGRATION_VERSION` (`VERSION`),
  KEY `IDX_UPDATE_TIME` (`UPDATE_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATION_MODEL`
--

LOCK TABLES `MIGRATION_MODEL` WRITE;
/*!40000 ALTER TABLE `MIGRATION_MODEL` DISABLE KEYS */;
INSERT INTO `MIGRATION_MODEL` VALUES ('dpt37','26.7.4',1789954027);
/*!40000 ALTER TABLE `MIGRATION_MODEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFLINE_CLIENT_SESSION`
--

DROP TABLE IF EXISTS `OFFLINE_CLIENT_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OFFLINE_CLIENT_SESSION` (
  `USER_SESSION_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OFFLINE_FLAG` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TIMESTAMP` int DEFAULT NULL,
  `DATA` longtext COLLATE utf8mb4_unicode_ci,
  `CLIENT_STORAGE_PROVIDER` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `EXTERNAL_CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `VERSION` int DEFAULT '0',
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`USER_SESSION_ID`,`CLIENT_ID`,`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_CSS_BY_CLIENT` (`CLIENT_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_CSS_BY_CLIENT_STORAGE_PROVIDER` (`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_CSS_BY_USER_SESSION_AND_OFFLINE` (`OFFLINE_FLAG`,`USER_SESSION_ID`),
  KEY `IDX_OFFLINE_CSS_BY_CLIENT_AND_REALM` (`REALM_ID`,`OFFLINE_FLAG`,`CLIENT_ID`,`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFLINE_CLIENT_SESSION`
--

LOCK TABLES `OFFLINE_CLIENT_SESSION` WRITE;
/*!40000 ALTER TABLE `OFFLINE_CLIENT_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `OFFLINE_CLIENT_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFLINE_USER_SESSION`
--

DROP TABLE IF EXISTS `OFFLINE_USER_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OFFLINE_USER_SESSION` (
  `USER_SESSION_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CREATED_ON` int NOT NULL,
  `OFFLINE_FLAG` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DATA` longtext COLLATE utf8mb4_unicode_ci,
  `LAST_SESSION_REFRESH` int NOT NULL DEFAULT '0',
  `BROKER_SESSION_ID` text COLLATE utf8mb4_unicode_ci,
  `VERSION` int DEFAULT '0',
  `REMEMBER_ME` tinyint DEFAULT NULL,
  PRIMARY KEY (`USER_SESSION_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_USS_BY_USER` (`USER_ID`,`REALM_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_USS_BY_BROKER_SESSION_ID` (`BROKER_SESSION_ID`(255),`REALM_ID`),
  KEY `IDX_USER_SESSION_EXPIRATION_CREATED` (`REALM_ID`,`OFFLINE_FLAG`,`REMEMBER_ME`,`CREATED_ON`,`USER_SESSION_ID`,`USER_ID`),
  KEY `IDX_USER_SESSION_EXPIRATION_LAST_REFRESH` (`REALM_ID`,`OFFLINE_FLAG`,`REMEMBER_ME`,`LAST_SESSION_REFRESH`,`USER_SESSION_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFLINE_USER_SESSION`
--

LOCK TABLES `OFFLINE_USER_SESSION` WRITE;
/*!40000 ALTER TABLE `OFFLINE_USER_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `OFFLINE_USER_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORG`
--

DROP TABLE IF EXISTS `ORG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORG` (
  `ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENABLED` tinyint NOT NULL,
  `REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `GROUP_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_unicode_ci,
  `ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REDIRECT_URL` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_ORG_NAME` (`REALM_ID`,`NAME`),
  UNIQUE KEY `UK_ORG_GROUP` (`GROUP_ID`),
  UNIQUE KEY `UK_ORG_ALIAS` (`REALM_ID`,`ALIAS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORG`
--

LOCK TABLES `ORG` WRITE;
/*!40000 ALTER TABLE `ORG` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORG_DOMAIN`
--

DROP TABLE IF EXISTS `ORG_DOMAIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORG_DOMAIN` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VERIFIED` tinyint NOT NULL,
  `ORG_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`,`NAME`),
  KEY `IDX_ORG_DOMAIN_ORG_ID` (`ORG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORG_DOMAIN`
--

LOCK TABLES `ORG_DOMAIN` WRITE;
/*!40000 ALTER TABLE `ORG_DOMAIN` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORG_DOMAIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORG_INVITATION`
--

DROP TABLE IF EXISTS `ORG_INVITATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORG_INVITATION` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ORGANIZATION_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FIRST_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_AT` int NOT NULL,
  `EXPIRES_AT` int DEFAULT NULL,
  `INVITE_LINK` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_ORG_INVITATION_EMAIL` (`ORGANIZATION_ID`,`EMAIL`),
  KEY `IDX_ORG_INVITATION_ORG_ID` (`ORGANIZATION_ID`),
  KEY `IDX_ORG_INVITATION_EMAIL` (`EMAIL`),
  KEY `IDX_ORG_INVITATION_EXPIRES` (`EXPIRES_AT`),
  CONSTRAINT `FK_ORG_INVITATION_ORG` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `ORG` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORG_INVITATION`
--

LOCK TABLES `ORG_INVITATION` WRITE;
/*!40000 ALTER TABLE `ORG_INVITATION` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORG_INVITATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OUTBOX_ENTRY`
--

DROP TABLE IF EXISTS `OUTBOX_ENTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OUTBOX_ENTRY` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENTRY_KIND` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OWNER_ID` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CONTAINER_ID` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CORRELATION_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENTRY_TYPE` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `PAYLOAD` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `METADATA` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `STATUS` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ATTEMPTS` int NOT NULL DEFAULT '0',
  `NEXT_ATTEMPT_AT` timestamp NOT NULL,
  `LAST_ERROR` text COLLATE utf8mb4_unicode_ci,
  `CREATED_AT` timestamp NOT NULL,
  `DELIVERED_AT` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UC_OUTBOX_KIND_OWNER_CORRELATION` (`ENTRY_KIND`,`OWNER_ID`,`CORRELATION_ID`),
  KEY `IDX_OUTBOX_DRAIN` (`ENTRY_KIND`,`STATUS`,`NEXT_ATTEMPT_AT`),
  KEY `IDX_OUTBOX_REALM` (`ENTRY_KIND`,`REALM_ID`,`STATUS`),
  KEY `IDX_OUTBOX_OWNER` (`ENTRY_KIND`,`OWNER_ID`,`STATUS`),
  KEY `IDX_OUTBOX_CONTAINER` (`ENTRY_KIND`,`OWNER_ID`,`CONTAINER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OUTBOX_ENTRY`
--

LOCK TABLES `OUTBOX_ENTRY` WRITE;
/*!40000 ALTER TABLE `OUTBOX_ENTRY` DISABLE KEYS */;
/*!40000 ALTER TABLE `OUTBOX_ENTRY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `POLICY_CONFIG`
--

DROP TABLE IF EXISTS `POLICY_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `POLICY_CONFIG` (
  `POLICY_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`POLICY_ID`,`NAME`),
  CONSTRAINT `FKDC34197CF864C4E43` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `POLICY_CONFIG`
--

LOCK TABLES `POLICY_CONFIG` WRITE;
/*!40000 ALTER TABLE `POLICY_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `POLICY_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROTOCOL_MAPPER`
--

DROP TABLE IF EXISTS `PROTOCOL_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROTOCOL_MAPPER` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PROTOCOL` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PROTOCOL_MAPPER_NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_PROTOCOL_MAPPER_CLIENT` (`CLIENT_ID`),
  KEY `IDX_CLSCOPE_PROTMAP` (`CLIENT_SCOPE_ID`),
  CONSTRAINT `FK_CLI_SCOPE_MAPPER` FOREIGN KEY (`CLIENT_SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`),
  CONSTRAINT `FK_PCM_REALM` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROTOCOL_MAPPER`
--

LOCK TABLES `PROTOCOL_MAPPER` WRITE;
/*!40000 ALTER TABLE `PROTOCOL_MAPPER` DISABLE KEYS */;
INSERT INTO `PROTOCOL_MAPPER` VALUES ('0553891b-a8d3-445e-b277-06208a04e501','given name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','locale','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('05b4476d-6eb3-47a8-a6be-2368006012e1','role list','saml','saml-role-list-mapper',NULL,'03354559-2779-4844-808b-30f9fb5ac62c'),('069fd744-1158-4ce2-9ca9-1b82425a04cb','audience resolve','openid-connect','oidc-audience-resolve-mapper','5ba1d38b-7896-475c-a275-f8b0be01b81d',NULL),('089a95c5-1cce-449a-8593-d7d4358a1d9d','client roles','openid-connect','oidc-usermodel-client-role-mapper',NULL,'f696bde9-1154-4d45-b708-7fba87b83fbd'),('0b079277-0937-4bd9-bd8c-8dbd64284495','address','openid-connect','oidc-address-mapper',NULL,'16653460-af7b-4d28-ab0b-96c6fb09fe1a'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','locale','openid-connect','oidc-usermodel-attribute-mapper','2524ca06-c64e-4850-b4e5-af745f459add',NULL),('13579438-6758-467f-af89-72bc9bb7b61b','Client IP Address','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'2c753b35-118a-48d9-ab0f-8d33a8b5b0bd'),('1487ca4a-2982-4770-ad2f-b1abc143796e','zoneinfo','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('14ed2b2f-5e2a-4181-8925-39dd06af52f9','full name','openid-connect','oidc-full-name-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('179774f3-50c7-4576-bbd6-0b718615322b','phone number','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3d201784-6f27-40b2-ab39-08b4f5521031'),('21970564-f66d-44b9-b9ef-570af96e7db4','Client IP Address','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'8d331b20-a42d-420b-9b2c-2caafb22ca64'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','realm roles','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'0c7363ad-14dd-4251-b417-320066960b32'),('2fd52fda-1eeb-47fb-881f-06637b060f37','locale','openid-connect','oidc-usermodel-attribute-mapper','c1e0cfff-9220-423f-9320-c191c13802de',NULL),('3245cb34-2dc9-4168-bcee-25dbb4896997','phone number','openid-connect','oidc-usermodel-attribute-mapper',NULL,'f9b9b4bf-db82-447f-b04a-8eadb2996ee6'),('38de27f9-d29a-48b7-a8f2-dcaa09486237','audience resolve','openid-connect','oidc-audience-resolve-mapper',NULL,'f696bde9-1154-4d45-b708-7fba87b83fbd'),('4154012e-687e-4a2e-a802-bb66f5759b38','organization','openid-connect','oidc-organization-membership-mapper',NULL,'1a80d43f-6fae-498e-99ec-9338390ea212'),('469806d8-aa52-490f-b646-0f2a0fa57b55','groups','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'e16864f1-ced5-4c30-bb89-bf358e8b1973'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','username','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','phone number verified','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3d201784-6f27-40b2-ab39-08b4f5521031'),('5222a785-7655-404e-b9e2-19fa79535110','updated at','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','profile','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('57def3a9-08ca-479a-bdef-e3a6bcd60662','acr loa level','openid-connect','oidc-acr-mapper',NULL,'d36a6820-93f8-4257-8cb0-f797106b49b1'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','profile','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('6095c17e-21d8-456c-8767-ddb4a839968c','client roles','openid-connect','oidc-usermodel-client-role-mapper',NULL,'0c7363ad-14dd-4251-b417-320066960b32'),('611ebdaa-355d-4270-bbcc-0e0b4c136057','acr loa level','openid-connect','oidc-acr-mapper',NULL,'f26107a8-8445-47e5-be56-a9c62d0acfd9'),('623ba149-c916-4830-94fd-6aa2abbe7d30','middle name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('65ad2119-9a74-4d37-84aa-e7f630d61635','website','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('66570280-82c5-4d31-85eb-6a4a2135eeef','Client ID','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'8d331b20-a42d-420b-9b2c-2caafb22ca64'),('69656e4a-037a-4b82-a22c-e385b5419c29','auth_time','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'363951aa-fdf3-4c95-8ec2-a380dc6a56c1'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','birthdate','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('7722532c-9b16-450d-919c-f711a4303c32','Client Host','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'8d331b20-a42d-420b-9b2c-2caafb22ca64'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','middle name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('82ad2b96-91be-4267-be85-43ab37749f86','email','openid-connect','oidc-usermodel-attribute-mapper',NULL,'219699e4-526e-45e2-9b0c-d40f3b0256b3'),('8608a145-616a-4477-8382-3242f191f3a1','audience resolve','openid-connect','oidc-audience-resolve-mapper','629abc42-f3c2-47d5-8e7b-e6a61818e495',NULL),('86718f60-197d-4193-a5d7-7b6490bb3107','gender','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('868e5f72-710b-4985-97dc-ffaa6aba56db','locale','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('917bdebf-f2ad-4120-b6e4-ff05a316ced6','AuthnContextClassRef','saml','saml-authn-context-class-ref-mapper',NULL,'de4d5fc0-a083-4965-9342-560b44260320'),('923bcdb9-2879-467e-b66c-3d85147a801e','nickname','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('990cbcbe-ea36-4e2e-9108-4434b06d287f','allowed web origins','openid-connect','oidc-allowed-origins-mapper',NULL,'2adeb05e-a6e4-43b5-ae58-51768990b844'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','gender','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','website','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('9bd88f78-ef72-4000-afae-02f85ca61e54','organization','saml','saml-organization-membership-mapper',NULL,'200dfbf0-3014-41f3-bbbd-f5be3f86cd42'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','given name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('a03c8a64-61cb-469d-9697-4c5168899c3b','realm roles','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'f696bde9-1154-4d45-b708-7fba87b83fbd'),('a0c6a654-2c99-4e19-ab67-331e28473527','zoneinfo','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('a0e01a37-e9c8-4b60-9ec0-7cf5350ac300','role list','saml','saml-role-list-mapper',NULL,'3e4c76ce-54c0-48ad-80a0-3e59fd82b374'),('a1679363-1af7-4100-a2ff-aed1aa85272c','AuthnContextClassRef','saml','saml-authn-context-class-ref-mapper',NULL,'cfaea429-dbd7-4700-81ea-3fc338cb3f77'),('a478c745-890d-4f2c-94c0-536333d7230c','upn','openid-connect','oidc-usermodel-attribute-mapper',NULL,'e16864f1-ced5-4c30-bb89-bf358e8b1973'),('a507010c-eed7-4065-b077-bad0196805d7','auth_time','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','address','openid-connect','oidc-address-mapper',NULL,'04c239dd-9551-429c-8449-9a2c2af1fbdb'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','family name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','picture','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('b456a15c-62ee-4f42-85a2-7102f5fd3f2d','full name','openid-connect','oidc-full-name-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('b4c83337-6911-4046-a91a-eaead7e8417d','username','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('be235748-03c0-4895-8f23-9162363a4043','picture','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('bed50587-9341-4c8d-90c3-0f8fb1e60f15','sub','openid-connect','oidc-sub-mapper',NULL,'ecae0ea0-ab5e-4f45-a0d6-beaa7fdfed81'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','email','openid-connect','oidc-usermodel-attribute-mapper',NULL,'1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea'),('c2e5388e-6cd8-4684-8515-88a679e30241','Client Host','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'2c753b35-118a-48d9-ab0f-8d33a8b5b0bd'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','phone number verified','openid-connect','oidc-usermodel-attribute-mapper',NULL,'f9b9b4bf-db82-447f-b04a-8eadb2996ee6'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','email verified','openid-connect','oidc-usermodel-property-mapper',NULL,'1c0dcf1b-a6a5-4df8-ad21-fe598ef81aea'),('d28fd185-abd8-444e-903b-6e12e58e147a','nickname','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('d6625472-b867-43e9-b8bb-30c6298a724b','upn','openid-connect','oidc-usermodel-attribute-mapper',NULL,'7d2e2940-2dd4-4bca-9c12-9ea859876e55'),('d6666442-4d29-498a-820f-ab2d2388c714','family name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'ff30dceb-8390-442d-b3ba-58fdf6e9d253'),('e1509446-730f-4684-858d-d49b13297a90','organization','openid-connect','oidc-organization-membership-mapper',NULL,'78e4132d-6e9c-429c-82b1-0bb738768f35'),('e3530f88-fe00-4ef3-92fe-0cdf00333b79','organization','saml','saml-organization-membership-mapper',NULL,'45184368-98fe-4bc6-acb6-fe4a82a66cc7'),('e3aeef71-ed9d-4084-b220-269012066967','allowed web origins','openid-connect','oidc-allowed-origins-mapper',NULL,'44025836-5c4a-4003-b9da-3cc785d53ef1'),('e8b89be9-0f8f-4123-8357-b12c38762840','updated at','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','Client ID','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'2c753b35-118a-48d9-ab0f-8d33a8b5b0bd'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','groups','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'7d2e2940-2dd4-4bca-9c12-9ea859876e55'),('f90965bc-acec-4cab-be23-2225811651fb','sub','openid-connect','oidc-sub-mapper',NULL,'363951aa-fdf3-4c95-8ec2-a380dc6a56c1'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','birthdate','openid-connect','oidc-usermodel-attribute-mapper',NULL,'651c49f7-028b-456a-b4ae-9aef93eb1cc6'),('fe3be249-6667-4484-b3d1-546d2bed5a3e','audience resolve','openid-connect','oidc-audience-resolve-mapper',NULL,'0c7363ad-14dd-4251-b417-320066960b32'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','email verified','openid-connect','oidc-usermodel-property-mapper',NULL,'219699e4-526e-45e2-9b0c-d40f3b0256b3');
/*!40000 ALTER TABLE `PROTOCOL_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROTOCOL_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `PROTOCOL_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROTOCOL_MAPPER_CONFIG` (
  `PROTOCOL_MAPPER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`PROTOCOL_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_PMCONFIG` FOREIGN KEY (`PROTOCOL_MAPPER_ID`) REFERENCES `PROTOCOL_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROTOCOL_MAPPER_CONFIG`
--

LOCK TABLES `PROTOCOL_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `PROTOCOL_MAPPER_CONFIG` DISABLE KEYS */;
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0553891b-a8d3-445e-b277-06208a04e501','true','access.token.claim'),('0553891b-a8d3-445e-b277-06208a04e501','given_name','claim.name'),('0553891b-a8d3-445e-b277-06208a04e501','true','id.token.claim'),('0553891b-a8d3-445e-b277-06208a04e501','true','introspection.token.claim'),('0553891b-a8d3-445e-b277-06208a04e501','String','jsonType.label'),('0553891b-a8d3-445e-b277-06208a04e501','firstName','user.attribute'),('0553891b-a8d3-445e-b277-06208a04e501','true','userinfo.token.claim'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','true','access.token.claim'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','locale','claim.name'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','true','id.token.claim'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','true','introspection.token.claim'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','String','jsonType.label'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','locale','user.attribute'),('05784a0d-1437-4b8f-ae91-621f8c50cec9','true','userinfo.token.claim'),('05b4476d-6eb3-47a8-a6be-2368006012e1','Role','attribute.name'),('05b4476d-6eb3-47a8-a6be-2368006012e1','Basic','attribute.nameformat'),('05b4476d-6eb3-47a8-a6be-2368006012e1','false','single'),('089a95c5-1cce-449a-8593-d7d4358a1d9d','true','access.token.claim'),('089a95c5-1cce-449a-8593-d7d4358a1d9d','resource_access.${client_id}.roles','claim.name'),('089a95c5-1cce-449a-8593-d7d4358a1d9d','true','introspection.token.claim'),('089a95c5-1cce-449a-8593-d7d4358a1d9d','String','jsonType.label'),('089a95c5-1cce-449a-8593-d7d4358a1d9d','true','multivalued'),('089a95c5-1cce-449a-8593-d7d4358a1d9d','foo','user.attribute'),('0b079277-0937-4bd9-bd8c-8dbd64284495','true','access.token.claim'),('0b079277-0937-4bd9-bd8c-8dbd64284495','true','id.token.claim'),('0b079277-0937-4bd9-bd8c-8dbd64284495','true','introspection.token.claim'),('0b079277-0937-4bd9-bd8c-8dbd64284495','country','user.attribute.country'),('0b079277-0937-4bd9-bd8c-8dbd64284495','formatted','user.attribute.formatted'),('0b079277-0937-4bd9-bd8c-8dbd64284495','locality','user.attribute.locality'),('0b079277-0937-4bd9-bd8c-8dbd64284495','postal_code','user.attribute.postal_code'),('0b079277-0937-4bd9-bd8c-8dbd64284495','region','user.attribute.region'),('0b079277-0937-4bd9-bd8c-8dbd64284495','street','user.attribute.street'),('0b079277-0937-4bd9-bd8c-8dbd64284495','true','userinfo.token.claim'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','true','access.token.claim'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','locale','claim.name'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','true','id.token.claim'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','true','introspection.token.claim'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','String','jsonType.label'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','locale','user.attribute'),('0dbb0fab-470d-4af4-9e10-b92482e48f17','true','userinfo.token.claim'),('13579438-6758-467f-af89-72bc9bb7b61b','true','access.token.claim'),('13579438-6758-467f-af89-72bc9bb7b61b','clientAddress','claim.name'),('13579438-6758-467f-af89-72bc9bb7b61b','true','id.token.claim'),('13579438-6758-467f-af89-72bc9bb7b61b','true','introspection.token.claim'),('13579438-6758-467f-af89-72bc9bb7b61b','String','jsonType.label'),('13579438-6758-467f-af89-72bc9bb7b61b','clientAddress','user.session.note'),('1487ca4a-2982-4770-ad2f-b1abc143796e','true','access.token.claim'),('1487ca4a-2982-4770-ad2f-b1abc143796e','zoneinfo','claim.name'),('1487ca4a-2982-4770-ad2f-b1abc143796e','true','id.token.claim'),('1487ca4a-2982-4770-ad2f-b1abc143796e','true','introspection.token.claim'),('1487ca4a-2982-4770-ad2f-b1abc143796e','String','jsonType.label'),('1487ca4a-2982-4770-ad2f-b1abc143796e','zoneinfo','user.attribute'),('1487ca4a-2982-4770-ad2f-b1abc143796e','true','userinfo.token.claim'),('14ed2b2f-5e2a-4181-8925-39dd06af52f9','true','access.token.claim'),('14ed2b2f-5e2a-4181-8925-39dd06af52f9','true','id.token.claim'),('14ed2b2f-5e2a-4181-8925-39dd06af52f9','true','introspection.token.claim'),('14ed2b2f-5e2a-4181-8925-39dd06af52f9','true','userinfo.token.claim'),('179774f3-50c7-4576-bbd6-0b718615322b','true','access.token.claim'),('179774f3-50c7-4576-bbd6-0b718615322b','phone_number','claim.name'),('179774f3-50c7-4576-bbd6-0b718615322b','true','id.token.claim'),('179774f3-50c7-4576-bbd6-0b718615322b','true','introspection.token.claim'),('179774f3-50c7-4576-bbd6-0b718615322b','String','jsonType.label'),('179774f3-50c7-4576-bbd6-0b718615322b','phoneNumber','user.attribute'),('179774f3-50c7-4576-bbd6-0b718615322b','true','userinfo.token.claim'),('21970564-f66d-44b9-b9ef-570af96e7db4','true','access.token.claim'),('21970564-f66d-44b9-b9ef-570af96e7db4','clientAddress','claim.name'),('21970564-f66d-44b9-b9ef-570af96e7db4','true','id.token.claim'),('21970564-f66d-44b9-b9ef-570af96e7db4','true','introspection.token.claim'),('21970564-f66d-44b9-b9ef-570af96e7db4','String','jsonType.label'),('21970564-f66d-44b9-b9ef-570af96e7db4','clientAddress','user.session.note'),('21970564-f66d-44b9-b9ef-570af96e7db4','true','userinfo.token.claim'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','true','access.token.claim'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','realm_access.roles','claim.name'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','true','introspection.token.claim'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','String','jsonType.label'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','true','multivalued'),('2c1fc5fc-a7b1-41b1-9e73-8d3b1795fc5e','foo','user.attribute'),('2fd52fda-1eeb-47fb-881f-06637b060f37','true','access.token.claim'),('2fd52fda-1eeb-47fb-881f-06637b060f37','locale','claim.name'),('2fd52fda-1eeb-47fb-881f-06637b060f37','true','id.token.claim'),('2fd52fda-1eeb-47fb-881f-06637b060f37','true','introspection.token.claim'),('2fd52fda-1eeb-47fb-881f-06637b060f37','String','jsonType.label'),('2fd52fda-1eeb-47fb-881f-06637b060f37','locale','user.attribute'),('2fd52fda-1eeb-47fb-881f-06637b060f37','true','userinfo.token.claim'),('3245cb34-2dc9-4168-bcee-25dbb4896997','true','access.token.claim'),('3245cb34-2dc9-4168-bcee-25dbb4896997','phone_number','claim.name'),('3245cb34-2dc9-4168-bcee-25dbb4896997','true','id.token.claim'),('3245cb34-2dc9-4168-bcee-25dbb4896997','true','introspection.token.claim'),('3245cb34-2dc9-4168-bcee-25dbb4896997','String','jsonType.label'),('3245cb34-2dc9-4168-bcee-25dbb4896997','phoneNumber','user.attribute'),('3245cb34-2dc9-4168-bcee-25dbb4896997','true','userinfo.token.claim'),('38de27f9-d29a-48b7-a8f2-dcaa09486237','true','access.token.claim'),('38de27f9-d29a-48b7-a8f2-dcaa09486237','true','introspection.token.claim'),('4154012e-687e-4a2e-a802-bb66f5759b38','true','access.token.claim'),('4154012e-687e-4a2e-a802-bb66f5759b38','organization','claim.name'),('4154012e-687e-4a2e-a802-bb66f5759b38','true','id.token.claim'),('4154012e-687e-4a2e-a802-bb66f5759b38','true','introspection.token.claim'),('4154012e-687e-4a2e-a802-bb66f5759b38','String','jsonType.label'),('4154012e-687e-4a2e-a802-bb66f5759b38','true','multivalued'),('469806d8-aa52-490f-b646-0f2a0fa57b55','true','access.token.claim'),('469806d8-aa52-490f-b646-0f2a0fa57b55','groups','claim.name'),('469806d8-aa52-490f-b646-0f2a0fa57b55','true','id.token.claim'),('469806d8-aa52-490f-b646-0f2a0fa57b55','true','introspection.token.claim'),('469806d8-aa52-490f-b646-0f2a0fa57b55','String','jsonType.label'),('469806d8-aa52-490f-b646-0f2a0fa57b55','true','multivalued'),('469806d8-aa52-490f-b646-0f2a0fa57b55','foo','user.attribute'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','true','access.token.claim'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','preferred_username','claim.name'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','true','id.token.claim'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','true','introspection.token.claim'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','String','jsonType.label'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','username','user.attribute'),('4f8940d5-8cc5-4803-ab7b-b031e013e139','true','userinfo.token.claim'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','true','access.token.claim'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','phone_number_verified','claim.name'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','true','id.token.claim'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','true','introspection.token.claim'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','boolean','jsonType.label'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','phoneNumberVerified','user.attribute'),('51011d5f-6f70-4d24-8d14-0b52e1b97522','true','userinfo.token.claim'),('5222a785-7655-404e-b9e2-19fa79535110','true','access.token.claim'),('5222a785-7655-404e-b9e2-19fa79535110','updated_at','claim.name'),('5222a785-7655-404e-b9e2-19fa79535110','true','id.token.claim'),('5222a785-7655-404e-b9e2-19fa79535110','true','introspection.token.claim'),('5222a785-7655-404e-b9e2-19fa79535110','long','jsonType.label'),('5222a785-7655-404e-b9e2-19fa79535110','updatedAt','user.attribute'),('5222a785-7655-404e-b9e2-19fa79535110','true','userinfo.token.claim'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','true','access.token.claim'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','profile','claim.name'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','true','id.token.claim'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','true','introspection.token.claim'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','String','jsonType.label'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','profile','user.attribute'),('54c99933-ec2b-4418-b5c9-f4870f5942b6','true','userinfo.token.claim'),('57def3a9-08ca-479a-bdef-e3a6bcd60662','true','access.token.claim'),('57def3a9-08ca-479a-bdef-e3a6bcd60662','true','id.token.claim'),('57def3a9-08ca-479a-bdef-e3a6bcd60662','true','introspection.token.claim'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','true','access.token.claim'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','profile','claim.name'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','true','id.token.claim'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','true','introspection.token.claim'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','String','jsonType.label'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','profile','user.attribute'),('58d1e29d-c756-4e4d-9fc8-988cb816347b','true','userinfo.token.claim'),('6095c17e-21d8-456c-8767-ddb4a839968c','true','access.token.claim'),('6095c17e-21d8-456c-8767-ddb4a839968c','resource_access.${client_id}.roles','claim.name'),('6095c17e-21d8-456c-8767-ddb4a839968c','true','introspection.token.claim'),('6095c17e-21d8-456c-8767-ddb4a839968c','String','jsonType.label'),('6095c17e-21d8-456c-8767-ddb4a839968c','true','multivalued'),('6095c17e-21d8-456c-8767-ddb4a839968c','foo','user.attribute'),('611ebdaa-355d-4270-bbcc-0e0b4c136057','true','access.token.claim'),('611ebdaa-355d-4270-bbcc-0e0b4c136057','true','id.token.claim'),('611ebdaa-355d-4270-bbcc-0e0b4c136057','true','introspection.token.claim'),('611ebdaa-355d-4270-bbcc-0e0b4c136057','true','userinfo.token.claim'),('623ba149-c916-4830-94fd-6aa2abbe7d30','true','access.token.claim'),('623ba149-c916-4830-94fd-6aa2abbe7d30','middle_name','claim.name'),('623ba149-c916-4830-94fd-6aa2abbe7d30','true','id.token.claim'),('623ba149-c916-4830-94fd-6aa2abbe7d30','true','introspection.token.claim'),('623ba149-c916-4830-94fd-6aa2abbe7d30','String','jsonType.label'),('623ba149-c916-4830-94fd-6aa2abbe7d30','middleName','user.attribute'),('623ba149-c916-4830-94fd-6aa2abbe7d30','true','userinfo.token.claim'),('65ad2119-9a74-4d37-84aa-e7f630d61635','true','access.token.claim'),('65ad2119-9a74-4d37-84aa-e7f630d61635','website','claim.name'),('65ad2119-9a74-4d37-84aa-e7f630d61635','true','id.token.claim'),('65ad2119-9a74-4d37-84aa-e7f630d61635','true','introspection.token.claim'),('65ad2119-9a74-4d37-84aa-e7f630d61635','String','jsonType.label'),('65ad2119-9a74-4d37-84aa-e7f630d61635','website','user.attribute'),('65ad2119-9a74-4d37-84aa-e7f630d61635','true','userinfo.token.claim'),('66570280-82c5-4d31-85eb-6a4a2135eeef','true','access.token.claim'),('66570280-82c5-4d31-85eb-6a4a2135eeef','client_id','claim.name'),('66570280-82c5-4d31-85eb-6a4a2135eeef','true','id.token.claim'),('66570280-82c5-4d31-85eb-6a4a2135eeef','true','introspection.token.claim'),('66570280-82c5-4d31-85eb-6a4a2135eeef','String','jsonType.label'),('66570280-82c5-4d31-85eb-6a4a2135eeef','client_id','user.session.note'),('66570280-82c5-4d31-85eb-6a4a2135eeef','true','userinfo.token.claim'),('69656e4a-037a-4b82-a22c-e385b5419c29','true','access.token.claim'),('69656e4a-037a-4b82-a22c-e385b5419c29','auth_time','claim.name'),('69656e4a-037a-4b82-a22c-e385b5419c29','true','id.token.claim'),('69656e4a-037a-4b82-a22c-e385b5419c29','true','introspection.token.claim'),('69656e4a-037a-4b82-a22c-e385b5419c29','long','jsonType.label'),('69656e4a-037a-4b82-a22c-e385b5419c29','AUTH_TIME','user.session.note'),('69656e4a-037a-4b82-a22c-e385b5419c29','true','userinfo.token.claim'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','true','access.token.claim'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','birthdate','claim.name'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','true','id.token.claim'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','true','introspection.token.claim'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','String','jsonType.label'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','birthdate','user.attribute'),('70b86a42-5c79-4193-bded-2ec24a3c33c0','true','userinfo.token.claim'),('7722532c-9b16-450d-919c-f711a4303c32','true','access.token.claim'),('7722532c-9b16-450d-919c-f711a4303c32','clientHost','claim.name'),('7722532c-9b16-450d-919c-f711a4303c32','true','id.token.claim'),('7722532c-9b16-450d-919c-f711a4303c32','true','introspection.token.claim'),('7722532c-9b16-450d-919c-f711a4303c32','String','jsonType.label'),('7722532c-9b16-450d-919c-f711a4303c32','clientHost','user.session.note'),('7722532c-9b16-450d-919c-f711a4303c32','true','userinfo.token.claim'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','true','access.token.claim'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','middle_name','claim.name'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','true','id.token.claim'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','true','introspection.token.claim'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','String','jsonType.label'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','middleName','user.attribute'),('802379f4-9c5f-4e12-9e49-527a4ff7b6dc','true','userinfo.token.claim'),('82ad2b96-91be-4267-be85-43ab37749f86','true','access.token.claim'),('82ad2b96-91be-4267-be85-43ab37749f86','email','claim.name'),('82ad2b96-91be-4267-be85-43ab37749f86','true','id.token.claim'),('82ad2b96-91be-4267-be85-43ab37749f86','true','introspection.token.claim'),('82ad2b96-91be-4267-be85-43ab37749f86','String','jsonType.label'),('82ad2b96-91be-4267-be85-43ab37749f86','email','user.attribute'),('82ad2b96-91be-4267-be85-43ab37749f86','true','userinfo.token.claim'),('86718f60-197d-4193-a5d7-7b6490bb3107','true','access.token.claim'),('86718f60-197d-4193-a5d7-7b6490bb3107','gender','claim.name'),('86718f60-197d-4193-a5d7-7b6490bb3107','true','id.token.claim'),('86718f60-197d-4193-a5d7-7b6490bb3107','true','introspection.token.claim'),('86718f60-197d-4193-a5d7-7b6490bb3107','String','jsonType.label'),('86718f60-197d-4193-a5d7-7b6490bb3107','gender','user.attribute'),('86718f60-197d-4193-a5d7-7b6490bb3107','true','userinfo.token.claim'),('868e5f72-710b-4985-97dc-ffaa6aba56db','true','access.token.claim'),('868e5f72-710b-4985-97dc-ffaa6aba56db','locale','claim.name'),('868e5f72-710b-4985-97dc-ffaa6aba56db','true','id.token.claim'),('868e5f72-710b-4985-97dc-ffaa6aba56db','true','introspection.token.claim'),('868e5f72-710b-4985-97dc-ffaa6aba56db','String','jsonType.label'),('868e5f72-710b-4985-97dc-ffaa6aba56db','locale','user.attribute'),('868e5f72-710b-4985-97dc-ffaa6aba56db','true','userinfo.token.claim'),('923bcdb9-2879-467e-b66c-3d85147a801e','true','access.token.claim'),('923bcdb9-2879-467e-b66c-3d85147a801e','nickname','claim.name'),('923bcdb9-2879-467e-b66c-3d85147a801e','true','id.token.claim'),('923bcdb9-2879-467e-b66c-3d85147a801e','true','introspection.token.claim'),('923bcdb9-2879-467e-b66c-3d85147a801e','String','jsonType.label'),('923bcdb9-2879-467e-b66c-3d85147a801e','nickname','user.attribute'),('923bcdb9-2879-467e-b66c-3d85147a801e','true','userinfo.token.claim'),('990cbcbe-ea36-4e2e-9108-4434b06d287f','true','access.token.claim'),('990cbcbe-ea36-4e2e-9108-4434b06d287f','true','introspection.token.claim'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','true','access.token.claim'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','gender','claim.name'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','true','id.token.claim'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','true','introspection.token.claim'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','String','jsonType.label'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','gender','user.attribute'),('99ecf456-54a1-4f6c-b6c8-a97eb3af6137','true','userinfo.token.claim'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','true','access.token.claim'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','website','claim.name'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','true','id.token.claim'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','true','introspection.token.claim'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','String','jsonType.label'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','website','user.attribute'),('9b52d6bd-b4a7-4bc8-8361-2e05962df1c4','true','userinfo.token.claim'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','true','access.token.claim'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','given_name','claim.name'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','true','id.token.claim'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','true','introspection.token.claim'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','String','jsonType.label'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','firstName','user.attribute'),('9df1b36b-08a1-4d7d-adbf-d93dc4f5d8f2','true','userinfo.token.claim'),('a03c8a64-61cb-469d-9697-4c5168899c3b','true','access.token.claim'),('a03c8a64-61cb-469d-9697-4c5168899c3b','realm_access.roles','claim.name'),('a03c8a64-61cb-469d-9697-4c5168899c3b','true','introspection.token.claim'),('a03c8a64-61cb-469d-9697-4c5168899c3b','String','jsonType.label'),('a03c8a64-61cb-469d-9697-4c5168899c3b','true','multivalued'),('a03c8a64-61cb-469d-9697-4c5168899c3b','foo','user.attribute'),('a0c6a654-2c99-4e19-ab67-331e28473527','true','access.token.claim'),('a0c6a654-2c99-4e19-ab67-331e28473527','zoneinfo','claim.name'),('a0c6a654-2c99-4e19-ab67-331e28473527','true','id.token.claim'),('a0c6a654-2c99-4e19-ab67-331e28473527','true','introspection.token.claim'),('a0c6a654-2c99-4e19-ab67-331e28473527','String','jsonType.label'),('a0c6a654-2c99-4e19-ab67-331e28473527','zoneinfo','user.attribute'),('a0c6a654-2c99-4e19-ab67-331e28473527','true','userinfo.token.claim'),('a0e01a37-e9c8-4b60-9ec0-7cf5350ac300','Role','attribute.name'),('a0e01a37-e9c8-4b60-9ec0-7cf5350ac300','Basic','attribute.nameformat'),('a0e01a37-e9c8-4b60-9ec0-7cf5350ac300','false','single'),('a478c745-890d-4f2c-94c0-536333d7230c','true','access.token.claim'),('a478c745-890d-4f2c-94c0-536333d7230c','upn','claim.name'),('a478c745-890d-4f2c-94c0-536333d7230c','true','id.token.claim'),('a478c745-890d-4f2c-94c0-536333d7230c','true','introspection.token.claim'),('a478c745-890d-4f2c-94c0-536333d7230c','String','jsonType.label'),('a478c745-890d-4f2c-94c0-536333d7230c','username','user.attribute'),('a478c745-890d-4f2c-94c0-536333d7230c','true','userinfo.token.claim'),('a507010c-eed7-4065-b077-bad0196805d7','true','access.token.claim'),('a507010c-eed7-4065-b077-bad0196805d7','auth_time','claim.name'),('a507010c-eed7-4065-b077-bad0196805d7','true','id.token.claim'),('a507010c-eed7-4065-b077-bad0196805d7','true','introspection.token.claim'),('a507010c-eed7-4065-b077-bad0196805d7','long','jsonType.label'),('a507010c-eed7-4065-b077-bad0196805d7','AUTH_TIME','user.session.note'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','true','access.token.claim'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','true','id.token.claim'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','true','introspection.token.claim'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','country','user.attribute.country'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','formatted','user.attribute.formatted'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','locality','user.attribute.locality'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','postal_code','user.attribute.postal_code'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','region','user.attribute.region'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','street','user.attribute.street'),('a531699f-f38f-4607-9ea5-2009eb4e21b2','true','userinfo.token.claim'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','true','access.token.claim'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','family_name','claim.name'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','true','id.token.claim'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','true','introspection.token.claim'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','String','jsonType.label'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','lastName','user.attribute'),('a8d6705f-9567-425c-b61f-d5343e6e96e1','true','userinfo.token.claim'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','true','access.token.claim'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','picture','claim.name'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','true','id.token.claim'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','true','introspection.token.claim'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','String','jsonType.label'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','picture','user.attribute'),('b395481a-b52e-4620-a8f2-1e897e2b2d4c','true','userinfo.token.claim'),('b456a15c-62ee-4f42-85a2-7102f5fd3f2d','true','access.token.claim'),('b456a15c-62ee-4f42-85a2-7102f5fd3f2d','true','id.token.claim'),('b456a15c-62ee-4f42-85a2-7102f5fd3f2d','true','introspection.token.claim'),('b456a15c-62ee-4f42-85a2-7102f5fd3f2d','true','userinfo.token.claim'),('b4c83337-6911-4046-a91a-eaead7e8417d','true','access.token.claim'),('b4c83337-6911-4046-a91a-eaead7e8417d','preferred_username','claim.name'),('b4c83337-6911-4046-a91a-eaead7e8417d','true','id.token.claim'),('b4c83337-6911-4046-a91a-eaead7e8417d','true','introspection.token.claim'),('b4c83337-6911-4046-a91a-eaead7e8417d','String','jsonType.label'),('b4c83337-6911-4046-a91a-eaead7e8417d','username','user.attribute'),('b4c83337-6911-4046-a91a-eaead7e8417d','true','userinfo.token.claim'),('be235748-03c0-4895-8f23-9162363a4043','true','access.token.claim'),('be235748-03c0-4895-8f23-9162363a4043','picture','claim.name'),('be235748-03c0-4895-8f23-9162363a4043','true','id.token.claim'),('be235748-03c0-4895-8f23-9162363a4043','true','introspection.token.claim'),('be235748-03c0-4895-8f23-9162363a4043','String','jsonType.label'),('be235748-03c0-4895-8f23-9162363a4043','picture','user.attribute'),('be235748-03c0-4895-8f23-9162363a4043','true','userinfo.token.claim'),('bed50587-9341-4c8d-90c3-0f8fb1e60f15','true','access.token.claim'),('bed50587-9341-4c8d-90c3-0f8fb1e60f15','true','introspection.token.claim'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','true','access.token.claim'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','email','claim.name'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','true','id.token.claim'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','true','introspection.token.claim'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','String','jsonType.label'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','email','user.attribute'),('c0255cf4-1909-40c1-bd84-6cb2cb576a59','true','userinfo.token.claim'),('c2e5388e-6cd8-4684-8515-88a679e30241','true','access.token.claim'),('c2e5388e-6cd8-4684-8515-88a679e30241','clientHost','claim.name'),('c2e5388e-6cd8-4684-8515-88a679e30241','true','id.token.claim'),('c2e5388e-6cd8-4684-8515-88a679e30241','true','introspection.token.claim'),('c2e5388e-6cd8-4684-8515-88a679e30241','String','jsonType.label'),('c2e5388e-6cd8-4684-8515-88a679e30241','clientHost','user.session.note'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','true','access.token.claim'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','phone_number_verified','claim.name'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','true','id.token.claim'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','true','introspection.token.claim'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','boolean','jsonType.label'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','phoneNumberVerified','user.attribute'),('c9cf416f-6979-4d62-9d2a-6c2642ba446f','true','userinfo.token.claim'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','true','access.token.claim'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','email_verified','claim.name'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','true','id.token.claim'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','true','introspection.token.claim'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','boolean','jsonType.label'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','emailVerified','user.attribute'),('cd7a1141-daf7-4b27-bb00-d1e4dbdb00d2','true','userinfo.token.claim'),('d28fd185-abd8-444e-903b-6e12e58e147a','true','access.token.claim'),('d28fd185-abd8-444e-903b-6e12e58e147a','nickname','claim.name'),('d28fd185-abd8-444e-903b-6e12e58e147a','true','id.token.claim'),('d28fd185-abd8-444e-903b-6e12e58e147a','true','introspection.token.claim'),('d28fd185-abd8-444e-903b-6e12e58e147a','String','jsonType.label'),('d28fd185-abd8-444e-903b-6e12e58e147a','nickname','user.attribute'),('d28fd185-abd8-444e-903b-6e12e58e147a','true','userinfo.token.claim'),('d6625472-b867-43e9-b8bb-30c6298a724b','true','access.token.claim'),('d6625472-b867-43e9-b8bb-30c6298a724b','upn','claim.name'),('d6625472-b867-43e9-b8bb-30c6298a724b','true','id.token.claim'),('d6625472-b867-43e9-b8bb-30c6298a724b','true','introspection.token.claim'),('d6625472-b867-43e9-b8bb-30c6298a724b','String','jsonType.label'),('d6625472-b867-43e9-b8bb-30c6298a724b','username','user.attribute'),('d6625472-b867-43e9-b8bb-30c6298a724b','true','userinfo.token.claim'),('d6666442-4d29-498a-820f-ab2d2388c714','true','access.token.claim'),('d6666442-4d29-498a-820f-ab2d2388c714','family_name','claim.name'),('d6666442-4d29-498a-820f-ab2d2388c714','true','id.token.claim'),('d6666442-4d29-498a-820f-ab2d2388c714','true','introspection.token.claim'),('d6666442-4d29-498a-820f-ab2d2388c714','String','jsonType.label'),('d6666442-4d29-498a-820f-ab2d2388c714','lastName','user.attribute'),('d6666442-4d29-498a-820f-ab2d2388c714','true','userinfo.token.claim'),('e1509446-730f-4684-858d-d49b13297a90','true','access.token.claim'),('e1509446-730f-4684-858d-d49b13297a90','organization','claim.name'),('e1509446-730f-4684-858d-d49b13297a90','true','id.token.claim'),('e1509446-730f-4684-858d-d49b13297a90','true','introspection.token.claim'),('e1509446-730f-4684-858d-d49b13297a90','String','jsonType.label'),('e1509446-730f-4684-858d-d49b13297a90','true','multivalued'),('e1509446-730f-4684-858d-d49b13297a90','true','userinfo.token.claim'),('e3aeef71-ed9d-4084-b220-269012066967','true','access.token.claim'),('e3aeef71-ed9d-4084-b220-269012066967','true','introspection.token.claim'),('e8b89be9-0f8f-4123-8357-b12c38762840','true','access.token.claim'),('e8b89be9-0f8f-4123-8357-b12c38762840','updated_at','claim.name'),('e8b89be9-0f8f-4123-8357-b12c38762840','true','id.token.claim'),('e8b89be9-0f8f-4123-8357-b12c38762840','true','introspection.token.claim'),('e8b89be9-0f8f-4123-8357-b12c38762840','long','jsonType.label'),('e8b89be9-0f8f-4123-8357-b12c38762840','updatedAt','user.attribute'),('e8b89be9-0f8f-4123-8357-b12c38762840','true','userinfo.token.claim'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','true','access.token.claim'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','client_id','claim.name'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','true','id.token.claim'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','true','introspection.token.claim'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','String','jsonType.label'),('eef6bd20-75fc-4007-950b-e1b51417dbc2','client_id','user.session.note'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','true','access.token.claim'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','groups','claim.name'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','true','id.token.claim'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','true','introspection.token.claim'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','String','jsonType.label'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','true','multivalued'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','foo','user.attribute'),('ef33d63a-3bb4-49a0-91d9-e33d3f6dc50d','true','userinfo.token.claim'),('f90965bc-acec-4cab-be23-2225811651fb','true','access.token.claim'),('f90965bc-acec-4cab-be23-2225811651fb','true','introspection.token.claim'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','true','access.token.claim'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','birthdate','claim.name'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','true','id.token.claim'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','true','introspection.token.claim'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','String','jsonType.label'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','birthdate','user.attribute'),('fa2b4160-a5f1-47a1-849b-d459b96f1675','true','userinfo.token.claim'),('fe3be249-6667-4484-b3d1-546d2bed5a3e','true','access.token.claim'),('fe3be249-6667-4484-b3d1-546d2bed5a3e','true','introspection.token.claim'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','true','access.token.claim'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','email_verified','claim.name'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','true','id.token.claim'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','true','introspection.token.claim'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','boolean','jsonType.label'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','emailVerified','user.attribute'),('fed8fef7-2f0b-436c-8202-6a89ec5b762f','true','userinfo.token.claim');
/*!40000 ALTER TABLE `PROTOCOL_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM`
--

DROP TABLE IF EXISTS `REALM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ACCESS_CODE_LIFESPAN` int DEFAULT NULL,
  `USER_ACTION_LIFESPAN` int DEFAULT NULL,
  `ACCESS_TOKEN_LIFESPAN` int DEFAULT NULL,
  `ACCOUNT_THEME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ADMIN_THEME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_THEME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ENABLED` tinyint NOT NULL DEFAULT '0',
  `EVENTS_ENABLED` tinyint NOT NULL DEFAULT '0',
  `EVENTS_EXPIRATION` bigint DEFAULT NULL,
  `LOGIN_THEME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NOT_BEFORE` int DEFAULT NULL,
  `PASSWORD_POLICY` text COLLATE utf8mb4_unicode_ci,
  `REGISTRATION_ALLOWED` tinyint NOT NULL DEFAULT '0',
  `REMEMBER_ME` tinyint NOT NULL DEFAULT '0',
  `RESET_PASSWORD_ALLOWED` tinyint NOT NULL DEFAULT '0',
  `SOCIAL` tinyint NOT NULL DEFAULT '0',
  `SSL_REQUIRED` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SSO_IDLE_TIMEOUT` int DEFAULT NULL,
  `SSO_MAX_LIFESPAN` int DEFAULT NULL,
  `UPDATE_PROFILE_ON_SOC_LOGIN` tinyint NOT NULL DEFAULT '0',
  `VERIFY_EMAIL` tinyint NOT NULL DEFAULT '0',
  `MASTER_ADMIN_CLIENT` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LOGIN_LIFESPAN` int DEFAULT NULL,
  `INTERNATIONALIZATION_ENABLED` tinyint NOT NULL DEFAULT '0',
  `DEFAULT_LOCALE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REG_EMAIL_AS_USERNAME` tinyint NOT NULL DEFAULT '0',
  `ADMIN_EVENTS_ENABLED` tinyint NOT NULL DEFAULT '0',
  `ADMIN_EVENTS_DETAILS_ENABLED` tinyint NOT NULL DEFAULT '0',
  `EDIT_USERNAME_ALLOWED` tinyint NOT NULL DEFAULT '0',
  `OTP_POLICY_COUNTER` int DEFAULT '0',
  `OTP_POLICY_WINDOW` int DEFAULT '1',
  `OTP_POLICY_PERIOD` int DEFAULT '30',
  `OTP_POLICY_DIGITS` int DEFAULT '6',
  `OTP_POLICY_ALG` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT 'HmacSHA1',
  `OTP_POLICY_TYPE` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT 'totp',
  `BROWSER_FLOW` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REGISTRATION_FLOW` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DIRECT_GRANT_FLOW` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESET_CREDENTIALS_FLOW` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_AUTH_FLOW` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OFFLINE_SESSION_IDLE_TIMEOUT` int DEFAULT '0',
  `REVOKE_REFRESH_TOKEN` tinyint NOT NULL DEFAULT '0',
  `ACCESS_TOKEN_LIFE_IMPLICIT` int DEFAULT '0',
  `LOGIN_WITH_EMAIL_ALLOWED` tinyint NOT NULL DEFAULT '1',
  `DUPLICATE_EMAILS_ALLOWED` tinyint NOT NULL DEFAULT '0',
  `DOCKER_AUTH_FLOW` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REFRESH_TOKEN_MAX_REUSE` int DEFAULT '0',
  `ALLOW_USER_MANAGED_ACCESS` tinyint NOT NULL DEFAULT '0',
  `SSO_MAX_LIFESPAN_REMEMBER_ME` int NOT NULL,
  `SSO_IDLE_TIMEOUT_REMEMBER_ME` int NOT NULL,
  `DEFAULT_ROLE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_ORVSDMLA56612EAEFIQ6WL5OI` (`NAME`),
  KEY `IDX_REALM_MASTER_ADM_CLI` (`MASTER_ADMIN_CLIENT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM`
--

LOCK TABLES `REALM` WRITE;
/*!40000 ALTER TABLE `REALM` DISABLE KEYS */;
INSERT INTO `REALM` VALUES ('84ab64b6-3491-4ad3-8d0b-34567e32e313',60,300,60,NULL,NULL,NULL,1,0,0,NULL,'master',0,NULL,0,0,0,0,'EXTERNAL',1800,36000,0,0,'fead954d-b832-4e09-a767-93f6ef398331',1800,0,NULL,0,0,0,0,0,1,30,6,'HmacSHA1','totp','2171dcb5-2f36-468d-9620-002ac6875e4a','30023d6e-1e73-472d-a64f-ebac7b7225d4','6a37e0ec-0488-4e26-93eb-d404bc21b066','ad814251-0805-46fa-a0b9-4b0f36475fc7','f84dfc68-fb64-42d2-b465-813fb35926e5',2592000,0,900,1,0,'37f96afe-b813-492c-85f9-6ac327b3cc7d',0,0,0,0,'c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','Keycloak'),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',60,300,300,NULL,NULL,NULL,1,0,0,NULL,'video-locadora',0,NULL,0,0,0,0,'NONE',1800,36000,0,0,'39076246-ac23-4c54-b55d-fefb0ab17939',1800,0,NULL,0,0,0,0,0,1,30,6,'HmacSHA1','totp','18f7dbe3-b9e1-4bfe-b6e4-e0633333649b','9277b8f3-ac0c-44fc-883d-ae764c53ca3e','ace3e7b2-4f53-411f-8937-15206446ee27','a4acbcfb-294f-462e-a9af-7066e899f78f','b329b136-1daa-4f76-97a6-9979c730a9ff',2592000,0,900,1,0,'c27ea42c-a5ae-4cc9-a80b-130c19243ed0',0,0,0,0,'690188dd-5aa0-4586-99ff-a0e575c77300','video-locadora');
/*!40000 ALTER TABLE `REALM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_ATTRIBUTE`
--

DROP TABLE IF EXISTS `REALM_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_ATTRIBUTE` (
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`NAME`,`REALM_ID`),
  KEY `IDX_REALM_ATTR_REALM` (`REALM_ID`),
  CONSTRAINT `FK_8SHXD6L3E9ATQUKACXGPFFPTW` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_ATTRIBUTE`
--

LOCK TABLES `REALM_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `REALM_ATTRIBUTE` DISABLE KEYS */;
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.contentSecurityPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';'),('_browser_header.contentSecurityPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';'),('_browser_header.contentSecurityPolicyReportOnly','84ab64b6-3491-4ad3-8d0b-34567e32e313',''),('_browser_header.contentSecurityPolicyReportOnly','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',''),('_browser_header.referrerPolicy','84ab64b6-3491-4ad3-8d0b-34567e32e313','no-referrer'),('_browser_header.referrerPolicy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','no-referrer'),('_browser_header.strictTransportSecurity','84ab64b6-3491-4ad3-8d0b-34567e32e313','max-age=31536000; includeSubDomains'),('_browser_header.strictTransportSecurity','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','max-age=31536000; includeSubDomains'),('_browser_header.xContentTypeOptions','84ab64b6-3491-4ad3-8d0b-34567e32e313','nosniff'),('_browser_header.xContentTypeOptions','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','nosniff'),('_browser_header.xFrameOptions','84ab64b6-3491-4ad3-8d0b-34567e32e313','SAMEORIGIN'),('_browser_header.xFrameOptions','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','SAMEORIGIN'),('_browser_header.xRobotsTag','84ab64b6-3491-4ad3-8d0b-34567e32e313','none'),('_browser_header.xRobotsTag','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','none'),('acr.loa.map','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','{}'),('acr.uri.map','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','{}'),('actionTokenGeneratedByAdminLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','43200'),('actionTokenGeneratedByUserLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','300'),('adminPermissionsEnabled','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('bruteForceProtected','84ab64b6-3491-4ad3-8d0b-34567e32e313','false'),('bruteForceProtected','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('bruteForceStrategy','84ab64b6-3491-4ad3-8d0b-34567e32e313','MULTIPLE'),('bruteForceStrategy','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','MULTIPLE'),('cibaAuthRequestedUserHint','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','login_hint'),('cibaBackchannelTokenDeliveryMode','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','poll'),('cibaExpiresIn','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','120'),('cibaInterval','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5'),('client-policies.policies','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','{\"policies\":[]}'),('client-policies.profiles','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','{\"profiles\":[]}'),('clientOfflineSessionIdleTimeout','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('clientOfflineSessionMaxLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('clientSessionIdleTimeout','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('clientSessionMaxLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('defaultSignatureAlgorithm','84ab64b6-3491-4ad3-8d0b-34567e32e313','RS256'),('defaultSignatureAlgorithm','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','RS256'),('displayNameHtml','84ab64b6-3491-4ad3-8d0b-34567e32e313','<div class=\"kc-logo-text\"><span>Keycloak</span></div>'),('displayNameHtml','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','video-locadora'),('failureFactor','84ab64b6-3491-4ad3-8d0b-34567e32e313','30'),('failureFactor','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','30'),('firstBrokerLoginFlowId','84ab64b6-3491-4ad3-8d0b-34567e32e313','b4d48dee-1ddd-40bd-8c23-ee5a21e0d768'),('firstBrokerLoginFlowId','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','fe9a8920-3135-4faf-bf53-430f105ca09b'),('frontendUrl','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','http://localhost:8081'),('maxDeltaTimeSeconds','84ab64b6-3491-4ad3-8d0b-34567e32e313','43200'),('maxDeltaTimeSeconds','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','43200'),('maxFailureWaitSeconds','84ab64b6-3491-4ad3-8d0b-34567e32e313','900'),('maxFailureWaitSeconds','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','900'),('maxSecondaryAuthFailures','84ab64b6-3491-4ad3-8d0b-34567e32e313','0'),('maxSecondaryAuthFailures','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('maxTemporaryLockouts','84ab64b6-3491-4ad3-8d0b-34567e32e313','0'),('maxTemporaryLockouts','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('minimumQuickLoginWaitSeconds','84ab64b6-3491-4ad3-8d0b-34567e32e313','60'),('minimumQuickLoginWaitSeconds','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','60'),('oauth2DeviceCodeLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','600'),('oauth2DevicePollingInterval','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5'),('offlineSessionMaxLifespan','84ab64b6-3491-4ad3-8d0b-34567e32e313','5184000'),('offlineSessionMaxLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','5184000'),('offlineSessionMaxLifespanEnabled','84ab64b6-3491-4ad3-8d0b-34567e32e313','false'),('offlineSessionMaxLifespanEnabled','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('organizationsEnabled','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('parRequestUriLifespan','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','60'),('permanentLockout','84ab64b6-3491-4ad3-8d0b-34567e32e313','false'),('permanentLockout','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('quickLoginCheckMilliSeconds','84ab64b6-3491-4ad3-8d0b-34567e32e313','1000'),('quickLoginCheckMilliSeconds','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','1000'),('realmReusableOtpCode','84ab64b6-3491-4ad3-8d0b-34567e32e313','false'),('realmReusableOtpCode','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('saml.signature.algorithm','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',''),('scimApiEnabled','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('verifiableCredentialsEnabled','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('waitIncrementSeconds','84ab64b6-3491-4ad3-8d0b-34567e32e313','60'),('waitIncrementSeconds','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','60'),('webAuthnPolicyAttestationConveyancePreference','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyAttestationConveyancePreferencePasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyAuthenticatorAttachment','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyAuthenticatorAttachmentPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyAvoidSameAuthenticatorRegister','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','false'),('webAuthnPolicyCreateTimeout','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('webAuthnPolicyCreateTimeoutPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','0'),('webAuthnPolicyRequireResidentKey','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyRequireResidentKeyPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyResidentKey','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyResidentKeyPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','required'),('webAuthnPolicyRpEntityName','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','keycloak'),('webAuthnPolicyRpEntityNamePasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','keycloak'),('webAuthnPolicyRpId','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',''),('webAuthnPolicyRpIdPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',''),('webAuthnPolicySignatureAlgorithms','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ES256,RS256'),('webAuthnPolicySignatureAlgorithmsPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','ES256,RS256'),('webAuthnPolicyUserVerificationRequirement','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','not specified'),('webAuthnPolicyUserVerificationRequirementPasswordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','required');
/*!40000 ALTER TABLE `REALM_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_DEFAULT_GROUPS`
--

DROP TABLE IF EXISTS `REALM_DEFAULT_GROUPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_DEFAULT_GROUPS` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `GROUP_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`GROUP_ID`),
  UNIQUE KEY `CON_GROUP_ID_DEF_GROUPS` (`GROUP_ID`),
  KEY `IDX_REALM_DEF_GRP_REALM` (`REALM_ID`),
  CONSTRAINT `FK_DEF_GROUPS_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_DEFAULT_GROUPS`
--

LOCK TABLES `REALM_DEFAULT_GROUPS` WRITE;
/*!40000 ALTER TABLE `REALM_DEFAULT_GROUPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_DEFAULT_GROUPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_ENABLED_EVENT_TYPES`
--

DROP TABLE IF EXISTS `REALM_ENABLED_EVENT_TYPES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_ENABLED_EVENT_TYPES` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`VALUE`),
  KEY `IDX_REALM_EVT_TYPES_REALM` (`REALM_ID`),
  CONSTRAINT `FK_H846O4H0W8EPX5NWEDRF5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_ENABLED_EVENT_TYPES`
--

LOCK TABLES `REALM_ENABLED_EVENT_TYPES` WRITE;
/*!40000 ALTER TABLE `REALM_ENABLED_EVENT_TYPES` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_ENABLED_EVENT_TYPES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_EVENTS_LISTENERS`
--

DROP TABLE IF EXISTS `REALM_EVENTS_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_EVENTS_LISTENERS` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`VALUE`),
  KEY `IDX_REALM_EVT_LIST_REALM` (`REALM_ID`),
  CONSTRAINT `FK_H846O4H0W8EPX5NXEV9F5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_EVENTS_LISTENERS`
--

LOCK TABLES `REALM_EVENTS_LISTENERS` WRITE;
/*!40000 ALTER TABLE `REALM_EVENTS_LISTENERS` DISABLE KEYS */;
INSERT INTO `REALM_EVENTS_LISTENERS` VALUES ('84ab64b6-3491-4ad3-8d0b-34567e32e313','jboss-logging'),('da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','jboss-logging');
/*!40000 ALTER TABLE `REALM_EVENTS_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_LOCALIZATIONS`
--

DROP TABLE IF EXISTS `REALM_LOCALIZATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_LOCALIZATIONS` (
  `REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `LOCALE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TEXTS` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`LOCALE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_LOCALIZATIONS`
--

LOCK TABLES `REALM_LOCALIZATIONS` WRITE;
/*!40000 ALTER TABLE `REALM_LOCALIZATIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_LOCALIZATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_REQUIRED_CREDENTIAL`
--

DROP TABLE IF EXISTS `REALM_REQUIRED_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_REQUIRED_CREDENTIAL` (
  `TYPE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FORM_LABEL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INPUT` tinyint NOT NULL DEFAULT '0',
  `SECRET` tinyint NOT NULL DEFAULT '0',
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`TYPE`),
  CONSTRAINT `FK_5HG65LYBEVAVKQFKI3KPONH9V` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_REQUIRED_CREDENTIAL`
--

LOCK TABLES `REALM_REQUIRED_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `REALM_REQUIRED_CREDENTIAL` DISABLE KEYS */;
INSERT INTO `REALM_REQUIRED_CREDENTIAL` VALUES ('password','password',1,1,'84ab64b6-3491-4ad3-8d0b-34567e32e313'),('password','password',1,1,'da5f37ca-01bb-44dc-95a8-b60f0c16f9bd');
/*!40000 ALTER TABLE `REALM_REQUIRED_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_SMTP_CONFIG`
--

DROP TABLE IF EXISTS `REALM_SMTP_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_SMTP_CONFIG` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`NAME`),
  CONSTRAINT `FK_70EJ8XDXGXD0B9HH6180IRR0O` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_SMTP_CONFIG`
--

LOCK TABLES `REALM_SMTP_CONFIG` WRITE;
/*!40000 ALTER TABLE `REALM_SMTP_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_SMTP_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_SUPPORTED_LOCALES`
--

DROP TABLE IF EXISTS `REALM_SUPPORTED_LOCALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_SUPPORTED_LOCALES` (
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`VALUE`),
  KEY `IDX_REALM_SUPP_LOCAL_REALM` (`REALM_ID`),
  CONSTRAINT `FK_SUPPORTED_LOCALES_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_SUPPORTED_LOCALES`
--

LOCK TABLES `REALM_SUPPORTED_LOCALES` WRITE;
/*!40000 ALTER TABLE `REALM_SUPPORTED_LOCALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_SUPPORTED_LOCALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REDIRECT_URIS`
--

DROP TABLE IF EXISTS `REDIRECT_URIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REDIRECT_URIS` (
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`VALUE`),
  KEY `IDX_REDIR_URI_CLIENT` (`CLIENT_ID`),
  CONSTRAINT `FK_1BURS8PB4OUJ97H5WUPPAHV9F` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REDIRECT_URIS`
--

LOCK TABLES `REDIRECT_URIS` WRITE;
/*!40000 ALTER TABLE `REDIRECT_URIS` DISABLE KEYS */;
INSERT INTO `REDIRECT_URIS` VALUES ('1f0e8266-2a00-4c51-abc1-7a0b09582410','http://localhost:8080/videolocadora/swagger-ui/oauth2-redirect.html'),('2524ca06-c64e-4850-b4e5-af745f459add','/admin/video-locadora/console/*'),('5ba1d38b-7896-475c-a275-f8b0be01b81d','/realms/master/account/*'),('5fc24b16-6cf5-400c-aecb-c7f50ddd7003','/realms/master/account/*'),('629abc42-f3c2-47d5-8e7b-e6a61818e495','/realms/video-locadora/account/*'),('62c26143-ea24-4ed0-aac2-7b01627a62c7','http://localhost:8083/login/oauth2/code/keycloak'),('c1e0cfff-9220-423f-9320-c191c13802de','/admin/master/console/*'),('f303bf4d-7b07-4a58-85b6-455d24269265','/realms/video-locadora/account/*');
/*!40000 ALTER TABLE `REDIRECT_URIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUIRED_ACTION_CONFIG`
--

DROP TABLE IF EXISTS `REQUIRED_ACTION_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REQUIRED_ACTION_CONFIG` (
  `REQUIRED_ACTION_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REQUIRED_ACTION_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUIRED_ACTION_CONFIG`
--

LOCK TABLES `REQUIRED_ACTION_CONFIG` WRITE;
/*!40000 ALTER TABLE `REQUIRED_ACTION_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `REQUIRED_ACTION_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUIRED_ACTION_PROVIDER`
--

DROP TABLE IF EXISTS `REQUIRED_ACTION_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REQUIRED_ACTION_PROVIDER` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ENABLED` tinyint NOT NULL DEFAULT '0',
  `DEFAULT_ACTION` tinyint NOT NULL DEFAULT '0',
  `PROVIDER_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_REQ_ACT_PROV_REALM` (`REALM_ID`),
  CONSTRAINT `FK_REQ_ACT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUIRED_ACTION_PROVIDER`
--

LOCK TABLES `REQUIRED_ACTION_PROVIDER` WRITE;
/*!40000 ALTER TABLE `REQUIRED_ACTION_PROVIDER` DISABLE KEYS */;
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('04dbd313-3a78-4fb9-b09c-00f19d8fbd0c','webauthn-register-passwordless','Webauthn Register Passwordless','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'webauthn-register-passwordless',90),('12f95aae-0fd0-45b8-9dd7-7808d3c18f90','delete_credential','Delete Credential','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'delete_credential',110),('14738f04-c1ef-40e2-b92b-39a34b1c24f4','CONFIGURE_RECOVERY_AUTHN_CODES','Recovery Authentication Codes','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'CONFIGURE_RECOVERY_AUTHN_CODES',130),('17b9a16d-cdff-4fee-9041-4002bc6dc0bd','TERMS_AND_CONDITIONS','Terms and Conditions','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,0,'TERMS_AND_CONDITIONS',20),('1e69947a-9691-464d-88cf-e341505309df','VERIFY_EMAIL','Verify Email','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'VERIFY_EMAIL',50),('234ce01f-7292-4a0b-b7a3-50a5ef92c494','update_user_locale','Update User Locale','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'update_user_locale',1000),('2b0fb782-9d75-45e5-b5f2-d607eb7eae28','UPDATE_EMAIL','Update Email','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,0,'UPDATE_EMAIL',70),('3dfafacc-acd1-453e-9dba-4ca5822538a9','UPDATE_PASSWORD','Update Password','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'UPDATE_PASSWORD',57),('55d294a1-146d-4451-a722-47889ebedc67','delete_account','Delete Account','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,0,'delete_account',60),('673e16e7-e487-4c6d-bbb4-c4b4b9065452','UPDATE_PASSWORD','Update Password','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'UPDATE_PASSWORD',57),('6821df6d-e7ff-48e7-83fb-eece57d8ea82','idp_link','Linking Identity Provider','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'idp_link',120),('6ddc8a66-b29b-486a-8bea-9bc2f16c476e','webauthn-register-passwordless','Webauthn Register Passwordless','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'webauthn-register-passwordless',90),('767cac2b-092d-406b-a282-43ce3d4a9f91','idp_link','Linking Identity Provider','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'idp_link',120),('7d6d0cb9-9824-4790-8215-0b5220a31883','UPDATE_EMAIL','Update Email','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,0,'UPDATE_EMAIL',70),('8194e5d2-0050-4884-92c3-1a4befff4a00','VERIFY_EMAIL','Verify Email','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'VERIFY_EMAIL',50),('960f1cfc-c4cb-4dbe-9896-fb03064ae7bf','delete_credential','Delete Credential','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'delete_credential',110),('991f5238-6c08-415c-aeb9-c7cc986439a0','CONFIGURE_TOTP','Configure OTP','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'CONFIGURE_TOTP',54),('a7f6bbfc-9e71-4a00-8f14-1f474d830a33','TERMS_AND_CONDITIONS','Terms and Conditions','84ab64b6-3491-4ad3-8d0b-34567e32e313',0,0,'TERMS_AND_CONDITIONS',20),('b7639429-1533-4cdb-ad37-046e06885faf','VERIFY_PROFILE','Verify Profile','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'VERIFY_PROFILE',100),('bb3f68c2-dbf2-4d71-a806-bb7a95019cab','webauthn-register','Webauthn Register','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'webauthn-register',80),('be7c7c9b-444b-494c-b439-2901a20e3902','delete_account','Delete Account','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',0,0,'delete_account',60),('c2982302-7418-488e-b56f-f5b3b7ded1b0','UPDATE_PROFILE','Update Profile','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'UPDATE_PROFILE',40),('c7d23f51-14d3-4673-829c-da9f4023940e','CONFIGURE_RECOVERY_AUTHN_CODES','Recovery Authentication Codes','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'CONFIGURE_RECOVERY_AUTHN_CODES',130),('c849c59f-89a8-4c54-98eb-eea67a7177a0','CONFIGURE_TOTP','Configure OTP','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'CONFIGURE_TOTP',54),('d494266e-5704-4681-a307-377275f51854','webauthn-register','Webauthn Register','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'webauthn-register',80),('e3827b14-0d07-42ab-a6e4-dbcf8afe64dc','UPDATE_PROFILE','Update Profile','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'UPDATE_PROFILE',40),('e8b83aaa-d9e4-4cc6-ab3a-4d4ea1b79ef5','update_user_locale','Update User Locale','84ab64b6-3491-4ad3-8d0b-34567e32e313',1,0,'update_user_locale',1000),('f67072b6-4580-458d-be61-6da1a1b998df','VERIFY_PROFILE','Verify Profile','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd',1,0,'VERIFY_PROFILE',100);
/*!40000 ALTER TABLE `REQUIRED_ACTION_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_ATTRIBUTE`
--

DROP TABLE IF EXISTS `RESOURCE_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_ATTRIBUTE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_5HRM2VLF9QL5FU022KQEPOVBR` (`RESOURCE_ID`),
  CONSTRAINT `FK_5HRM2VLF9QL5FU022KQEPOVBR` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_ATTRIBUTE`
--

LOCK TABLES `RESOURCE_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_POLICY`
--

DROP TABLE IF EXISTS `RESOURCE_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_POLICY` (
  `RESOURCE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `POLICY_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`,`POLICY_ID`),
  KEY `IDX_RES_POLICY_POLICY` (`POLICY_ID`),
  CONSTRAINT `FK_FRSRPOS53XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`),
  CONSTRAINT `FK_FRSRPP213XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_POLICY`
--

LOCK TABLES `RESOURCE_POLICY` WRITE;
/*!40000 ALTER TABLE `RESOURCE_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SCOPE`
--

DROP TABLE IF EXISTS `RESOURCE_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SCOPE` (
  `RESOURCE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`,`SCOPE_ID`),
  KEY `IDX_RES_SCOPE_SCOPE` (`SCOPE_ID`),
  CONSTRAINT `FK_FRSRPOS13XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`),
  CONSTRAINT `FK_FRSRPS213XCX4WNKOG82SSRFY` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SCOPE`
--

LOCK TABLES `RESOURCE_SCOPE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALLOW_RS_REMOTE_MGMT` tinyint NOT NULL DEFAULT '0',
  `POLICY_ENFORCE_MODE` tinyint DEFAULT NULL,
  `DECISION_STRATEGY` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER`
--

LOCK TABLES `RESOURCE_SERVER` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_PERM_TICKET`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_PERM_TICKET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_PERM_TICKET` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OWNER` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REQUESTER` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint NOT NULL,
  `GRANTED_TIMESTAMP` bigint DEFAULT NULL,
  `RESOURCE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `POLICY_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSR6T700S9V50BU18WS5PMT` (`OWNER`,`REQUESTER`,`RESOURCE_SERVER_ID`,`RESOURCE_ID`,`SCOPE_ID`),
  KEY `FK_FRSRHO213XCX4WNKOG82SSPMT` (`RESOURCE_SERVER_ID`),
  KEY `FK_FRSRHO213XCX4WNKOG83SSPMT` (`RESOURCE_ID`),
  KEY `FK_FRSRHO213XCX4WNKOG84SSPMT` (`SCOPE_ID`),
  KEY `FK_FRSRPO2128CX4WNKOG82SSRFY` (`POLICY_ID`),
  KEY `IDX_PERM_TICKET_REQUESTER` (`REQUESTER`),
  KEY `IDX_PERM_TICKET_OWNER` (`OWNER`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG82SSPMT` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG83SSPMT` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG84SSPMT` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`),
  CONSTRAINT `FK_FRSRPO2128CX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_PERM_TICKET`
--

LOCK TABLES `RESOURCE_SERVER_PERM_TICKET` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_PERM_TICKET` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_PERM_TICKET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_POLICY`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_POLICY` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `TYPE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DECISION_STRATEGY` tinyint DEFAULT NULL,
  `LOGIC` tinyint DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OWNER` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSRPT700S9V50BU18WS5HA6` (`NAME`,`RESOURCE_SERVER_ID`),
  KEY `IDX_RES_SERV_POL_RES_SERV` (`RESOURCE_SERVER_ID`),
  CONSTRAINT `FK_FRSRPO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_POLICY`
--

LOCK TABLES `RESOURCE_SERVER_POLICY` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_RESOURCE`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_RESOURCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_RESOURCE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ICON_URI` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OWNER` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OWNER_MANAGED_ACCESS` tinyint NOT NULL DEFAULT '0',
  `DISPLAY_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSR6T700S9V50BU18WS5HA6` (`NAME`,`OWNER`,`RESOURCE_SERVER_ID`),
  KEY `IDX_RES_SRV_RES_RES_SRV` (`RESOURCE_SERVER_ID`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_RESOURCE`
--

LOCK TABLES `RESOURCE_SERVER_RESOURCE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_RESOURCE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_RESOURCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_SCOPE`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_SCOPE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ICON_URI` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSRST700S9V50BU18WS5HA6` (`NAME`,`RESOURCE_SERVER_ID`),
  KEY `IDX_RES_SRV_SCOPE_RES_SRV` (`RESOURCE_SERVER_ID`),
  CONSTRAINT `FK_FRSRSO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_SCOPE`
--

LOCK TABLES `RESOURCE_SERVER_SCOPE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_URIS`
--

DROP TABLE IF EXISTS `RESOURCE_URIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_URIS` (
  `RESOURCE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`,`VALUE`),
  CONSTRAINT `FK_RESOURCE_SERVER_URIS` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_URIS`
--

LOCK TABLES `RESOURCE_URIS` WRITE;
/*!40000 ALTER TABLE `RESOURCE_URIS` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_URIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REVOKED_TOKEN`
--

DROP TABLE IF EXISTS `REVOKED_TOKEN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REVOKED_TOKEN` (
  `ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `EXPIRE` bigint NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_REV_TOKEN_ON_EXPIRE` (`EXPIRE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REVOKED_TOKEN`
--

LOCK TABLES `REVOKED_TOKEN` WRITE;
/*!40000 ALTER TABLE `REVOKED_TOKEN` DISABLE KEYS */;
/*!40000 ALTER TABLE `REVOKED_TOKEN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROLE_ATTRIBUTE`
--

DROP TABLE IF EXISTS `ROLE_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROLE_ATTRIBUTE` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ROLE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ROLE_ATTRIBUTE` (`ROLE_ID`),
  CONSTRAINT `FK_ROLE_ATTRIBUTE_ID` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROLE_ATTRIBUTE`
--

LOCK TABLES `ROLE_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `ROLE_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `ROLE_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROOT_AUTH_SESSION`
--

DROP TABLE IF EXISTS `ROOT_AUTH_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROOT_AUTH_SESSION` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TIMESTAMP` bigint DEFAULT NULL,
  `VERSION` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ROOT_AUTH_SESSION_REALM` (`REALM_ID`,`TIMESTAMP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROOT_AUTH_SESSION`
--

LOCK TABLES `ROOT_AUTH_SESSION` WRITE;
/*!40000 ALTER TABLE `ROOT_AUTH_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `ROOT_AUTH_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCOPE_MAPPING`
--

DROP TABLE IF EXISTS `SCOPE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SCOPE_MAPPING` (
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ROLE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`ROLE_ID`),
  KEY `IDX_SCOPE_MAPPING_ROLE` (`ROLE_ID`),
  CONSTRAINT `FK_OUSE064PLMLR732LXJCN1Q5F1` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCOPE_MAPPING`
--

LOCK TABLES `SCOPE_MAPPING` WRITE;
/*!40000 ALTER TABLE `SCOPE_MAPPING` DISABLE KEYS */;
INSERT INTO `SCOPE_MAPPING` VALUES ('5ba1d38b-7896-475c-a275-f8b0be01b81d','20da5824-73db-41d3-bbac-12746edfc486'),('629abc42-f3c2-47d5-8e7b-e6a61818e495','6123245b-7a96-4fc4-94aa-4276443ef839'),('629abc42-f3c2-47d5-8e7b-e6a61818e495','ce1beaab-6d75-4d98-b4a4-84a41aff73d9'),('5ba1d38b-7896-475c-a275-f8b0be01b81d','e0e28484-ed84-43ab-8925-b7ad0c900cf4');
/*!40000 ALTER TABLE `SCOPE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCOPE_POLICY`
--

DROP TABLE IF EXISTS `SCOPE_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SCOPE_POLICY` (
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `POLICY_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`,`POLICY_ID`),
  KEY `IDX_SCOPE_POLICY_POLICY` (`POLICY_ID`),
  CONSTRAINT `FK_FRSRASP13XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`),
  CONSTRAINT `FK_FRSRPASS3XCX4WNKOG82SSRFY` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCOPE_POLICY`
--

LOCK TABLES `SCOPE_POLICY` WRITE;
/*!40000 ALTER TABLE `SCOPE_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SCOPE_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SERVER_CONFIG`
--

DROP TABLE IF EXISTS `SERVER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SERVER_CONFIG` (
  `SERVER_CONFIG_KEY` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `VERSION` int DEFAULT '0',
  PRIMARY KEY (`SERVER_CONFIG_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SERVER_CONFIG`
--

LOCK TABLES `SERVER_CONFIG` WRITE;
/*!40000 ALTER TABLE `SERVER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SERVER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SINGLE_USE_OBJECT`
--

DROP TABLE IF EXISTS `SINGLE_USE_OBJECT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SINGLE_USE_OBJECT` (
  `ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NOTES` text COLLATE utf8mb4_unicode_ci,
  `EXPIRE` bigint NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_SINGLE_USE_OBJ_EXPIRE` (`EXPIRE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SINGLE_USE_OBJECT`
--

LOCK TABLES `SINGLE_USE_OBJECT` WRITE;
/*!40000 ALTER TABLE `SINGLE_USE_OBJECT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SINGLE_USE_OBJECT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ATTRIBUTE`
--

DROP TABLE IF EXISTS `USER_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_ATTRIBUTE` (
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `LONG_VALUE_HASH` binary(64) DEFAULT NULL,
  `LONG_VALUE_HASH_LOWER_CASE` binary(64) DEFAULT NULL,
  `LONG_VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_USER_ATTRIBUTE` (`USER_ID`),
  KEY `IDX_USER_ATTRIBUTE_NAME` (`NAME`,`VALUE`),
  KEY `USER_ATTR_LONG_VALUES` (`LONG_VALUE_HASH`,`NAME`),
  KEY `USER_ATTR_LONG_VALUES_LOWER_CASE` (`LONG_VALUE_HASH_LOWER_CASE`,`NAME`),
  CONSTRAINT `FK_5HRM2VLF9QL5FU043KQEPOVBR` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ATTRIBUTE`
--

LOCK TABLES `USER_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `USER_ATTRIBUTE` DISABLE KEYS */;
INSERT INTO `USER_ATTRIBUTE` VALUES ('is_temporary_admin','true','ba1c28da-a84e-493c-9114-cbe05fdb502f','d25b1ae1-da3e-4cba-bf93-540a5fdcda0a',NULL,NULL,NULL);
/*!40000 ALTER TABLE `USER_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT`
--

DROP TABLE IF EXISTS `USER_CONSENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_CONSENT` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `LAST_UPDATED_DATE` bigint DEFAULT NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EXTERNAL_CLIENT_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_LOCAL_CONSENT` (`CLIENT_ID`,`USER_ID`),
  UNIQUE KEY `UK_EXTERNAL_CONSENT` (`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`,`USER_ID`),
  KEY `IDX_USER_CONSENT` (`USER_ID`),
  CONSTRAINT `FK_GRNTCSNT_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT`
--

LOCK TABLES `USER_CONSENT` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT_CLIENT_SCOPE`
--

DROP TABLE IF EXISTS `USER_CONSENT_CLIENT_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_CONSENT_CLIENT_SCOPE` (
  `USER_CONSENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PARAMETER` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#N A#',
  PRIMARY KEY (`USER_CONSENT_ID`,`SCOPE_ID`,`PARAMETER`),
  KEY `IDX_USCONSENT_CLSCOPE` (`USER_CONSENT_ID`),
  KEY `IDX_USCONSENT_SCOPE_ID` (`SCOPE_ID`),
  CONSTRAINT `FK_GRNTCSNT_CLSC_USC` FOREIGN KEY (`USER_CONSENT_ID`) REFERENCES `USER_CONSENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT_CLIENT_SCOPE`
--

LOCK TABLES `USER_CONSENT_CLIENT_SCOPE` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT_CLIENT_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT_CLIENT_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ENTITY`
--

DROP TABLE IF EXISTS `USER_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_ENTITY` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_CONSTRAINT` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_VERIFIED` tinyint NOT NULL DEFAULT '0',
  `ENABLED` tinyint NOT NULL DEFAULT '0',
  `FEDERATION_LINK` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FIRST_NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `LAST_NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REALM_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USERNAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint DEFAULT NULL,
  `SERVICE_ACCOUNT_CLIENT_LINK` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NOT_BEFORE` int NOT NULL DEFAULT '0',
  `LAST_MODIFIED_TIMESTAMP` bigint DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_DYKN684SL8UP1CRFEI6ECKHD7` (`REALM_ID`,`EMAIL_CONSTRAINT`),
  UNIQUE KEY `UK_RU8TT6T700S9V50BU18WS5HA6` (`REALM_ID`,`USERNAME`),
  KEY `IDX_USER_EMAIL` (`EMAIL`),
  KEY `IDX_USER_SERVICE_ACCOUNT` (`REALM_ID`,`SERVICE_ACCOUNT_CLIENT_LINK`),
  KEY `IDX_USER_CREATED_TIMESTAMP` (`REALM_ID`,`CREATED_TIMESTAMP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ENTITY`
--

LOCK TABLES `USER_ENTITY` WRITE;
/*!40000 ALTER TABLE `USER_ENTITY` DISABLE KEYS */;
INSERT INTO `USER_ENTITY` VALUES ('6f56e56d-f8ef-4d1a-8f6b-032448476e28','teste@gmail.com','teste@gmail.com',1,1,NULL,'teste','teste','da5f37ca-01bb-44dc-95a8-b60f0c16f9bd','teste@gmail.com',1789954241268,NULL,0,1789954241268),('ba1c28da-a84e-493c-9114-cbe05fdb502f',NULL,'9f5802fd-dfac-424d-b476-78c9c9f543d2',0,1,NULL,NULL,NULL,'84ab64b6-3491-4ad3-8d0b-34567e32e313','admin',1789954029724,NULL,0,1789954029724);
/*!40000 ALTER TABLE `USER_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_CONFIG`
--

DROP TABLE IF EXISTS `USER_FEDERATION_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_CONFIG` (
  `USER_FEDERATION_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_PROVIDER_ID`,`NAME`),
  CONSTRAINT `FK_T13HPU1J94R2EBPEKR39X5EU5` FOREIGN KEY (`USER_FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_CONFIG`
--

LOCK TABLES `USER_FEDERATION_CONFIG` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_MAPPER`
--

DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_MAPPER` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FEDERATION_PROVIDER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FEDERATION_MAPPER_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_USR_FED_MAP_FED_PRV` (`FEDERATION_PROVIDER_ID`),
  KEY `IDX_USR_FED_MAP_REALM` (`REALM_ID`),
  CONSTRAINT `FK_FEDMAPPERPM_FEDPRV` FOREIGN KEY (`FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`),
  CONSTRAINT `FK_FEDMAPPERPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_MAPPER`
--

LOCK TABLES `USER_FEDERATION_MAPPER` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_MAPPER_CONFIG` (
  `USER_FEDERATION_MAPPER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_FEDMAPPER_CFG` FOREIGN KEY (`USER_FEDERATION_MAPPER_ID`) REFERENCES `USER_FEDERATION_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_MAPPER_CONFIG`
--

LOCK TABLES `USER_FEDERATION_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_PROVIDER`
--

DROP TABLE IF EXISTS `USER_FEDERATION_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_PROVIDER` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CHANGED_SYNC_PERIOD` int DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FULL_SYNC_PERIOD` int DEFAULT NULL,
  `LAST_SYNC` int DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  `PROVIDER_NAME` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_USR_FED_PRV_REALM` (`REALM_ID`),
  CONSTRAINT `FK_1FJ32F6PTOLW2QY60CD8N01E8` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_PROVIDER`
--

LOCK TABLES `USER_FEDERATION_PROVIDER` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_PROVIDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_GROUP_MEMBERSHIP`
--

DROP TABLE IF EXISTS `USER_GROUP_MEMBERSHIP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_GROUP_MEMBERSHIP` (
  `GROUP_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MEMBERSHIP_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`USER_ID`),
  KEY `IDX_USER_GROUP_MAPPING` (`USER_ID`),
  CONSTRAINT `FK_USER_GROUP_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_GROUP_MEMBERSHIP`
--

LOCK TABLES `USER_GROUP_MEMBERSHIP` WRITE;
/*!40000 ALTER TABLE `USER_GROUP_MEMBERSHIP` DISABLE KEYS */;
INSERT INTO `USER_GROUP_MEMBERSHIP` VALUES ('2b170f91-dec1-452a-946c-becbdab73b7c','6f56e56d-f8ef-4d1a-8f6b-032448476e28','UNMANAGED');
/*!40000 ALTER TABLE `USER_GROUP_MEMBERSHIP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_REQUIRED_ACTION`
--

DROP TABLE IF EXISTS `USER_REQUIRED_ACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_REQUIRED_ACTION` (
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REQUIRED_ACTION` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  PRIMARY KEY (`REQUIRED_ACTION`,`USER_ID`),
  KEY `IDX_USER_REQACTIONS` (`USER_ID`),
  CONSTRAINT `FK_6QJ3W1JW9CVAFHE19BWSIUVMD` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_REQUIRED_ACTION`
--

LOCK TABLES `USER_REQUIRED_ACTION` WRITE;
/*!40000 ALTER TABLE `USER_REQUIRED_ACTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_REQUIRED_ACTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `USER_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_ROLE_MAPPING` (
  `ROLE_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`USER_ID`),
  KEY `IDX_USER_ROLE_MAPPING` (`USER_ID`),
  CONSTRAINT `FK_C4FQV34P1MBYLLOXANG7B1Q3L` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ROLE_MAPPING`
--

LOCK TABLES `USER_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `USER_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `USER_ROLE_MAPPING` VALUES ('690188dd-5aa0-4586-99ff-a0e575c77300','6f56e56d-f8ef-4d1a-8f6b-032448476e28'),('25777294-becf-4448-a78c-64c10a80f012','ba1c28da-a84e-493c-9114-cbe05fdb502f'),('c3b58dc5-b1a2-4144-8d2a-ec7460cdf891','ba1c28da-a84e-493c-9114-cbe05fdb502f');
/*!40000 ALTER TABLE `USER_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_VER_CREDENTIAL`
--

DROP TABLE IF EXISTS `USER_VER_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_VER_CREDENTIAL` (
  `ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_SCOPE_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `REVISION` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `UPDATED_DATE` bigint DEFAULT NULL,
  `USER_ATTRIBUTES` text COLLATE utf8mb4_unicode_ci,
  `VERSION` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_KKUWUVD67ONTGSUGOGM8UEWRE` (`USER_ID`,`CLIENT_SCOPE_ID`),
  CONSTRAINT `FK_VCRED_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_VER_CREDENTIAL`
--

LOCK TABLES `USER_VER_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `USER_VER_CREDENTIAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_VER_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_ORIGINS`
--

DROP TABLE IF EXISTS `WEB_ORIGINS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_ORIGINS` (
  `CLIENT_ID` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`VALUE`),
  KEY `IDX_WEB_ORIG_CLIENT` (`CLIENT_ID`),
  CONSTRAINT `FK_LOJPHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_ORIGINS`
--

LOCK TABLES `WEB_ORIGINS` WRITE;
/*!40000 ALTER TABLE `WEB_ORIGINS` DISABLE KEYS */;
INSERT INTO `WEB_ORIGINS` VALUES ('1f0e8266-2a00-4c51-abc1-7a0b09582410','*'),('2524ca06-c64e-4850-b4e5-af745f459add','+'),('62c26143-ea24-4ed0-aac2-7b01627a62c7','http://localhost:8083'),('c1e0cfff-9220-423f-9320-c191c13802de','+');
/*!40000 ALTER TABLE `WEB_ORIGINS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WORKFLOW_STATE`
--

DROP TABLE IF EXISTS `WORKFLOW_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WORKFLOW_STATE` (
  `EXECUTION_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `RESOURCE_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `WORKFLOW_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `RESOURCE_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SCHEDULED_STEP_ID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SCHEDULED_STEP_TIMESTAMP` bigint DEFAULT NULL,
  PRIMARY KEY (`EXECUTION_ID`),
  UNIQUE KEY `UQ_WORKFLOW_RESOURCE` (`WORKFLOW_ID`,`RESOURCE_ID`),
  KEY `IDX_WORKFLOW_STATE_STEP` (`WORKFLOW_ID`,`SCHEDULED_STEP_ID`),
  KEY `IDX_WORKFLOW_STATE_PROVIDER` (`RESOURCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WORKFLOW_STATE`
--

LOCK TABLES `WORKFLOW_STATE` WRITE;
/*!40000 ALTER TABLE `WORKFLOW_STATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `WORKFLOW_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'keycloak'
--

--
-- Dumping routines for database 'keycloak'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-24 21:48:27
